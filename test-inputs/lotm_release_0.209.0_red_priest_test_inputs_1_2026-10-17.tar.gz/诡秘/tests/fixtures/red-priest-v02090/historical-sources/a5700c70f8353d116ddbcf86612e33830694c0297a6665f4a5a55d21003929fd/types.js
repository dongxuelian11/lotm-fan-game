"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RED_PRIEST_ABILITY_IDS = void 0;
exports.RED_PRIEST_ABILITY_IDS = ['hunter.s0.shared-standard', 'hunter.s0.bounded-flame'];
//# sourceMappingURL=types.js.map