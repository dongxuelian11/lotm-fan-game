import assert from 'node:assert/strict';

export const ALLOWED_PUBLIC_CHANGES = Object.freeze(['EPILOGUE_ROOT_STORY_ACTUAL_PATIENTS_AND_REPORT']);
export const ORIGINAL_EPILOGUE_STORY = '停战后的原运输侧线起火，三名原伤员尚待移出。六人分队来自原军团，仍受疲劳、伤势和现场抵抗限制。';
export const ORIGINAL_PRE_EPILOGUE_STORY = '北大陆四方的危机仍未成为全面战争。取得三方实际委托之后，你可以选择亲自发动，也可以拒绝、停战或保护撤离。旧日互助同伴始终保留原来的身份与经历。';

/** Independent oracle for the single approved field, with no runtime imports. */
export function expectedCurrentStory(state) {
  const ep = state.redPriest.epilogue;
  if (ep === null) return ORIGINAL_PRE_EPILOGUE_STORY;
  assert.equal(ep.patients.length, 3); assert.equal(new Set(ep.patients.map(patient => patient.id)).size, 3);
  assert(ep.patients.every(patient => ['EVACUATED', 'SHELTERED'].includes(patient.status)));
  assert(['ACTIVE', 'RESOLVED', 'WITHDRAWN'].includes(ep.status)); assert.equal(typeof ep.reported, 'boolean');
  assert(!ep.reported || ep.status !== 'ACTIVE');
  const evacuated = ep.patients.reduce((total, patient) => total + Number(patient.status === 'EVACUATED'), 0);
  const sheltered = ep.patients.length - evacuated;
  const account = ep.reported ? '救援人数和原分队损失已经交接。'
    : ep.status === 'ACTIVE' ? '原分队仍受疲劳、伤势和现场抵抗限制。'
      : '救援已经收束，实际人数和原分队损失尚待交接。';
  return `停战后的原运输侧线起火；已转运原伤员${evacuated}名，${sheltered}名仍留在有遮蔽的原救护站。${account}`;
}

/** Only RedPriestProjection.story is replaced. Complete projection hashing
 * remains mandatory after normalization. Global SliceProjection embeds this
 * object once at redPriest, so its one equivalent path is redPriest.story. */
export function reconstructOriginalStory(view, state) {
  assert(Object.hasOwn(view, 'story')); assert.equal(typeof view.story, 'string');
  const currentStory = expectedCurrentStory(state);
  assert.equal(view.story, currentStory, 'Current story must exactly report actual patients and report status');
  const hasEpilogue = state.redPriest.epilogue !== null;
  const originalStory = hasEpilogue ? ORIGINAL_EPILOGUE_STORY : ORIGINAL_PRE_EPILOGUE_STORY;
  const prior = structuredClone(view);
  if (hasEpilogue) prior.story = originalStory;
  return { prior, originalStory, currentStory, changed: hasEpilogue,
    actualPatients: hasEpilogue ? { evacuated: state.redPriest.epilogue.patients.filter(patient => patient.status === 'EVACUATED').length,
      sheltered: state.redPriest.epilogue.patients.filter(patient => patient.status === 'SHELTERED').length,
      status: state.redPriest.epilogue.status, reported: state.redPriest.epilogue.reported } : null };
}
