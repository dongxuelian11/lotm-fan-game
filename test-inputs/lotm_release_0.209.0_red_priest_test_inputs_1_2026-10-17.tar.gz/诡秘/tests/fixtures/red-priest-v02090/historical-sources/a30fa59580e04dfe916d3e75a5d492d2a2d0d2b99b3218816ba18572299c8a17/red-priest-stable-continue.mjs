import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { closeSync, existsSync, fsyncSync, lstatSync, mkdirSync, mkdtempSync, openSync, readFileSync, readdirSync, readSync, renameSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';

/** Continue the same sealed command1137 observation of the original918 planning branch.
 * Only public projection/actions enter chooseAction. No seed/options/outcome search.
 * Original983, original1017 and both actual failed doses remain sealed history.
 * No runtime imports occur before exact historical pins and independent219 proof verification.
 */
export const SOURCE = 'tests/fixtures/conqueror-v01870/natural.json';
export const SOURCE_SHA256 = '469a6ac77052f92ac0dbd8e6ea39164592de6b4c8d8ea0405b080c1a015f7973';
export const ORIGINAL_PREFIX_SHA256 = '88211e592c4714058c3e8b45eab02fa0f0ae73b35c2526288503329ec1d52f2e';
export const PREFIX_SHA256 = ORIGINAL_PREFIX_SHA256;
export const PREFIX_COUNT = 795;
export const FORK_COUNT = 918;
const FORMAT = 'RED_PRIEST_DURABLE_PUBLIC_ACTION_BOUNDARY_V1';
const SELF = fileURLToPath(import.meta.url);
export const POLICY = Object.freeze({
  id: 'RED_PRIEST1137_STABLE_POSTWAR_CONTINUATION_V1',
  materialAttemptScope: 'SINCE_LAST_ACTUAL_CONSUMPTION',
  promotionPreparation: 'REQUIRE_SAME_COMPOUND_PAID_STABILITY',
  minimumMindBeforeStability: 78, preparedEpilogue: true,
  maximumNewCommands: 900, attemptsPerMaterialOperation: 12,
  authorityAttemptsPerPolity: 12, battleAttemptsPerNode: 4, armisticeAttempts: 20,
  maximumSupportCommandsWithoutProgress: 70, maximumUnchangedWeeklyWaits: 4,
  cashBeforeDeclaration: 1600, preparationHealth: 100, preparationMind: 100, preparationSpirituality: 120,
  materialOrder: 'LOCAL_WORK_BEFORE_FIRST_PUBLIC_MATERIAL_DESTINATION',
  warOrder: 'EXPLICIT_PLANNING_OPT_IN_THEN_REAL_RECON_COORDINATED_EXTRA_SUPPLIES_BATTLE_CONSOLIDATE_ACHIEVED_TRUCE',
  plannedStance: 'COORDINATED', extraSupplies: true, minimumPlanningMorale: 60, supplyConvoyThreshold: 40,
  publicBasis: 'Recon+8, six actual extra supply per army+12, coordinated+20 needs three present authorized armies each1000personnel and60morale; choose once before any battle result',
  recovery: 'BOUNDED_ENABLED_CLINIC_REST_WORK_MILITARY_LABOUR_ACTUAL_ARMY_REST_AND_ORIGINAL_STOCK_CONVOYS',
  rescue: 'REAL_RETURN_ROUTE_THEN_COORDINATE_ONCE_THEN_EVACUATE_OR_WITHDRAW_AND_REPORT',
  logisticsRecovery: true, fieldArmyRecovery: true, finiteSupplyRecovery: true, postwarFootReturn: true,
  verifiedPersonnelExit: '现有人员已经不足以完成剩余目标。继续交战不能补回损失，可以真实停战或保护撤离。',
  noReroll: true, snapshots: 'ONE_ROLLING_CHECKPOINT_AND_FINAL_CAPTURE_ONLY',
});
export const LEGACY1017_PIN = Object.freeze({
  "format": "RED_PRIEST1017_SEALED_CAPTURE_V1",
  "commandCount": 1017,
  "checkpointPayloadSha256": "ad9a5f482a9c70c182bb10abb781df3c9b330ceba9055ed6241145eb51d25d56",
  "stateSha256": "fd4dfbe50b8ab6fcbe1ba02f7ba6465358f2d0d4402a8081a732fa0b92813cdc",
  "publicSha256": "bfaa38148d473d572d8fa41642f0a99e88ed49368b3fe7cdeeacdd051d39d9d2",
  "random": {
    "seed": "hunter-rebuild-first",
    "cursor": 434
  },
  "freezeSha256": "8edaca68cd1ede2c3dad5b31b67e5297a7c0a583feea2524eb24ed5b7b0596a8",
  "files": [
    {
      "file": "checkpoint.json",
      "bytes": 3880482,
      "sha256": "31481a9606f6d1aa326e22c4772ef0e8ae3bec8cc23fdc9216f900449626afe5"
    },
    {
      "file": "commands.ndjson",
      "bytes": 90138,
      "sha256": "23df568c7690a4a69fc99d6f96d914f511fde900886aac9926c047a627a973a4"
    },
    {
      "file": "freeze.json",
      "bytes": 549731,
      "sha256": "5ee9dd98303e2beaab257563a0ce9a0cd86f59d94fb7be8d0845fd067d247ba2"
    },
    {
      "file": "natural.json",
      "bytes": 4409834,
      "sha256": "96e61054a4404e8ba7fb6b3db7349f33b3a1e46b9d9e1e28ed3e886cb7d58b45"
    },
    {
      "file": "runtime-transition.json",
      "bytes": 1219,
      "sha256": "14f770b7670cf3a0dee8c30a8e43e7e6d756d65c9a1010f7f58df6c40693452b"
    },
    {
      "file": "summary.json",
      "bytes": 9779,
      "sha256": "8116d2f3796fd211d4a7833a89e353203b7520af16f1f5a42630c91094174866"
    }
  ],
  "producer": {
    "file": "producer.mjs",
    "bytes": 54193,
    "sha256": "280452d293448be4678ab95075ec02cf79b1815407ca8647d4c2b34e197f5065"
  }
});
export const STABILITY_PIN = Object.freeze({
  "format": "RED_PRIEST1137_SEALED_CAPTURE_V1",
  "commandCount": 1137,
  "checkpointPayloadSha256": "0ab3ef4e30ca552ed16611439a270ac921f0d1763af3854b3d3cb58c95290a88",
  "stateSha256": "ef0a3d0bad112bb15156257e905d65c00dbadce7c79914d58fa097d52c8062bc",
  "publicSha256": "5bfa25052d1fb2a01c8d0f1ce8424d0318477aabfe6f5baf0e778ce97490f354",
  "random": {
    "seed": "hunter-rebuild-first",
    "cursor": 477
  },
  "freezeSha256": "f0b74f904c2bdc58838d013daf1a9669462582af04d412c7d0e0d35308edac4a",
  "files": [
    {
      "path": "checkpoint.json",
      "bytes": 5578135,
      "sha256": "2076c05ac77a6506512cced159a507a358874510593af31f642560d840c7cbf5"
    },
    {
      "path": "commands.ndjson",
      "bytes": 197906,
      "sha256": "29931eec874ef983d875a20635c1cf77f4f3b41d1a6f2a0852a643c080ca1eb5"
    },
    {
      "path": "continuation.json",
      "bytes": 9259,
      "sha256": "a99965211e755af3b18ab8165a14ad8e7297d30975c9c95552e5b8a94954c199"
    },
    {
      "path": "freeze.json",
      "bytes": 549731,
      "sha256": "153c1bf1e8dbe0e9823a3f9ba6f43de176bc3d05e3f98a21fbc7e3fb8de42655"
    },
    {
      "path": "natural.json",
      "bytes": 5998188,
      "sha256": "fc50408c3dbb087d46e441dfc5228993c1d65d750874cda81621e567e8930ac0"
    },
    {
      "path": "runtime-transition.json",
      "bytes": 1219,
      "sha256": "8706ff676bf4d195b44305de429a35c6f2e3007922e112945a1216dcbab13367"
    },
    {
      "path": "summary.json",
      "bytes": 9104,
      "sha256": "e98c504aa28f22008fdbba1c2b8f18bfc7197445f0e30724432f74b5cf0aeb71"
    }
  ],
  "producer": {
    "file": "producer.mjs",
    "bytes": 61731,
    "sha256": "d19b9b1181d3826c61a9cd8da412ed2ae8114d1645486944a91a493bf581d0ef"
  }
});
export const REVIEWED_STABILITY_PROOF_SHA256 = 'f7ae783e6592d8fe1d4c5fc41c2555b271c4ed2a3860140bee88b77073328dff'; // Freeze after independent219 replay succeeds.
const clone = value => structuredClone(value);
export function stable(value) {
  if (Array.isArray(value)) return `[${value.map(stable).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stable(value[key])}`).join(',')}}`;
  return JSON.stringify(value);
}
const sha = value => createHash('sha256').update(value).digest('hex');
export const stateHash = value => sha(stable(value));
const compactHash = value => sha(JSON.stringify(value));
export function fileEvidence(path) {
  const before = lstatSync(path, { bigint: true });
  assert(before.isFile() && !before.isSymbolicLink(), `Not a frozen regular file: ${path}`);
  const hash = createHash('sha256'), fd = openSync(path, 'r'), buffer = Buffer.allocUnsafe(65536);
  let bytes = 0;
  try { for (;;) { const n = readSync(fd, buffer, 0, buffer.length, null); if (!n) break; bytes += n; hash.update(buffer.subarray(0, n)); } }
  finally { closeSync(fd); }
  const after = lstatSync(path, { bigint: true });
  assert.equal(before.size, after.size); assert.equal(before.mtimeNs, after.mtimeNs); assert.equal(BigInt(bytes), after.size);
  return { bytes, sha256: hash.digest('hex') };
}
export function inspectFreeze(root = process.cwd()) {
  const files = [];
  const walk = name => {
    const path = join(root, name), stat = lstatSync(path);
    assert(!stat.isSymbolicLink(), `Frozen input cannot be a symlink: ${name}`);
    if (stat.isDirectory()) for (const child of readdirSync(path).sort()) walk(join(name, child));
    else if (stat.isFile()) files.push({ file: name.split(sep).join('/'), ...fileEvidence(path) });
  };
  assert(existsSync(join(root, 'dist/domain/red-priest/owned-session.js')), 'Build reviewed mechanics before capture; no game was loaded');
  for (const name of ['package.json', 'package-lock.json', 'src', 'dist/domain', 'dist/content', 'dist/resolution', 'dist/persistence', 'dist/shared', 'dist/application', 'dist/simulation']) walk(name);
  files.push({ file: '$natural-producer', ...fileEvidence(SELF) }, { file: SOURCE, ...fileEvidence(join(root, SOURCE)) });
  return { sha256: compactHash(files), files };
}
function stampFreeze(root, freeze) {
  return freeze.files.map(file => {
    const path = file.file === '$natural-producer' ? SELF : join(root, file.file), stat = lstatSync(path, { bigint: true });
    return { path, size: stat.size, mtimeNs: stat.mtimeNs, ctimeNs: stat.ctimeNs, ino: stat.ino };
  });
}
function unchangedSinceFreeze(stamps) {
  for (const before of stamps) {
    const after = lstatSync(before.path, { bigint: true });
    assert(after.isFile() && !after.isSymbolicLink(), `Frozen input replaced: ${before.path}`);
    for (const key of ['size', 'mtimeNs', 'ctimeNs', 'ino']) assert.equal(after[key], before[key], `Frozen input changed: ${before.path}`);
  }
}
export function readSource(root = process.cwd()) {
  const path = join(root, SOURCE), bytes = readFileSync(path);
  assert.equal(sha(bytes), SOURCE_SHA256, 'Original natural capture bytes have changed; do not regenerate/replace them');
  const old = JSON.parse(bytes), s = old.final;
  assert.equal(old.commands.length, PREFIX_COUNT); assert.equal(compactHash(old.commands), PREFIX_SHA256);
  assert.equal(old.seed, 'hunter-rebuild-first'); assert.equal(s.runId, 'hunter-rebuild-natural');
  assert.equal(s.schemaVersion, 184); assert.equal(s.contentVersion, 'conqueror-v184');
  assert.equal(s.status, 'ACTIVE'); assert.equal(s.revision, 796); assert.equal(s.week, 200);
  assert.deepEqual([s.health, s.mind, s.spirituality, s.cash, s.actionsRemaining], [80, 100, 120, 536, 3]);
  assert.deepEqual(s.random, { seed: old.seed, cursor: 376 });
  assert.equal(s.progression.pathwayId, 'hunter'); assert.equal(s.progression.sequence, 1); assert.equal(s.progression.acting, 100);
  assert.equal(Object.keys(s.progression.mastery).length, 23); assert.equal(Object.values(s.progression.mastery).filter(n => n === 0).length, 6);
  assert.equal(s.injuries.length, 2); assert(s.injuries.every(i => i.severity === 'LIGHT'));
  assert.deepEqual(s.conqueror.bottles.map(b => [b.id, b.status, b.outcome]), [
    ['conqueror-potion-1', 'CONSUMED', 'FAILURE'], ['conqueror-potion-2', 'CONSUMED', 'FAILURE'], ['conqueror-potion-3', 'CONSUMED', 'SUCCESS'],
  ]);
  assert.equal(s.combat, null); assert.equal(s.activeEvent, null);
  return Object.fromEntries(['provenance', 'creation', 'seed', 'commands', 'initial', 'final'].map(key => [key, old[key]]));
}
async function loadRuntime(root) {
  const [slice, migration, session] = await Promise.all(['domain/slice/index', 'domain/slice/migration', 'domain/red-priest/owned-session']
    .map(name => import(pathToFileURL(join(root, `dist/${name}.js`)).href)));
  return { ...slice, migrateSliceState: migration.migrateSliceState, openRedPriestRuntimeSession: session.openRedPriestRuntimeSession };
}
function verifyMigration(runtime, raw) {
  const current = runtime.migrateSliceState(raw);
  assert.equal(current.contentVersion, 'red-priest-v206'); assert.equal(current.schemaVersion, 206);
  for (const [key, value] of Object.entries(raw)) {
    if (['schemaVersion', 'contentVersion', 'fool', 'redPriest'].includes(key)) continue;
    assert.deepEqual(current[key], value, `Migration changed original ${key}`);
  }
  runtime.assertValidSliceState(current); return current;
}
function checkOriginals(state, old) {
  assert.equal(state.runId, old.final.runId); assert.equal(state.random.seed, old.seed);
  assert(state.random.cursor >= old.final.random.cursor);
  for (const key of ['hunter', 'provoker', 'pyromaniac', 'conspirator', 'reaper', 'ironBloodKnight', 'warBishop', 'weatherWarlock', 'conqueror', 'combatHistory', 'world'])
    assert.deepEqual(state[key], old.final[key], `Original ${key} must not change`);
  const { coreStats: _now, ...identity } = state.character, { coreStats: _then, ...original } = old.final.character;
  assert.deepEqual(identity, original);
  for (const [id, value] of Object.entries(old.final.progression.mastery)) assert.equal(state.progression.mastery[id], value, `Original mastery changed: ${id}`);
  if (state.redPriest?.source) {
    const source = state.redPriest.source, raw = old.final;
    assert.equal(source.revision, raw.revision); assert.deepEqual(source.random, raw.random); assert.deepEqual(source.character, raw.character);
    assert.deepEqual(source.finance, Object.fromEntries(['weeklyBudget', 'wagePaidWeek', 'lifeTier', 'nextLifeTier', 'debts', 'missedWeeks', 'credit'].map(key => [key, raw[key]])));
    assert.deepEqual(source.budget, { week: raw.week, date: raw.date, actions: raw.actionsRemaining, cash: raw.cash,
      health: raw.health, mind: raw.mind, spirituality: raw.spirituality, pollution: raw.seer.pollution,
      injuries: raw.injuries, injuryRisk: raw.injuryRisk, status: raw.status, sequence: raw.progression.sequence,
      acting: raw.progression.acting, mastery: raw.progression.mastery, coreStats: raw.character.coreStats, completedSources: raw.seer.completedSources });
  }
}
function syncDirectory(path) {
  const fd = openSync(path, 'r'); try { fsyncSync(fd); } finally { closeSync(fd); }
}
function durableCreate(path, contents) {
  const fd = openSync(path, 'wx'); try { writeFileSync(fd, contents); fsyncSync(fd); } finally { closeSync(fd); }
}
function encodeCheckpoint(payload) { return JSON.stringify({ sha256: stateHash(payload), payload }); }
function decodeCheckpoint(bytes) {
  const wrapped = JSON.parse(bytes); assert.equal(wrapped.sha256, stateHash(wrapped.payload), 'Checkpoint checksum mismatch');
  assert.equal(wrapped.payload.format, FORMAT); return wrapped;
}
/** A complete next boundary is never thrown away merely because rename was interrupted. */
function recoverAtomicNext(path) {
  const nextPath = `${path}.next`; if (!existsSync(nextPath)) return;
  const current = existsSync(path) ? decodeCheckpoint(readFileSync(path, 'utf8')) : null;
  let next;
  try { next = decodeCheckpoint(readFileSync(nextPath, 'utf8')); }
  catch {
    const retained = `${path}.incomplete`;
    assert(!existsSync(retained), 'A prior incomplete checkpoint already exists; preserve both files and inspect before resuming');
    renameSync(nextPath, retained); syncDirectory(dirname(path)); return;
  }
  assert.equal(next.payload.predecessorSha256, current?.sha256 ?? null, 'Unrecognized next checkpoint; preserve files for inspection');
  renameSync(nextPath, path); syncDirectory(dirname(path));
}
function saveCheckpoint(path, payload, predecessorSha256) {
  assert(!existsSync(`${path}.next`), 'A pending atomic replacement must be recovered first');
  const next = { ...payload, predecessorSha256 }, text = encodeCheckpoint(next);
  durableCreate(`${path}.next`, text); renameSync(`${path}.next`, path); syncDirectory(dirname(path));
  return decodeCheckpoint(text);
}
function replaceDerived(path, value) {
  // Derived outputs are only written at a manual/terminal boundary, not per step.
  const temp = `${path}.derived-next`, fd = openSync(temp, 'w');
  try { writeFileSync(fd, value); fsyncSync(fd); } finally { closeSync(fd); }
  renameSync(temp, path); syncDirectory(dirname(path));
}
const section = (view, id) => view.sections.find(s => s.id === id)?.lines ?? [];
const commandKey = command => JSON.stringify(command);
const nestedType = action => action.command.command?.type;
const injuryCount = view => Number(section(view, 'finance').join(' ').match(/当前伤势(\d+)份/)?.[1] ?? 0);
const cash = view => Number(view.resources.cash.match(/^\d+/)?.[0] ?? 0);
const achievement = view => {
  const match = section(view, 'campaign-status').join(' ').match(/独立胜利(\d+)\/5；交战战区(\d+)\/3；受控战区(\d+)\/3/);
  return match ? { victories: Number(match[1]), engaged: Number(match[2]), controlled: Number(match[3]) } : null;
};
const materialReady = view => section(view, 'materials').filter(line => line.includes('本人持有原件')).length === 3;
const materialUnavailable = view => section(view, 'materials').some(line => line.includes('当前无法取回'));
function startingPolicy() { return { phase: 'GUIDANCE', attempts: {}, supportSinceProgress: 0, unchangedWaits: 0, lastProgress: null, stopAfterWithdrawal: null }; }
function progressSignature(view) {
  return stateHash({ promoted: view.promoted, guidance: view.guidanceKnown,
    materials: section(view, 'materials'), campaign: section(view, 'campaign-status'), epilogue: section(view, 'epilogue'),
    actions: view.actions.filter(a => !['REST', 'WORK', 'CLINIC', 'NEXT_WEEK'].includes(a.command.type))
      .map(a => ({ command: a.command, label: a.label })) });
}
function price(action) {
  const text = action.cost;
  return { actions: Number(text.match(/(\d+)行动/)?.[1] ?? 1), cash: Number(text.match(/(\d+)便士/)?.[1] ?? 0), spirituality: Number(text.match(/(\d+)灵性/)?.[1] ?? 0) };
}
/** This function receives no private state, RNG, checks or outcome receipts. */
export function chooseAction(view, previous, definition = POLICY) {
  const policy = clone(previous), all = view.actions, enabled = all.filter(a => a.enabled);
  const find = type => enabled.find(a => a.command.type === type);
  const campaign = type => all.find(a => a.command.type === 'CAMPAIGN' && nestedType(a) === type);
  const choose = (action, reason) => { assert(action?.enabled, 'Policy may select only an enabled public action'); return { action: clone(action), reason, policy }; };
  const stop = (code, reason) => ({ stop: code, reason, policy });
  const count = action => policy.attempts[commandKey(action.command)] ?? 0;
  const support = (reason, need = {}, allowArmyWork = true) => {
    const clinic = find('CLINIC'), work = find('WORK'), rest = find('REST'), wait = find('NEXT_WEEK');
    const armyWork = enabled.find(a => a.command.type === 'CAMPAIGN' && nestedType(a) === 'MILITARY_LABOUR');
    const requiredCash = need.cash ?? 0;
    const headquartersReturn = enabled.find(a => a.command.type === 'CAMPAIGN' && nestedType(a) === 'RETURN_TO_HEADQUARTERS');
    if (definition.logisticsRecovery && cash(view) < requiredCash && !work && !(allowArmyWork && armyWork) && headquartersReturn)
      return choose(headquartersReturn, 'Return along the real military route to earn legal income; retain war, losses, time and personal debts');
    if (policy.supportSinceProgress >= POLICY.maximumSupportCommandsWithoutProgress || policy.unchangedWaits >= POLICY.maximumUnchangedWeeklyWaits)
      return stop('FINITE_PUBLIC_NO_PROGRESS', `Finite recovery limit reached: ${reason}`);
    if (injuryCount(view) > 0 && clinic) return choose(clinic, `Pay actual treatment before recovery: ${reason}`);
    if (cash(view) < requiredCash) {
      if (work) return choose(work, `Earn the one legal occupational wage this week: ${reason}`);
      if (allowArmyWork && armyWork) return choose(armyWork, `Perform the enabled, treasury-funded weekly military task: ${reason}`);
    }
    if (rest && (injuryCount(view) > 0 || view.resources.health < (need.health ?? 0) || view.resources.mind < (need.mind ?? 0) || view.resources.spirituality < (need.spirituality ?? 0)))
      return choose(rest, `Use ordinary paid-life recovery, preserving actual wounds: ${reason}`);
    if (wait) return choose(wait, `Actually pass seven days and settle costs: ${reason}`);
    return stop('PUBLIC_RECOVERY_UNAVAILABLE', reason);
  };
  const prepare = (reason, need, allowArmyWork = true) => {
    if (cash(view) < (need.cash ?? 0) || view.resources.actionsRemaining < (need.actions ?? 1) || view.resources.health < (need.health ?? 0)
      || view.resources.mind < (need.mind ?? 0) || view.resources.spirituality < (need.spirituality ?? 0) || need.uninjured && injuryCount(view) > 0)
      return support(reason, need, allowArmyWork);
    return null;
  };
  const atFullHealth = { health: POLICY.preparationHealth, mind: POLICY.preparationMind, spirituality: POLICY.preparationSpirituality, uninjured: true };
  const pursue = (action, reason, extra = {}) => {
    const needs = { ...price(action), ...extra };
    const preparation = prepare(reason, needs); if (preparation) return preparation;
    if (action.enabled) return choose(action, reason);
    if (/无法按当前保管线|已经用尽|无法取回|后备.*不足/.test(action.reason ?? '')) return stop('PUBLIC_FINITE_RESOURCE_LOSS', action.reason);
    // Return-route prices are deliberately prose rather than a numeric total.
    // A public insufficient-funds block authorizes seeking actual legal income,
    // never reading the private route cost or repeatedly waiting into debt.
    if (/费用|资源/.test(action.reason ?? '') && cash(view) >= needs.cash) needs.cash = cash(view) + 1;
    return support(`${reason}; public block: ${action.reason ?? 'unavailable'}`, needs);
  };
  const materials = afterWar => {
    if (materialUnavailable(view)) return stop('ORIGINAL_MATERIAL_UNAVAILABLE', 'An original material is publicly unavailable; no replacement, reset or reroll is permitted');
    const local = all.find(a => a.command.type === 'MATERIAL' && nestedType(a) !== 'PREPARE_COMPOUND');
    if (local) {
      if ((policy.materialCycle?.attempts[commandKey(local.command)] ?? 0) >= definition.attemptsPerMaterialOperation) return stop('FINITE_MATERIAL_ATTEMPTS', `Finite attempts exhausted for ${local.label}`);
      return pursue(local, `Complete the current original-material operation at this actual location: ${local.label}`, atFullHealth);
    }
    if (materialReady(view) || all.some(a => a.command.type === 'CONSUME')) return null;
    // Projection order is public; local work always wins, so preferred travel
    // cannot bounce the actor between the two original residue destinations.
    const travel = all.find(a => a.command.type === 'TRAVEL' && a.command.to !== 'loen-headquarters' && a.command.to !== 'backlund:sealed-compounding-room');
    return travel ? pursue(travel, `Follow the first publicly offered remaining material lead: ${travel.label}`)
      : stop(afterWar ? 'NO_RECOVERABLE_MATERIAL_ROUTE' : 'NO_PUBLIC_MATERIAL_ROUTE', 'No public route to the remaining original materials is available');
  };
  for (let transitions = 0; transitions < 8; transitions++) {
    if (policy.phase === 'WITHDRAWN_PERSONNEL') {
      const ended = section(view, 'campaign-status').includes('战事已停，原有损失和经历继续保留。') && !campaign('WITHDRAW_PROTECT');
      return stop(ended ? 'FINITE_CAMPAIGN_WITHDRAWN' : 'FINITE_CAMPAIGN_REVIEW_REQUIRED', ended
        ? 'Executed the real protective withdrawal after the exact public warning that remaining personnel cannot complete the remaining objectives; all losses and costs remain'
        : 'The selected protective withdrawal did not publicly confirm a stopped war; preserve the actual result for review');
    }
    if (policy.stopAfterWithdrawal) {
      if (definition.logisticsRecovery) return stop('FINITE_CAMPAIGN_REVIEW_REQUIRED', policy.stopAfterWithdrawal);
      const withdrawal = campaign('WITHDRAW_PROTECT');
      if (withdrawal) return pursue(withdrawal, `End the actual failed campaign by its ordinary route: ${policy.stopAfterWithdrawal}`);
      return stop('FINITE_CAMPAIGN_WITHDRAWN', policy.stopAfterWithdrawal);
    }
    if (view.promoted) policy.phase = 'RESCUE';
    if (policy.phase === 'GUIDANCE') {
      if (view.guidanceKnown) { policy.phase = 'MATERIALS'; continue; }
      const action = find('LEARN_GUIDANCE'); return action ? choose(action, 'Learn guidance publicly from the exact migrated living original') : stop('GUIDANCE_UNAVAILABLE', 'Original public guidance is unavailable');
    }
    if (policy.phase === 'MATERIALS') {
      const preparation = prepare('Heal the original light wounds before material investigation', { ...atFullHealth, actions: 1 });
      if (preparation) return preparation;
      const next = materials(false); if (next) return next;
      policy.phase = 'FUND_WAR'; continue;
    }
    if (policy.phase === 'FUND_WAR') {
      const preparation = prepare('Accumulate a finite personal campaign reserve through actual weekly wages', { ...atFullHealth, actions: 1, cash: POLICY.cashBeforeDeclaration }, false);
      if (preparation) return preparation;
      const home = all.find(a => a.command.type === 'TRAVEL' && a.command.to === 'loen-headquarters');
      if (home) return pursue(home, 'Personally return to the coalition headquarters before requesting authority');
      policy.phase = 'WAR'; continue;
    }
    if (policy.phase === 'WAR') {
      const enablePlanning = campaign('ENABLE_PLANNING');
      if (enablePlanning) return pursue(enablePlanning, 'Explicitly enable the authorized planning rules before declaration; preserve the entire original predeclaration state', { actions: 0 });
      if (definition.verifiedPersonnelExit && section(view, 'campaign-readiness').includes(definition.verifiedPersonnelExit)) {
        const withdrawal = campaign('WITHDRAW_PROTECT');
        if (withdrawal?.enabled) {
          policy.phase = 'WITHDRAWN_PERSONNEL';
          return choose(withdrawal, 'The exact public readiness warning confirms insufficient remaining original personnel for the remaining objectives; execute the approved real protective withdrawal');
        }
        return withdrawal ? support('Obtain the real action needed for the publicly justified protective withdrawal', { actions: 1 })
          : stop('FINITE_CAMPAIGN_REVIEW_REQUIRED', 'Public personnel exhaustion has no enabled protective withdrawal route');
      }
      if (/将两份外在原特性/.test(view.nextStep)) { policy.phase = 'POSTWAR'; continue; }
      const authority = campaign('REQUEST_AUTHORITY');
      if (authority) {
        if (count(authority) >= definition.authorityAttemptsPerPolity) return stop('FINITE_AUTHORITY_ATTEMPTS', 'Actual coalition permission was not obtained within the finite public policy');
        return pursue(authority, `Obtain this polity's actual coalition authority: ${authority.label}`, atFullHealth);
      }
      const declaration = campaign('DECLARE_OFFENSIVE');
      if (declaration) return pursue(declaration, 'Issue the actual offensive only after the three public authorizations',
        definition.logisticsRecovery ? { ...atFullHealth, cash: POLICY.cashBeforeDeclaration } : atFullHealth);
      const achieved = achievement(view), truce = campaign('SEEK_ARMISTICE');
      if (truce && achieved && achieved.victories >= 5 && achieved.engaged === 3 && achieved.controlled === 3 && /完整经历/.test(view.nextStep)) {
        if (count(truce) >= POLICY.armisticeAttempts) { policy.stopAfterWithdrawal = 'Actual truce was refused within the finite negotiation policy'; continue; }
        return pursue(truce, 'Negotiate actual truce after the publicly recorded five victories and three controlled theaters');
      }
      const legionNeeds = section(view, 'campaign-losses').flatMap(line => {
        const match = line.match(/^(.+)：现员(\d+)，阵亡\d+，伤员\d+，补给(\d+)，士气(\d+)/);
        return match ? [{ name: match[1], personnel: Number(match[2]), supply: Number(match[3]), morale: Number(match[4]) }] : [];
      });
      const depletedSupply = legionNeeds.filter(l => l.supply < POLICY.supplyConvoyThreshold);
      if (definition.finiteSupplyRecovery && depletedSupply.length) {
        const forDepleted = a => depletedSupply.some(l => a.label.includes(l.name.slice(0, 2)));
        const reinforcement = enabled.find(a => a.command.type === 'CAMPAIGN' && nestedType(a) === 'REORGANIZE' && forDepleted(a) && legionNeeds.some(l => l.personnel < 1200 && a.label.includes(l.name.slice(0, 2))));
        const supplies = all.filter(a => a.command.type === 'CAMPAIGN' && nestedType(a) === 'SUPPLY_ONLY' && forDepleted(a));
        const supply = supplies.find(a => a.enabled);
        if (!reinforcement && supply) return choose(supply, 'Pay the actual finite supply convoy when the original manpower reserve cannot reinforce this publicly undersupplied army');
        if (!reinforcement && supplies.some(a => /仍在途中/.test(a.reason ?? '')))
          return support('Wait for the actual already-dispatched original-supply convoy');
        const resourceBlockedSupply = supplies.find(a => /行动|费用|灵性/.test(a.reason ?? ''));
        if (!reinforcement && resourceBlockedSupply) return pursue(resourceBlockedSupply, 'Earn or recover the actual personal resources for the finite original-supply convoy');
      }
      if (definition.fieldArmyRecovery && legionNeeds.some(l => l.morale < POLICY.minimumPlanningMorale)) {
        const armyRest = campaign('REST_FIELD_ARMIES'), returnHome = campaign('RETURN_TO_HEADQUARTERS');
        if (armyRest?.enabled) return choose(armyRest, 'Pay the actual headquarters rest costs to recover original-army morale; preserve all casualties, reserves and battle attempts');
        if (returnHome?.enabled) return choose(returnHome, 'Return the same original armies along the real route for headquarters rest; retain the active war and all losses');
        if (/行动/.test(armyRest?.reason ?? returnHome?.reason ?? '')) return support('Actually pass time for the headquarters rest action', { actions: 1 });
        return stop('PUBLIC_FIELD_ARMY_RECOVERY_UNAVAILABLE', armyRest?.reason ?? 'No enabled actual route or headquarters rest is available for the exhausted original armies');
      }
      const depleted = legionNeeds.filter(l => l.personnel < 1200 || l.supply < 20 || l.morale < 50);
      if (depleted.length) {
        const reinforcement = enabled.find(a => a.command.type === 'CAMPAIGN' && nestedType(a) === 'REORGANIZE' && depleted.some(l => a.label.includes(l.name.slice(0, 2))));
        if (reinforcement) return pursue(reinforcement, 'Request real finite reserves for a publicly depleted legion');
      }
      const consolidation = campaign('CONSOLIDATE'), battle = campaign('PREPARED_BATTLE'), march = campaign('MARCH');
      if (definition.logisticsRecovery && march && /本人在鲁恩联合协商处；原军团在鲁恩联合协商处/.test(section(view, 'campaign-status')[0] ?? '')) {
        const reserve = prepare('Earn the existing 1600-penny operating reserve before leaving headquarters again',
          { ...atFullHealth, actions: 1, cash: POLICY.cashBeforeDeclaration }, false);
        if (reserve) return reserve;
      }
      if (consolidation?.enabled) return pursue(consolidation, 'Consolidate the genuinely won local transport objective');
      if (battle && !/已经获胜/.test(battle.reason ?? '')) {
        const target = battle.command.command.nodeId;
        if (count(battle) >= POLICY.battleAttemptsPerNode) return stop('FINITE_PLANNED_BATTLE_ATTEMPTS', 'Four genuine prepared attempts at this objective are exhausted; retain every loss');
        const prepared = prepare('Recover the real body before this planned encounter', { health: 90, mind: 90, spirituality: 30, uninjured: true, actions: 1 });
        if (prepared) return prepared;
        const recon = all.find(a => a.command.type === 'CAMPAIGN' && nestedType(a) === 'RECONNOITRE' && a.command.command.nodeId === target);
        if (!section(view, 'campaign-planning').includes('本次侦察仍对应当前守军：实际检定加值8，只用于该守军的下一次交战。')) {
          if (!recon) return stop('PUBLIC_RECON_ROUTE_UNAVAILABLE', 'No scoped public reconnaissance action is available at the current actual objective');
          if (recon.enabled) return choose(recon, 'Perform one real target-scoped reconnaissance, paying the published original treasuries, supplies and week');
          if (/行动|费用|灵性/.test(recon.reason ?? '')) return pursue(recon, 'Recover the actual resources needed for scoped reconnaissance');
          return stop('FINITE_PLANNING_RESOURCE_EXHAUSTED', recon.reason ?? 'Reconnaissance is blocked by finite resources or live target conditions');
        }
        if (!section(view, 'campaign-planning').includes('已生效方案：三军协同；会战时额外投入每军6补给。方案仅用于本次交战，打完不会自动沿用。')) {
          const selection = all.find(a => a.command.type === 'CAMPAIGN' && nestedType(a) === 'SELECT_BATTLE_PLAN' && a.command.command.nodeId === target && a.command.command.stance === POLICY.plannedStance && a.command.command.extraSupplies === true);
          if (!selection) return stop('PUBLIC_COORDINATED_PLAN_UNAVAILABLE', 'The predetermined coordinated full-supply public plan is not offered');
          if (selection.enabled) return choose(selection, 'Select the precommitted coordinated plan with six actual extra supplies per army after live eligibility and paid reconnaissance');
          if (/行动|费用|灵性/.test(selection.reason ?? '')) return pursue(selection, 'Recover the live personal resources for the selected coordinated plan');
          return stop('FINITE_COORDINATED_PLAN_BLOCKED', selection.reason ?? 'The publicly visible coordinated plan requirements are not met');
        }
      }
      if (battle?.enabled) {
        if (count(battle) >= POLICY.battleAttemptsPerNode) { policy.stopAfterWithdrawal = 'Finite attempts at the same real battle are exhausted'; continue; }
        return pursue(battle, 'Fight the actual opposing legion at this independent objective', { health: 90, mind: 90, spirituality: 30, uninjured: true });
      }
      if (march?.enabled) return pursue(march, 'March along the next enabled real route after local consolidation');
      const resourceBlocked = [battle, consolidation, march].find(a => a && /行动|费用|灵性|休养|重伤/.test(a.reason ?? ''));
      if (resourceBlocked) return pursue(resourceBlocked, `Recover actual resources for ${resourceBlocked.label}`, { health: 90, mind: 90, spirituality: 30, uninjured: true });
      const reinforcement = enabled.find(a => a.command.type === 'CAMPAIGN' && nestedType(a) === 'REORGANIZE');
      if (reinforcement) return pursue(reinforcement, 'Use the remaining legal finite reinforcement when forward action is blocked');
      const pending = all.some(a => a.command.type === 'CAMPAIGN' && nestedType(a) === 'REORGANIZE' && /仍在途中/.test(a.reason ?? ''));
      if (pending) return support('Wait for the actual already-dispatched reinforcement convoy');
      policy.stopAfterWithdrawal = 'No enabled forward route, objective or finite reinforcement remains'; continue;
    }
    if (policy.phase === 'POSTWAR') {
      const footReturn = definition.postwarFootReturn ? all.find(a => a.command.type === 'RETURN_ON_FOOT') : null;
      if (footReturn) {
        const paidReturn = enabled.find(a => a.command.type === 'TRAVEL' && a.command.to === 'loen-headquarters');
        if (paidReturn) return choose(paidReturn, 'Use the affordable real paid return route after actual armistice, retaining the original armies at their postwar station');
        if (footReturn.enabled) return choose(footReturn, 'Walk the actual postwar return route without advance fare; pay real extra weeks and living debts while the original armies remain stationed');
        return support('Wait for a legal public postwar return action', { actions: 1 });
      }
      // Failure may leave real recoverable original boxes, or permanently lose
      // them. Treat the actual living patient before considering another bottle.
      const preparation = prepare('Recover actual postwar or failed-consumption injuries', { ...atFullHealth, actions: 1, cash: injuryCount(view) ? 60 : 0 });
      if (preparation) return preparation;
      const next = materials(true); if (next) return next;
      const consumption = all.find(a => a.command.type === 'CONSUME');
      if (consumption) {
        const preparation = all.find(a => a.command.type === 'STABILIZE_PROMOTION' && a.command.compoundId === consumption.command.compoundId);
        if (!preparation) return stop('PUBLIC_STABILITY_UNAVAILABLE', 'The current actual compound has no public stability action; never drink an unprepared substitute');
        const bound = !preparation.enabled && preparation.reason === '本瓶已有一次稳定准备；不能重复付费叠加或转给另一瓶。'
          && section(view, 'promotion-stability').some(line => line.includes('已生效稳定加值35，仅用于此份原成药的下一次服用'));
        if (!bound) {
          if (!preparation.enabled && !/行动|费用|灵性|精神|健康|伤势|恢复/.test(preparation.reason ?? ''))
            return stop('PUBLIC_STABILITY_BINDING_BLOCKED', preparation.reason ?? 'No eligible same-compound preparation remains');
          return pursue(preparation, 'Pay for the real one-week, same-compound stability preparation; preserve every prior failed dose and its RNG',
            { ...atFullHealth, mind: Math.max(atFullHealth.mind, definition.minimumMindBeforeStability), actions: 2, cash: 150, spirituality: 42 });
        }
        return pursue(consumption, 'Drink this same actually stabilized compound once after ordinary recovery, accepting its genuine result', atFullHealth);
      }
      const compound = all.find(a => a.command.type === 'MATERIAL' && nestedType(a) === 'PREPARE_COMPOUND');
      if (compound) return pursue(compound, 'Consume one finite ordinary supply pack to prepare the original materials');
      const destinations = all.filter(a => a.command.type === 'TRAVEL' && ['backlund:sealed-compounding-room', 'loen-headquarters'].includes(a.command.to));
      const travel = destinations.find(a => a.enabled) ?? destinations.find(a => a.command.to === 'loen-headquarters') ?? destinations[0];
      return travel ? pursue(travel, 'Transport the actual originals along the public return route to the workshop')
        : stop('POSTWAR_PUBLIC_ROUTE_UNAVAILABLE', 'No legal public preparation or transport action remains');
    }
    if (policy.phase === 'RESCUE') {
      const epilogue = enabled.filter(a => a.command.type === 'EPILOGUE');
      // A real rescue, not an ability checklist. With the inherited 3 AP,
      // START leaves 2: attempt coordination, then carry the actual patients.
      // Never sacrifice the only remaining evacuation action to test flame.
      for (const type of ['COORDINATE', 'EVACUATE', 'REPORT', 'CONTAIN_FIRE', 'WITHDRAW']) {
        const action = epilogue.find(a => nestedType(a) === type);
        if (type === 'CONTAIN_FIRE' && epilogue.some(a => nestedType(a) === 'EVACUATE')) continue;
        if (action) return choose(action, type === 'WITHDRAW' ? 'Ordinarily withdraw when the remaining real rescue actions are unavailable' : `Resolve the one actual return-route rescue: ${action.label}`);
      }
      if (section(view, 'epilogue').length) return stop('NATURAL_RESCUE_REPORTED', 'The actual rescue/withdrawal and casualties have been reported');
      const preparation = prepare('Recover before returning to the original route for coordination and actual evacuation', { ...atFullHealth, actions: 3 });
      if (preparation) return preparation;
      const start = find('START_PREPARED_EPILOGUE');
      if (start) return choose(start, 'Explicitly open the prepared version2 rescue at the original postwar location; pay its ordinary one-action entry and real six-person detachment');
      const travel = all.find(a => a.command.type === 'TRAVEL');
      return travel ? pursue(travel, 'Actually traverse the original continent route back to the postwar legion') : stop('RESCUE_ROUTE_UNAVAILABLE', 'No public route or real detachment is available');
    }
  }
  return stop('PUBLIC_POLICY_PHASE_BLOCKED', 'No bounded phase transition produced an enabled action');
}
export function advancePolicy(decision, publicAfter, commandCount) {
  const policy = clone(decision.policy), key = commandKey(decision.action.command);
  const command = decision.action.command.command;
  if (decision.action.command.type === 'CAMPAIGN') {
    if (command.type === 'RECONNOITRE') policy.reconNode = command.nodeId;
    if (command.type === 'SELECT_BATTLE_PLAN') policy.selectedPlanNode = command.nodeId;
    if (['MARCH', 'RETURN_TO_HEADQUARTERS', 'BATTLE', 'PREPARED_BATTLE', 'RELEASE_AUTHORITY'].includes(command.type)) { policy.reconNode = null; policy.selectedPlanNode = null; }
  }
  policy.attempts[key] = (policy.attempts[key] ?? 0) + 1;
  assert(policy.materialCycle, 'The exact retained command history must establish the material cycle');
  if (decision.action.command.type === 'CONSUME') policy.materialCycle = { startedAfterCommand: commandCount, attempts: {} };
  else if (decision.action.command.type === 'MATERIAL' && command?.type !== 'PREPARE_COMPOUND')
    policy.materialCycle.attempts[key] = (policy.materialCycle.attempts[key] ?? 0) + 1;
  const progress = progressSignature(publicAfter), unchanged = policy.lastProgress === progress;
  const supportAction = ['REST', 'WORK', 'CLINIC', 'NEXT_WEEK'].includes(decision.action.command.type)
    || decision.action.command.command?.type === 'MILITARY_LABOUR';
  policy.supportSinceProgress = unchanged && supportAction ? policy.supportSinceProgress + 1 : 0;
  // Wage/health progress makes another weekly cycle meaningful. Pure consecutive
  // waiting on an unchanged public problem remains bounded.
  policy.unchangedWaits = unchanged && decision.action.command.type === 'NEXT_WEEK' ? policy.unchangedWaits + 1 : 0;
  policy.lastProgress = progress; return policy;
}
function verifyBoundary(cp, root, prefixHash, freeze, fork, expectedPolicy = POLICY, stabilitySeam = null) {
  assert.equal(cp.format, FORMAT); assert.equal(cp.prefixCount, FORK_COUNT);
  assert.equal(cp.source, SOURCE); assert.equal(cp.sourceSha256, SOURCE_SHA256); assert.equal(cp.prefixSha256, prefixHash);
  assert.equal(cp.freezeSha256, freeze.sha256); assert.deepEqual(cp.policyDefinition, expectedPolicy); assert.deepEqual(cp.fork, fork);
  assert.equal(cp.initialStateSha256, root.finalStateSha256); assert.equal(cp.commandCount,FORK_COUNT+cp.commands.length);
  assert.equal(cp.rows.length,cp.commands.length); assert.equal(cp.state.revision,root.state.revision+cp.commands.length);
  assert.equal(cp.finalStateSha256,stateHash(cp.state)); assert.deepEqual(cp.state.random.seed,root.state.random.seed);
  let previousState=root.finalStateSha256,previousRandom=root.state.random,previousPublic=cp.initialPublicStateSha256;
  const attempts={};
  for(const [i,row] of cp.rows.entries()) {
    if (stabilitySeam && i === 219) { assert.equal(previousPublic, STABILITY_PIN.publicSha256); previousPublic = stabilitySeam.continuedPublicSha256; }
    assert.equal(row.commandCount,FORK_COUNT+i+1);assert.equal(row.revision,root.state.revision+i+1);assert.deepEqual(row.intent,cp.commands[i]);
    assert.equal(row.commandSha256,compactHash(row.intent));assert.equal(row.beforeStateSha256,previousState);assert.deepEqual(row.randomBefore,previousRandom);
    assert.equal(row.publicBeforeSha256,previousPublic);assert.equal(row.randomAfter.seed,root.state.random.seed);
    previousState=row.afterStateSha256;previousRandom=row.randomAfter;previousPublic=row.publicAfterSha256;
    const key=commandKey(row.intent.command);attempts[key]=(attempts[key]??0)+1;
  }
  if (stabilitySeam && cp.rows.length === 219) { assert.equal(previousPublic, STABILITY_PIN.publicSha256); previousPublic = stabilitySeam.continuedPublicSha256; }
  assert.equal(previousState,cp.finalStateSha256);assert.deepEqual(previousRandom,cp.state.random);assert.equal(previousPublic,cp.publicStateSha256);
  assert.deepEqual(attempts,cp.policy.attempts);
  if (stabilitySeam) assert.deepEqual(cp.policy.materialCycle, materialCycleFromCommands(cp.commands));
  if(cp.pending) {assert.equal(cp.pending.commandCount,cp.commandCount+1);assert.equal(cp.pending.beforeStateSha256,cp.finalStateSha256);assert.equal(cp.pending.publicBeforeSha256,cp.publicStateSha256);assert.deepEqual(cp.pending.intent,{type:'RED_PRIEST',command:cp.pending.decision.action.command});}
}

function readBranchInputs(options, old, freeze) {
  const rootPath=join(options.forkDirectory,'original-918-checkpoint.json'),proofPath=join(options.forkDirectory,'reconstruction-proof.json');
  const wrapped=JSON.parse(readFileSync(rootPath,'utf8')),root=wrapped.payload,proof=JSON.parse(readFileSync(proofPath,'utf8'));
  assert.equal(fileEvidence(rootPath).sha256,'2ab728663f4ce0096a94e49279a5feadda378f64629dd4ec6ccff785db60c68b');assert.equal(fileEvidence(proofPath).sha256,'398f3854fc323bc106f58b0133cf702cce1a9b234bca850ccc416a21570611c5');
  assert.equal(wrapped.sha256,stateHash(root));assert.equal(root.format,'RED_PRIEST_EXACT_PREDECLARATION918_BRANCH_ROOT_V1');assert.equal(root.commandCount,FORK_COUNT);
  assert.equal(root.finalStateSha256,'779ef84dfc74b9abbfe1e97c9bff206c683a9b18d3957d6603661f9748b38acd');
  assert.equal(root.publicStateSha256,'361cc87eba7713bdf66752b17fd298350d558e5be2f10e30e8419fb67f172d91');
  assert.equal(root.originalRuntimeFreezeSha256,'be967f07d9a912627b5c21fb1746247b4d2ba3797ee1dce532108748e1eeb11e');
  assert.equal(root.sourceSha256,SOURCE_SHA256);assert.equal(root.prefixSha256,ORIGINAL_PREFIX_SHA256);assert.equal(root.commands.length,123);assert.equal(root.rows.length,123);
  assert.equal(stateHash(root.state),root.finalStateSha256);assert.deepEqual(root.state.random,{seed:old.seed,cursor:423});
  assert.equal(root.state.redPriest.campaign.phase,'CRISIS');assert.equal(root.state.redPriest.campaign.declaration,null);assert.equal(root.state.redPriest.campaign.planning,undefined);
  assert.equal(proof.allPrivatePublicAndRngEqual,true);assert.equal(proof.strictFinalValidation,true);assert.deepEqual(fileEvidence(rootPath),proof.checkpoint);
  assert.deepEqual(proof.checks.map(r=>r.commandCount),[916,917,918]);assert.equal(proof.expectedStateSha256,root.finalStateSha256);assert.equal(proof.expectedPublicSha256,root.publicStateSha256);
  for(const entry of proof.original983.files)assert.deepEqual(fileEvidence(join(options.archiveDirectory,entry.path)),{bytes:entry.bytes,sha256:entry.sha256},`Sealed original983 ${entry.path}`);
  assert.equal(proof.original983.files.length,57,'Complete original983 archive required');
  assert.equal(proof.original983.manifestEvidence.sha256,'24d971395d08ca7b031d51d79c17a75681ccf7e3fe78a076f79b84f917acf909');
  const sealed=JSON.parse(readFileSync(join(options.archiveDirectory,'checkpoint.json'),'utf8'));assert.equal(sealed.sha256,stateHash(sealed.payload));assert.equal(sealed.payload.commandCount,983);assert.equal(sealed.payload.terminal.stage,'FINITE_CAMPAIGN_WITHDRAWN');assert.equal(sealed.sha256,'91ca947ee1b0903d3d63296827d9db4004ee0f077a357bccd11ffa35fdb03c85');assert.deepEqual(root.commands,sealed.payload.commands.slice(0,123));assert.deepEqual(root.rows,sealed.payload.rows.slice(0,123));
  assert.equal(fileEvidence(options.equivalenceProof).sha256,'9f64e510ace5f5f484ad2869a8bc616c668231ac345383695740a4edd065a3c3','The reviewed complete original983 planning-equivalence proof is required');
  const equivalent=JSON.parse(readFileSync(options.equivalenceProof,'utf8'));
  assert.equal(equivalent.format,'RED_PRIEST983_PLANNING_TRANSITION_V1');
  const runtimeFiles=freeze.files.filter(e=>e.file!=='$natural-producer');
  assert.deepEqual(equivalent.currentRuntimeFreeze.files.filter(e=>e.file!=='$natural-producer'),runtimeFiles,'Historical equivalence must use the exact current frozen runtime');
  assert.equal(equivalent.currentRuntimeFreeze.sha256,compactHash(equivalent.currentRuntimeFreeze.files));assert.equal(equivalent.currentRuntimeFreeze.sha256,'a7e68d0887485e05bc55779eda3db46512fad01e8a67b67babace7f8ae3e3cd7');
  assert.equal(equivalent.replay.commands,188);assert.equal(equivalent.replay.first,796);assert.equal(equivalent.replay.last,983);
  assert.equal(equivalent.replay.allPrivateAndRngEqual,true);assert.equal(equivalent.replay.rows.length,188);
  const originalProducer=options.archiveProducer??(existsSync(join(options.archiveDirectory,'producer.mjs'))?join(options.archiveDirectory,'producer.mjs'):resolve(proof.original983.producer.path));
  assert.deepEqual(fileEvidence(originalProducer),{bytes:proof.original983.producer.bytes,sha256:proof.original983.producer.sha256},'Archived original983 producer must remain exact');
  const prefixCommands=[...old.commands,...root.commands],prefixHash=compactHash(prefixCommands);
  return {root,proof,equivalent,prefixCommands,prefixHash,rootEvidence:fileEvidence(rootPath),proofEvidence:fileEvidence(proofPath),equivalenceEvidence:fileEvidence(options.equivalenceProof)};
}

/** Observation budgets are scoped to actual recovery episodes, not reset by waiting.
 * Every prior attempt remains in policy.attempts and the original219 rows. */
export function materialCycleFromCommands(commands) {
  let cycle = { startedAfterCommand: FORK_COUNT, attempts: {} };
  for (const [i, intent] of commands.entries()) {
    const command = intent.command;
    if (command.type === 'CONSUME') cycle = { startedAfterCommand: FORK_COUNT + i + 1, attempts: {} };
    else if (command.type === 'MATERIAL' && command.command.type !== 'PREPARE_COMPOUND') {
      const key = commandKey(command); cycle.attempts[key] = (cycle.attempts[key] ?? 0) + 1;
    }
  }
  return cycle;
}
export function assertStabilityPolicy(originalPolicy, continuedPolicy) {
  assert.equal(originalPolicy.id, 'RED_PRIEST_PREDECLARE918_COORDINATED_FULL_PREPARATION_V1');
  assert.deepEqual(continuedPolicy, { ...originalPolicy,
    id: 'RED_PRIEST1137_STABLE_POSTWAR_CONTINUATION_V1',
    materialAttemptScope: 'SINCE_LAST_ACTUAL_CONSUMPTION',
    promotionPreparation: 'REQUIRE_SAME_COMPOUND_PAID_STABILITY',
    minimumMindBeforeStability: 78, preparedEpilogue: true,
  }, 'Only the reviewed future postwar policy may differ; all old budgets and strategies remain fixed');
}
export function assertStabilityPin(pin) { assert.deepEqual(pin, STABILITY_PIN, 'Only the exact sealed command1137 observation may be continued'); }
export function parseOptions(args) {
  const options = { out: null, resume: null, forkDirectory: null, archiveDirectory: null, archiveProducer: null,
    equivalenceProof: null, continueFrom: null, priorProducer: null, stabilityEquivalenceProof: null,
    stabilityEquivalenceSha256: null, maxNew: Infinity, preflight: false };
  const paths = { '--out': 'out', '--resume': 'resume', '--fork-directory': 'forkDirectory', '--archive-directory': 'archiveDirectory',
    '--archive-producer': 'archiveProducer', '--equivalence-proof': 'equivalenceProof', '--continue-from': 'continueFrom',
    '--prior-producer': 'priorProducer', '--stability-equivalence-proof': 'stabilityEquivalenceProof' };
  for (let i = 0; i < args.length; i++) {
    const flag = args[i]; if (flag === '--preflight') { assert(!options.preflight); options.preflight = true; continue; }
    const value = args[++i]; assert(value !== undefined, `Missing ${flag}`);
    if (paths[flag]) { assert.equal(options[paths[flag]], null); options[paths[flag]] = resolve(value); }
    else if (flag === '--stability-equivalence-sha256') { assert.equal(options.stabilityEquivalenceSha256, null); assert(/^[a-f0-9]{64}$/.test(value)); options.stabilityEquivalenceSha256 = value; }
    else if (flag === '--max-new') { assert.equal(options.maxNew, Infinity); assert(/^\d+$/.test(value)); options.maxNew = Number(value); assert(Number.isSafeInteger(options.maxNew)); }
    else throw Error(`Unsupported option ${flag}; no seed, resources, success, history or strategy override exists`);
  }
  for (const key of ['forkDirectory', 'archiveDirectory', 'equivalenceProof', 'continueFrom', 'priorProducer', 'stabilityEquivalenceProof', 'stabilityEquivalenceSha256'])
    assert(options[key], `${key} is required`);
  if (options.resume) { assert(!options.out || options.out === dirname(options.resume)); options.out = dirname(options.resume); }
  if (!options.preflight) assert(options.out, 'Explicit new output directory required');
  for (const source of [options.continueFrom, options.archiveDirectory, options.forkDirectory])
    if (options.out) assert(options.out !== source && !options.out.startsWith(source + sep), 'Continuation must remain outside every immutable historical input');
  return options;
}
export function runtimeDifference(before, after) {
  const previous = new Map(before.filter(e => e.file !== '$natural-producer').map(e => [e.file, e]));
  const next = new Map(after.filter(e => e.file !== '$natural-producer').map(e => [e.file, e]));
  return [...new Set([...previous.keys(), ...next.keys()])].flatMap(file => {
    const a = previous.get(file), b = next.get(file);
    if (isDeepStrictEqual(a, b)) return [];
    const evidence = entry => entry ? { bytes: entry.bytes, sha256: entry.sha256 } : null;
    return [{ file, before: evidence(a), after: evidence(b) }];
  });
}
export function assertFrozenTransition(priorFreeze, freeze, transition) {
  assert.equal(priorFreeze.sha256, STABILITY_PIN.freezeSha256); assert.equal(compactHash(priorFreeze.files), priorFreeze.sha256);
  assert.equal(freeze.sha256, compactHash(freeze.files));
  assert.deepEqual(priorFreeze.files.map(e => e.file), freeze.files.map(e => e.file), 'Frozen source/runtime inventory may not add or remove files');
  assert.deepEqual(transition.currentRuntimeFreeze.files, freeze.files.filter(e => e.file !== '$natural-producer'), 'Every live source and runtime byte must match the independent219 replay');
  assert.equal(transition.currentRuntimeFreeze.sha256, compactHash(transition.currentRuntimeFreeze.files));
  assert.deepEqual(runtimeDifference(priorFreeze.files, freeze.files), transition.changedFiles, 'Only the precise independently proved source/runtime files may change');
  assert(transition.changedFiles.length > 0, 'The reviewed future-action implementation must be present');
  assert.equal(transition.originalFreezeSha256, priorFreeze.sha256);
}
function readStabilityPrior(options) {
  assert.deepEqual(readdirSync(options.continueFrom).sort(), STABILITY_PIN.files.map(e => e.path).sort(), 'Original1137 must retain precisely its seven sealed files');
  for (const entry of STABILITY_PIN.files) assert.deepEqual(fileEvidence(join(options.continueFrom, entry.path)), { bytes: entry.bytes, sha256: entry.sha256 }, `Immutable original1137 changed: ${entry.path}`);
  assert.deepEqual(fileEvidence(options.priorProducer), { bytes: STABILITY_PIN.producer.bytes, sha256: STABILITY_PIN.producer.sha256 }, 'The original1137 producer must remain byte-exact');
  const wrapped = decodeCheckpoint(readFileSync(join(options.continueFrom, 'checkpoint.json'), 'utf8')), prior = wrapped.payload;
  assert.equal(wrapped.sha256, STABILITY_PIN.checkpointPayloadSha256); assert.equal(prior.commandCount, 1137);
  assert.equal(prior.commands.length, 219); assert.equal(prior.rows.length, 219); assert.equal(prior.pending, null);
  assert.equal(prior.finalStateSha256, STABILITY_PIN.stateSha256); assert.equal(prior.publicStateSha256, STABILITY_PIN.publicSha256);
  assert.equal(stateHash(prior.state), prior.finalStateSha256); assert.deepEqual(prior.state.random, STABILITY_PIN.random);
  assert.equal(prior.state.status, 'ACTIVE'); assert.equal(prior.state.progression.sequence, 1);
  assert.deepEqual(prior.terminal, { stage: 'FINITE_MATERIAL_ATTEMPTS', reason: 'Finite attempts exhausted for 完成原件保管交接' });
  assertStabilityPolicy(prior.policyDefinition, POLICY);
  const priorFreeze = JSON.parse(readFileSync(join(options.continueFrom, 'freeze.json'), 'utf8'));
  assert.equal(priorFreeze.sha256, STABILITY_PIN.freezeSha256); assert.equal(compactHash(priorFreeze.files), priorFreeze.sha256);
  assert.deepEqual(priorFreeze.files.find(e => e.file === '$natural-producer'), { file: '$natural-producer', bytes: STABILITY_PIN.producer.bytes, sha256: STABILITY_PIN.producer.sha256 });
  const runtimeProofBytes = readFileSync(join(options.continueFrom, 'runtime-transition.json'), 'utf8');
  const continuationProofBytes = readFileSync(join(options.continueFrom, 'continuation.json'), 'utf8');
  assert.equal(sha(runtimeProofBytes), prior.fork.runtimeProofSha256); assert.equal(sha(continuationProofBytes), prior.continuation.proofSha256);
  assert.deepEqual(prior.continuation, { proofFile: 'continuation.json', proofSha256: 'a99965211e755af3b18ab8165a14ad8e7297d30975c9c95552e5b8a94954c199', originalCommandCount: 1017 });
  assert.equal(readFileSync(join(options.continueFrom, 'commands.ndjson'), 'utf8'), prior.rows.map(row => JSON.stringify(row)).join('\n') + '\n');
  const natural = JSON.parse(readFileSync(join(options.continueFrom, 'natural.json'), 'utf8'));
  assert.deepEqual(natural.final, prior.state); assert.deepEqual(natural.policy, prior.policyDefinition);
  assert.equal(natural.stage, prior.terminal.stage); assert.equal(natural.reason, prior.terminal.reason);
  return { wrapped, prior, priorFreeze, runtimeProofBytes, continuationProofBytes, natural };
}
function readStabilityTransition(options, original, freeze) {
  assert(/^[a-f0-9]{64}$/.test(REVIEWED_STABILITY_PROOF_SHA256 ?? ''), 'Independent219 equivalence proof is not yet sealed; no game was loaded');
  assert.equal(options.stabilityEquivalenceSha256, REVIEWED_STABILITY_PROOF_SHA256, 'Unreviewed transition proof is forbidden');
  const evidence = fileEvidence(options.stabilityEquivalenceProof);
  assert.equal(evidence.sha256, REVIEWED_STABILITY_PROOF_SHA256, 'The reviewed independent219 transition proof must be byte-exact');
  const transition = JSON.parse(readFileSync(options.stabilityEquivalenceProof, 'utf8'));
  assert.equal(transition.format, 'RED_PRIEST1137_STABILITY_TRANSITION_V1');
  assertFrozenTransition(original.priorFreeze, freeze, transition);
  assert.deepEqual(transition.source1137.checkpoint, fileEvidence(join(options.continueFrom, 'checkpoint.json')));
  assert.equal(transition.source1137.payloadSha256, original.wrapped.sha256);
  for (const [field, expected] of Object.entries({ stateSha256: STABILITY_PIN.stateSha256, publicSha256: STABILITY_PIN.publicSha256, random: STABILITY_PIN.random }))
    assert.deepEqual(transition.source1137[field], expected);
  assert.equal(transition.stateSha256, STABILITY_PIN.stateSha256); assert.deepEqual(transition.random, STABILITY_PIN.random);
  assert.equal(transition.originalPublicSha256, STABILITY_PIN.publicSha256);
  assert(/^[a-f0-9]{64}$/.test(transition.continuedPublicSha256));
  assert.equal(transition.replay.commands, 219); assert.equal(transition.replay.first, 919); assert.equal(transition.replay.last, 1137);
  assert.equal(transition.replay.allPrivateAndRngEqual, true); assert.equal(transition.replay.allExistingPublicFieldsEqual, true); assert.equal(transition.replay.rows.length, 219);
  return { transition, evidence };
}
function verifyStabilityPrefix(cp, original, continuation) {
  assert.deepEqual(cp.stabilityContinuation, continuation); assert.deepEqual(cp.continuation, original.continuation); assert.deepEqual(cp.fork, original.fork);
  assert(cp.commandCount >= 1137); assert.deepEqual(cp.commands.slice(0, 219), original.commands); assert.deepEqual(cp.rows.slice(0, 219), original.rows);
  if (cp.rows.length > 219) { const row = cp.rows[219]; assert.equal(row.commandCount, 1138); assert.equal(row.beforeStateSha256, original.finalStateSha256); assert.deepEqual(row.randomBefore, original.state.random); }
}
export async function main(args = process.argv.slice(2)) {
  const options = parseOptions(args), rootDirectory = process.cwd();
  const old = readSource(rootDirectory), freeze = inspectFreeze(rootDirectory), stamps = stampFreeze(rootDirectory, freeze);
  const original = readStabilityPrior(options), inputs = readBranchInputs(options, old, original.priorFreeze), forkRoot = inputs.root;
  verifyBoundary(original.prior, forkRoot, inputs.prefixHash, original.priorFreeze, original.prior.fork, original.prior.policyDefinition);
  assert.deepEqual(original.natural.commands, [...inputs.prefixCommands, ...original.prior.commands]);
  assert.equal(original.prior.fork.rootSha256, inputs.rootEvidence.sha256); assert.equal(original.prior.fork.proofSha256, inputs.proofEvidence.sha256);
  const { transition, evidence } = readStabilityTransition(options, original, freeze);
  const policy = { ...clone(original.prior.policy), materialCycle: materialCycleFromCommands(original.prior.commands) };
  assert.equal(policy.materialCycle.startedAfterCommand, 1114);
  const continuationProof = { format: 'RED_PRIEST1137_STABILITY_CONTINUATION_V1', originalCapture: STABILITY_PIN,
    originalPolicyDefinition: original.prior.policyDefinition, continuedPolicyDefinition: POLICY, originalPolicyState: original.prior.policy,
    originalTerminal: original.prior.terminal, originalRowsSha256: compactHash(original.prior.rows), originalCommandsSha256: compactHash(original.prior.commands),
    priorFork: original.prior.fork, priorContinuation: original.prior.continuation, newFreezeSha256: freeze.sha256,
    runtimeTransition: { proofFile: relative(rootDirectory, options.stabilityEquivalenceProof).split(sep).join('/'), proofSha256: evidence.sha256 } };
  const continuationProofBytes = JSON.stringify(continuationProof);
  const stabilityContinuation = { proofFile: 'stability-continuation.json', proofSha256: sha(continuationProofBytes), originalCommandCount: 1137 };
  if (options.preflight) { console.log(JSON.stringify({ passed: true, continuedFrom: 1137, freezeSha256: freeze.sha256, producerSha256: fileEvidence(SELF).sha256,
    original1137Intact: true, original219RowsAndCommandsRetained: true, original983Intact: true, noRuntimeImported: true,
    privateStateSha256: STABILITY_PIN.stateSha256, random: STABILITY_PIN.random, originalPublicSha256: STABILITY_PIN.publicSha256,
    continuedPublicSha256: transition.continuedPublicSha256, materialCycle: policy.materialCycle, stabilityContinuation })); return; }
  mkdirSync(options.out, { recursive: true }); const checkpointPath = options.resume ?? join(options.out, 'checkpoint.json');
  const runtime = await loadRuntime(rootDirectory);
  let saved, session, stage = null, reason = null, committedThisInvocation = 0;
  if (options.resume) {
    recoverAtomicNext(checkpointPath); saved = decodeCheckpoint(readFileSync(checkpointPath, 'utf8'));
    assert.deepEqual(JSON.parse(readFileSync(join(options.out, 'freeze.json'), 'utf8')), freeze);
    assert.equal(readFileSync(join(options.out, 'runtime-transition.json'), 'utf8'), original.runtimeProofBytes);
    assert.equal(readFileSync(join(options.out, 'continuation.json'), 'utf8'), original.continuationProofBytes);
    assert.equal(readFileSync(join(options.out, 'stability-continuation.json'), 'utf8'), continuationProofBytes);
    verifyBoundary(saved.payload, forkRoot, inputs.prefixHash, freeze, original.prior.fork, POLICY, transition);
    verifyStabilityPrefix(saved.payload, original.prior, stabilityContinuation);
    session = runtime.openRedPriestRuntimeSession(saved.payload.state);
    if (saved.payload.terminal) { stage = saved.payload.terminal.stage; reason = saved.payload.terminal.reason; }
  } else {
    assert.equal(readdirSync(options.out).length, 0, 'Use a separate empty continuation directory; never overwrite an observation');
    session = runtime.openRedPriestRuntimeSession(original.prior.state);
    assert.equal(stateHash(session.snapshot()), original.prior.finalStateSha256, 'New runtime must preserve the exact1137 private state');
    assert.deepEqual(session.snapshot().random, STABILITY_PIN.random);
    assert.equal(stateHash(session.projectRedPriest()), transition.continuedPublicSha256, 'New1137 public projection must equal the independent proof');
    durableCreate(join(options.out, 'freeze.json'), JSON.stringify(freeze));
    durableCreate(join(options.out, 'runtime-transition.json'), original.runtimeProofBytes);
    durableCreate(join(options.out, 'continuation.json'), original.continuationProofBytes);
    durableCreate(join(options.out, 'stability-continuation.json'), continuationProofBytes);
    saved = saveCheckpoint(checkpointPath, { ...original.prior, freezeSha256: freeze.sha256, policyDefinition: POLICY, policy,
      publicStateSha256: transition.continuedPublicSha256, stabilityContinuation, terminal: null }, null);
    assert.deepEqual(saved.payload.state, original.prior.state); assert.deepEqual(saved.payload.policy.attempts, original.prior.policy.attempts);
    verifyStabilityPrefix(saved.payload, original.prior, stabilityContinuation);
  }
  try {
    assert.equal(stateHash(session.projectRedPriest()), saved.payload.publicStateSha256);
    while (!stage) {
      unchangedSinceFreeze(stamps); const boundary = saved.payload;
      if (boundary.state.status !== 'ACTIVE') { stage = 'NATURAL_ACTUAL_TERMINAL'; reason = `Actual ${boundary.state.status}`; break; }
      if (!boundary.pending && committedThisInvocation >= options.maxNew) { stage = 'MANUAL_PAUSE_COMPLETED_ACTION_BOUNDARY'; reason = 'Requested action-boundary pause'; break; }
      if (!boundary.pending && boundary.commands.length >= POLICY.maximumNewCommands) { stage = 'FINITE_COMMAND_BUDGET'; reason = 'The bounded public planned-campaign policy is exhausted'; break; }
      let pending = boundary.pending;
      if (!pending) {
        const view = session.projectRedPriest(), decision = chooseAction(view, boundary.policy, POLICY);
        if (decision.stop) { stage = decision.stop; reason = decision.reason; break; }
        assert.notEqual(decision.action.command.command?.type, 'BATTLE', 'Never replace the planned campaign with an ordinary battle');
        assert.notEqual(decision.action.command.type, 'START_EPILOGUE', 'The continuation opts in only through the explicit prepared opening');
        pending = { commandCount: boundary.commandCount + 1, intent: { type: 'RED_PRIEST', command: clone(decision.action.command) }, decision,
          beforeStateSha256: boundary.finalStateSha256, publicBeforeSha256: stateHash(view), startedAt: new Date().toISOString() };
        saved = saveCheckpoint(checkpointPath, { ...boundary, pending }, saved.sha256);
      }
      const view = session.projectRedPriest(), offered = view.actions.find(a => isDeepStrictEqual(a.command, pending.intent.command));
      assert(offered?.enabled); assert.equal(stateHash(view), pending.publicBeforeSha256);
      const before = saved.payload.state, started = performance.now(), draft = session.prepare(pending.intent, before.revision);
      const next = session.snapshotDraft(draft), after = session.projectDraftRedPriest(draft);
      assert.equal(next.revision, before.revision + 1); checkOriginals(next, old);
      const row = { commandCount: pending.commandCount, intent: clone(pending.intent), commandSha256: compactHash(pending.intent),
        reason: pending.decision.reason, publicLabel: offered.label, startedAt: pending.startedAt, elapsedMilliseconds: Math.round(performance.now() - started),
        revision: next.revision, beforeStateSha256: pending.beforeStateSha256, afterStateSha256: stateHash(next), publicBeforeSha256: pending.publicBeforeSha256,
        publicAfterSha256: stateHash(after), randomBefore: clone(before.random), randomAfter: clone(next.random) };
      saved = saveCheckpoint(checkpointPath, { ...saved.payload, state: next, finalStateSha256: row.afterStateSha256, publicStateSha256: row.publicAfterSha256,
        commandCount: pending.commandCount, commands: [...saved.payload.commands, clone(pending.intent)], rows: [...saved.payload.rows, row],
        policy: advancePolicy(pending.decision, after, pending.commandCount), pending: null }, saved.sha256);
      session.commit(draft); committedThisInvocation++;
      console.log(JSON.stringify({ completed: pending.commandCount, action: offered.label, week: next.week, sequence: next.progression.sequence, milliseconds: row.elapsedMilliseconds }));
    }
    unchangedSinceFreeze(stamps); assert.deepEqual(inspectFreeze(rootDirectory), freeze);
    verifyBoundary(saved.payload, forkRoot, inputs.prefixHash, freeze, original.prior.fork, POLICY, transition);
    verifyStabilityPrefix(saved.payload, original.prior, stabilityContinuation); checkOriginals(saved.payload.state, old);
    readStabilityPrior(options); readStabilityTransition(options, original, freeze);
    runtime.assertValidSliceState(saved.payload.state);
    const strict = runtime.openRedPriestRuntimeSession(saved.payload.state);
    assert.equal(stateHash(strict.snapshot()), saved.payload.finalStateSha256); assert.equal(stateHash(strict.projectRedPriest()), saved.payload.publicStateSha256);
    for (const entry of inputs.proof.original983.files) assert.deepEqual(fileEvidence(join(options.archiveDirectory, entry.path)), { bytes: entry.bytes, sha256: entry.sha256 });
    const paused = stage === 'MANUAL_PAUSE_COMPLETED_ACTION_BOUNDARY';
    if (!paused && !saved.payload.terminal) saved = saveCheckpoint(checkpointPath, { ...saved.payload, terminal: { stage, reason } }, saved.sha256);
    const finalView = session.projectRedPriest();
    replaceDerived(join(options.out, 'commands.ndjson'), saved.payload.rows.map(row => JSON.stringify(row)).join('\n') + '\n');
    const provenance = { ...original.natural.provenance, runtimeFreezeSha256: freeze.sha256, stabilityContinuation };
    replaceDerived(join(options.out, 'natural.json'), JSON.stringify({ provenance, creation: old.creation, seed: old.seed, prefixCount: FORK_COUNT,
      commands: [...inputs.prefixCommands, ...saved.payload.commands], initial: old.initial, policy: POLICY, stage, reason, pendingIntent: null, final: saved.payload.state }));
    replaceDerived(join(options.out, 'summary.json'), JSON.stringify({ stage, reason, commands: saved.payload.commandCount, originalCommands: FORK_COUNT,
      newCommands: saved.payload.commands.length, stabilityNewCommands: saved.payload.commandCount - 1137, paused, strictFinalValidation: true,
      branch: 'Same original918 planning branch continued from the exact sealed1137 observation; both original failed doses and all prior costs preserved',
      public: { title: finalView.title, promoted: finalView.promoted, nextStep: finalView.nextStep, resources: finalView.resources, abilities: finalView.abilities, sections: finalView.sections } }));
    console.log(JSON.stringify({ outputDir: options.out, stage, commands: saved.payload.commandCount, paused }));
    return { outputDir: options.out, stage, commands: saved.payload.commandCount, paused };
  } catch (error) {
    try { replaceDerived(join(options.out, 'error.json'), JSON.stringify({ stage: 'CAPTURE_INTERRUPTED', error: String(error), checkpoint: checkpointPath,
      resumeExactPendingRequired: true, commandCount: saved?.payload.commandCount ?? null, at: new Date().toISOString() })); } catch {}
    throw error;
  }
}
if (process.argv[1] && resolve(process.argv[1]) === SELF) await main();
