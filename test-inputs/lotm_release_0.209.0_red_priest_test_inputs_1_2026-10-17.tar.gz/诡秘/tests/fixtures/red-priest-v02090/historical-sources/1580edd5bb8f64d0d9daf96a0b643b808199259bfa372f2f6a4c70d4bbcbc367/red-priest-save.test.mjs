import assert from 'node:assert/strict';
import test from 'node:test';
import { createHash } from 'node:crypto';
import { argumentsForSave, assertFreeze, assertProducerOnlyFreezeChange, assertOriginalLedgerPrefix, assertContinuationPolicy, assertAuthorityContinuationPolicy, assertContinuationOrder, assertLogisticsPolicy, restoreBeforeLogistics, assertLogisticsReplayRows, assertLogisticsFreeze, assertRestorationPolicy, restoreBeforeRestoration, assertRestorationFreeze, assertRestorationReplayRows, assertPublicChain, assertResumeManifest, selectBoundaries, stateHash } from './red-priest-save.mjs';

// Small pure helper tests only: no producer, game/dist, source fixture, SQLite,
// filesystem writes, synthetic play, or natural-death claim.
const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const row = (file, digit) => ({ file, bytes: 5, sha256: digit.repeat(64) });
const freeze = files => ({ files, sha256: hash(files) });

test('freeze binds all exact ordered rows without runtime exceptions', () => {
  const original = freeze([row('src/a.ts', 'a'), row('dist/a.js', 'b'), row('$natural-producer', 'c')]);
  assertFreeze(original, structuredClone(original));
  for (const changed of [freeze([...original.files].reverse()), freeze(original.files.slice(1)), freeze([...original.files, row('extra', 'd')]),
    freeze(original.files.map(r => ({ ...r, bytes: 6 }))), { ...original, sha256: '0'.repeat(64) }, freeze([...original.files, original.files[0]])])
    assert.throws(() => assertFreeze(original, changed));
});

test('resume binds complete input hashes, runtime, source, verifier and selection', () => {
  const manifest = { source: row('natural.json', 'a'), verifier: row('verifier', 'b'), inputs: [row('checkpoint.json', 'c')], freeze: freeze([row('dist', 'd')]), selected: [{ commandCount: 796, names: ['guidance'] }] };
  assertResumeManifest(manifest, structuredClone(manifest));
  for (const key of Object.keys(manifest)) assert.throws(() => assertResumeManifest(manifest, { ...manifest, [key]: null }));
  assert.throws(() => assertResumeManifest(manifest, { ...manifest, extra: true }));
});

function sample() {
  const commands = [{ type: 'LEARN_GUIDANCE' }, { type: 'MATERIAL', command: { type: 'RECOVER' } },
    { type: 'TRAVEL', to: 'actual-destination' }, { type: 'CAMPAIGN', command: { type: 'BATTLE', nodeId: 'actual-node' } },
    { type: 'CAMPAIGN', command: { type: 'BATTLE', nodeId: 'actual-node' } },
    { type: 'CONSUME', compoundId: 'actual-compound', confirmed: true }];
  const rows = commands.map((command, i) => ({ commandCount: 796 + i, revision: 797 + i, intent: { type: 'RED_PRIEST', command } }));
  const journal = rows.slice(1).map(r => ({ revision: r.revision, command: r.intent.command }));
  journal[2].campaignHost = { receipt: { kind: 'BATTLE', result: 'FAILURE' } };
  journal[3].campaignHost = { receipt: { kind: 'BATTLE', result: 'GREAT_SUCCESS' } };
  journal[4].materialReceipt = { consumption: { outcome: 'FAILURE', compoundId: 'actual-compound' } };
  return { rows, journal };
}

test('actual unique indices merge multiple boundary names and retain both battle outcomes', () => {
  const { rows, journal } = sample(), { selected, coverage } = selectBoundaries(rows, journal);
  assert.equal(selected.length, 6); assert.equal(new Set(selected.map(r => r.commandCount)).size, 6);
  assert.deepEqual(selected[3].names, ['command:CAMPAIGN:BATTLE', 'battle:failure']);
  assert.deepEqual(selected[4].names, ['battle:success']);
  assert.deepEqual(selected[5].names, ['command:CONSUME', 'consume:FAILURE', 'final-actual-transition']);
  assert.equal(coverage['command:CAMPAIGN:BATTLE'], 2); assert.equal(coverage['consume:SUCCESS'], undefined);
});

test('every material and epilogue command kind present gets a real representative', () => {
  const commands = [{ type: 'LEARN_GUIDANCE' }, ...['A', 'B', 'A'].map(type => ({ type: 'MATERIAL', command: { type } })),
    { type: 'EPILOGUE', command: { type: 'REPORT' } }];
  const rows = commands.map((command, i) => ({ commandCount: 796 + i, revision: 797 + i, intent: { type: 'RED_PRIEST', command } }));
  const journal = rows.slice(1).map(r => ({ revision: r.revision, command: r.intent.command }));
  const result = selectBoundaries(rows, journal); assert.equal(result.selected.length, 4);
  assert.deepEqual(result.selected.map(r => r.commandCount), [796, 797, 798, 800]);
  assert.equal(result.coverage['command:MATERIAL:A'], 2);
});

test('cannot fabricate journal boundaries, outcomes or consumption identity', () => {
  const a = sample(); a.journal[0].command = { type: 'REST' }; assert.throws(() => selectBoundaries(a.rows, a.journal));
  const b = sample(); b.journal[2].campaignHost.receipt.result = 'INVENTED'; assert.throws(() => selectBoundaries(b.rows, b.journal));
  const c = sample(); c.journal[4].materialReceipt.consumption.compoundId = 'different'; assert.throws(() => selectBoundaries(c.rows, c.journal));
  const d = sample(); d.journal.push(d.journal[0]); assert.throws(() => selectBoundaries(d.rows, d.journal));
  assert.throws(() => selectBoundaries([], []));
});

test('stable state hashes are order independent but preserve all values', () => {
  assert.equal(stateHash({ b: [2, 1], a: { y: 2, x: 1 } }), stateHash({ a: { x: 1, y: 2 }, b: [2, 1] }));
  assert.notEqual(stateHash({ b: [1, 2] }), stateHash({ b: [2, 1] }));
});

test('CLI requires exact explicit stale PID and rejects ambiguous or duplicate routes', () => {
  assert.deepEqual(argumentsForSave(['--source-directory', 'capture', '--preflight']), { sourceDirectory: 'capture', preflight: true });
  assert.equal(argumentsForSave(['--resume-directory', 'prior', '--remove-stale-lock-pid', '123']).removeStaleLockPid, 123);
  for (const args of [['--remove-stale-lock-pid', '0'], ['--remove-stale-lock-pid', 'NaN'], ['--resume-directory', 'x', '--output-directory', 'y'], ['--preflight', '--preflight'], ['--source-directory'], ['--unknown', 'x']])
    assert.throws(() => argumentsForSave(args));
});


test('continuation changes only producer bytes, never source, product or compiled rules', () => {
  const before = freeze([row('src/rules.ts', 'a'), row('dist/rules.js', 'b'), row('$natural-producer', 'c')]);
  const after = freeze([before.files[0], before.files[1], row('$natural-producer', 'd')]);
  assertProducerOnlyFreezeChange(before, after);
  for (const changed of [before, freeze([row('src/rules.ts', 'e'), ...after.files.slice(1)]), freeze([...after.files].reverse()),
    freeze([...after.files, row('dist/extra.js', 'f')]), freeze(after.files.slice(1))])
    assert.throws(() => assertProducerOnlyFreezeChange(before, changed));
});

test('continuation retains original complete ledger bytes exactly once as prefix', () => {
  const original = Buffer.from('{"commandCount":796}\n{"commandCount":797}\n');
  assertOriginalLedgerPrefix(Buffer.concat([original, Buffer.from('{"commandCount":798}\n')]), original);
  assert.throws(() => assertOriginalLedgerPrefix(Buffer.from('{"commandCount":796}\n'), original));
  assert.throws(() => assertOriginalLedgerPrefix(Buffer.from(' '+original.toString()), original));
  assert.throws(() => assertOriginalLedgerPrefix(original, original.subarray(0, -1)));
});


test('continuation permits only approved material cap six to twelve without other policy changes', () => {
  const before = { id: 'same', attemptsPerMaterialOperation: 6, maximumNewCommands: 900, noReroll: true };
  const after = { ...before, attemptsPerMaterialOperation: 12 }; assertContinuationPolicy(before, after);
  for (const changed of [{ ...after, attemptsPerMaterialOperation: 13 }, { ...after, maximumNewCommands: 1800 }, { ...after, noReroll: false }, { ...after, extra: true }])
    assert.throws(() => assertContinuationPolicy(before, changed));
});


test('authority continuation changes only cumulative authority five to twelve', () => {
  const before = { id: 'same', attemptsPerMaterialOperation: 12, authorityAttemptsPerPolity: 5, maximumNewCommands: 900, noReroll: true };
  const after = { ...before, authorityAttemptsPerPolity: 12 }; assertAuthorityContinuationPolicy(before, after);
  for (const changed of [{ ...after, authorityAttemptsPerPolity: 13 }, { ...after, attemptsPerMaterialOperation: 6 }, { ...after, maximumNewCommands: 1800 }, { ...after, noReroll: false }])
    assert.throws(() => assertAuthorityContinuationPolicy(before, changed));
  assert.throws(() => assertAuthorityContinuationPolicy({ ...before, authorityAttemptsPerPolity: 6 }, after));
});

test('only exact836,915,941,974 observations are permitted in their fixed ancestor order', () => {
  assertContinuationOrder(836); assertContinuationOrder(915); assertContinuationOrder(941); assertContinuationOrder(974); assertContinuationOrder(836, 836); assertContinuationOrder(915, 915);
  for (const count of [795, 837, 914, 916, 973, 975, null, '915']) assert.throws(() => assertContinuationOrder(count));
  assert.throws(() => assertContinuationOrder(915, 836)); assert.throws(() => assertContinuationOrder(941, 915));
});

test('all120 prior915 ledger rows are retained without a changed or truncated prefix', () => {
  const original = Buffer.from(Array.from({ length: 120 }, (_, i) => JSON.stringify({ commandCount: 796 + i })).join('\n')+'\n');
  assertOriginalLedgerPrefix(Buffer.concat([original, Buffer.from('{"commandCount":916}\n')]), original);
  assert.throws(() => assertOriginalLedgerPrefix(Buffer.from(original.toString().replace('"commandCount":900', '"commandCount":901')), original));
  assert.throws(() => assertOriginalLedgerPrefix(original.subarray(0, original.length - 1), original));
});


test('logistics policy adds only the explicit recovery flag without resetting limits', () => {
  const before = { attemptsPerMaterialOperation: 12, authorityAttemptsPerPolity: 12, battleAttemptsPerNode: 4, armisticeAttempts: 5 };
  assertLogisticsPolicy(before, { ...before, logisticsRecovery: true });
  for (const after of [{ ...before, logisticsRecovery: false }, { ...before, logisticsRecovery: true, battleAttemptsPerNode: 5 }, { ...before, logisticsRecovery: true, extra: true }])
    assert.throws(() => assertLogisticsPolicy(before, after));
});

const returnAction = () => ({ command: { type: 'CAMPAIGN', command: { type: 'RETURN_TO_HEADQUARTERS' } }, label: '沿原路回总部整备', enabled: true });
test('old-public restoration removes only one exact appended return action without mutation', () => {
  const old = { title: 'public', actions: [{ command: { type: 'REST' }, label: 'rest', enabled: true }] };
  const next = { ...old, actions: [...old.actions, returnAction()] };
  assert.deepEqual(restoreBeforeLogistics(next), old); assert.equal(next.actions.length, 2);
  assert.deepEqual(restoreBeforeLogistics(old), old);
  for (const actions of [[returnAction(), ...old.actions], [...next.actions, returnAction()], [...old.actions, { ...returnAction(), label: 'other' }]])
    assert.throws(() => restoreBeforeLogistics({ ...old, actions }));
  const changed = { ...next, title: 'changed old field' }; assert.notEqual(stateHash(restoreBeforeLogistics(changed)), stateHash(old));
});

function logisticsRows() {
  const rows = Array.from({ length: 146 }, (_, i) => ({ commandCount: 796 + i, afterStateSha256: stateHash(i), publicAfterSha256: stateHash({ old: i }), randomAfter: { seed: 'fixed', cursor: i } }));
  const proof = { continuedPublicSha256: stateHash({ new: 145 }), replay: { commands: 146, first: 796, last: 941, allPrivateAndRngEqual: true,
    publicDifference: 'Only appended RETURN_TO_HEADQUARTERS action', addedProjectionChecks: 18,
    rows: rows.map((r, i) => ({ commandCount: r.commandCount, stateSha256: r.afterStateSha256, capturedPublicSha256: r.publicAfterSha256, publicSha256: stateHash({ new: i }), random: r.randomAfter })) } };
  return { rows, proof };
}
test('941 proof binds all146 exact private, RNG and captured/current public hashes', () => {
  const { rows, proof } = logisticsRows(); assertLogisticsReplayRows(proof, rows);
  for (const field of ['stateSha256', 'capturedPublicSha256', 'commandCount', 'random']) {
    const changed = structuredClone(proof); changed.replay.rows[81][field] = null; assert.throws(() => assertLogisticsReplayRows(changed, rows));
  }
  const short = structuredClone(proof); short.replay.rows.pop(); assert.throws(() => assertLogisticsReplayRows(short, rows));
  const outcome = structuredClone(proof); outcome.replay.allPrivateAndRngEqual = false; assert.throws(() => assertLogisticsReplayRows(outcome, rows));
});

test('941 freeze admits exactly six reviewed runtime files plus producer, never broad exclusions', () => {
  const paths = ['src/domain/red-priest/campaign.ts', 'src/domain/red-priest/index.ts', 'dist/domain/red-priest/campaign.js', 'dist/domain/red-priest/campaign.js.map', 'dist/domain/red-priest/index.js', 'dist/domain/red-priest/index.js.map'];
  const changes = paths.map(file => ({ file, before: { bytes: 5, sha256: 'a'.repeat(64) }, after: { bytes: 6, sha256: 'b'.repeat(64) } }));
  const before = freeze([...changes.map(c => ({ file: c.file, ...c.before })), row('$natural-producer', 'c'), row('src/untouched.ts', 'd')]);
  const after = freeze([...changes.map(c => ({ file: c.file, ...c.after })), row('$natural-producer', 'e'), row('src/untouched.ts', 'd')]);
  assertLogisticsFreeze(before, after, changes);
  assert.throws(() => assertLogisticsFreeze(before, freeze([...after.files.slice(0, -1), row('src/untouched.ts', 'f')]), changes));
  assert.throws(() => assertLogisticsFreeze(before, after, changes.slice(1)));
  assert.throws(() => assertLogisticsFreeze(before, after, [...changes].reverse()));
  const wrong = structuredClone(changes); wrong[0].after.bytes++; assert.throws(() => assertLogisticsFreeze(before, after, wrong));
});


test('974 policy adds only explicit recovery flags and exact verified-personnel exit', () => {
  const before = { logisticsRecovery: true, attemptsPerMaterialOperation: 12, authorityAttemptsPerPolity: 12, battleAttemptsPerNode: 4, armisticeAttempts: 5 };
  const after = { ...before, fieldArmyRecovery: true, finiteSupplyRecovery: true, postwarFootReturn: true, verifiedPersonnelExit: '现有人员已经不足以完成剩余目标。继续交战不能补回损失，可以真实停战或保护撤离。' }; assertRestorationPolicy(before, after);
  for (const changed of [{ ...after, fieldArmyRecovery: false }, { ...after, finiteSupplyRecovery: false }, { ...after, postwarFootReturn: false }, { ...after, verifiedPersonnelExit: 'any warning' }, { ...after, battleAttemptsPerNode: 5 }, { ...after, extra: true }])
    assert.throws(() => assertRestorationPolicy(before, changed));
});

test('974 freeze binds exactly twelve approved source, runtime and renderer files', () => {
  const paths = ['src/domain/red-priest/campaign.ts', 'src/domain/red-priest/engine.ts', 'src/domain/red-priest/index.ts', 'src/domain/red-priest/types.ts', 'src/renderer/RedPriestPanel.tsx', 'src/renderer/SliceApp.tsx', 'dist/domain/red-priest/campaign.js', 'dist/domain/red-priest/campaign.js.map', 'dist/domain/red-priest/engine.js', 'dist/domain/red-priest/engine.js.map', 'dist/domain/red-priest/index.js', 'dist/domain/red-priest/index.js.map'];
  const changes = paths.map(file => ({ file, before: { bytes: 5, sha256: 'a'.repeat(64) }, after: { bytes: 6, sha256: 'b'.repeat(64) } }));
  const before = freeze([...changes.map(c => ({ file: c.file, ...c.before })), row('$natural-producer', 'c'), row('src/untouched.ts', 'd')]);
  const after = freeze([...changes.map(c => ({ file: c.file, ...c.after })), row('$natural-producer', 'e'), row('src/untouched.ts', 'd')]);
  assertRestorationFreeze(before, after, changes);
  assert.throws(() => assertRestorationFreeze(before, freeze([...after.files.slice(0, -1), row('src/untouched.ts', 'f')]), changes));
  for (const bad of [changes.slice(0, 6), [...changes].reverse(), changes.map((c, i) => i === 6 ? { ...c, before: { ...c.before, bytes: 8 } } : c)])
    assert.throws(() => assertRestorationFreeze(before, after, bad));
  assert.throws(() => assertLogisticsFreeze(before, after, changes));
});

test('974 proof binds all179 private/RNG hashes and both historical public eras without gaps', () => {
  const rows = Array.from({ length: 179 }, (_, i) => ({ commandCount: 796 + i, afterStateSha256: stateHash(i), publicAfterSha256: stateHash({ era: i < 146 ? 'original' : 'return', i }), randomAfter: { seed: 'fixed', cursor: i } }));
  const proof = { continuedPublicSha256: stateHash({ new: 178 }), originalPublicSha256: rows.at(-1).publicAfterSha256, replay: { commands: 179, first: 796, last: 974, allPrivateAndRngEqual: true,
    publicDifference: 'Only appended recovery actions and campaign-readiness section; historical RETURN_TO_HEADQUARTERS projection preserved', addedProjectionChecks: 382,
    rows: rows.map((r, i) => ({ commandCount: r.commandCount, priorRuntimePublicSha256: i < 146 ? stateHash({ return: i }) : r.publicAfterSha256, stateSha256: r.afterStateSha256, capturedPublicSha256: r.publicAfterSha256, publicSha256: stateHash({ new: i }), random: r.randomAfter })) } };
  assertRestorationReplayRows(proof, rows);
  for (const index of [0, 145, 146, 178]) for (const field of ['stateSha256', 'capturedPublicSha256', 'priorRuntimePublicSha256', 'commandCount', 'random']) {
    const changed = structuredClone(proof); changed.replay.rows[index][field] = null; assert.throws(() => assertRestorationReplayRows(changed, rows));
  }
  for (const changed of [{ ...proof, replay: { ...proof.replay, rows: proof.replay.rows.slice(1) } }, { ...proof, replay: { ...proof.replay, addedProjectionChecks: 0 } }])
    assert.throws(() => assertRestorationReplayRows(changed, rows));
});

test('public chain rejects undeclared seams and any change outside the exact941 seam', () => {
  const old = '86f1b384408032f77881fd95db91a22c36079cdd45fce3c57901047e4cda09f0', next = 'c87ae3523ad27e645baf837a845579f7a223eb9b2c0c428562e0b0c6be9db5db';
  const previous = { publicAfterSha256: old }, row = { commandCount: 942, publicBeforeSha256: next };
  const lineage = { original: { commandCount: 941 }, runtimeTransition: { commandCount: 941, proofSha256: '3dbc170abff8c7310dd384677469a19d9f9e217a0653dfe8d6a78a18587b4b66', originalPublicSha256: old, continuedPublicSha256: next } };
  assertPublicChain(previous, row, lineage);
  assert.throws(() => assertPublicChain(previous, row));
  assert.throws(() => assertPublicChain(previous, { ...row, commandCount: 943 }, lineage));
  assert.throws(() => assertPublicChain(previous, { ...row, publicBeforeSha256: stateHash('unapproved') }, lineage));
  assert.throws(() => assertPublicChain(previous, row, { ...lineage, runtimeTransition: { ...lineage.runtimeTransition, proofSha256: stateHash('unapproved') } }));
});


test('974 restoration removes only exact ordered recovery suffix and public readiness section', () => {
  const old = { actions: [returnAction()], sections: [{ id: 'existing', title: 'existing', lines: ['retained'] }] };
  const rest = { command: { type: 'CAMPAIGN', command: { type: 'REST_FIELD_ARMIES' } }, label: '让总部原军休整', enabled: true };
  const supply = { command: { type: 'CAMPAIGN', command: { type: 'SUPPLY_ONLY', polityId: 'loen' } }, label: '运输鲁恩原库存补给', enabled: false };
  const section = { id: 'campaign-readiness', title: '胜算与有限兵员', lines: ['public current readiness'] };
  const next = { actions: [...old.actions, rest, supply], sections: [...old.sections, section] };
  assert.deepEqual(restoreBeforeRestoration(next), old); assert.equal(next.actions.length, 3); assert.equal(next.sections.length, 2);
  const foot = { command: { type: 'RETURN_ON_FOOT' }, label: '停战后沿原路步行返总部', enabled: true };
  assert.deepEqual(restoreBeforeRestoration({ actions: [...old.actions, foot], sections: old.sections }), old);
  for (const actions of [[rest, ...old.actions], [...old.actions, supply, rest], [...next.actions, supply], [...old.actions, { ...rest, label: 'other' }], [...old.actions, { ...supply, command: { type: 'CAMPAIGN', command: { type: 'SUPPLY_ONLY', polityId: 'unapproved' } } }]])
    assert.throws(() => restoreBeforeRestoration({ ...next, actions }));
  assert.throws(() => restoreBeforeRestoration({ ...next, sections: [...next.sections, section] }));
  assert.throws(() => restoreBeforeRestoration({ ...next, sections: [{ ...section, extra: 'private' }] }));
  const changed = { ...next, sections: [{ ...old.sections[0], lines: ['changed existing data'] }, section] };
  assert.notEqual(stateHash(restoreBeforeRestoration(changed)), stateHash(old));
});


test('974 inherited941 and new974 public seams are independently fixed and cannot move', () => {
  const inheritedRuntimeTransition = { commandCount: 941, proofSha256: '3dbc170abff8c7310dd384677469a19d9f9e217a0653dfe8d6a78a18587b4b66',
    originalPublicSha256: '86f1b384408032f77881fd95db91a22c36079cdd45fce3c57901047e4cda09f0', continuedPublicSha256: 'c87ae3523ad27e645baf837a845579f7a223eb9b2c0c428562e0b0c6be9db5db' };
  const runtimeTransition = { commandCount: 974, proofSha256: 'c5fa12707cde98bba0a775475d274c369f68267fe5d2991e5a04acaabb3ad201',
    originalPublicSha256: '89b59e830d4ca6bdfee64c6edc990fa8ea032b0ae553c313880679ef5ee7f3c4', continuedPublicSha256: '2b45e65b382e3aaf98e945347ea752294cdc3a26899f867272388f96d5c3b205' };
  const lineage = { original: { commandCount: 974 }, inheritedRuntimeTransition, runtimeTransition };
  for (const seam of [inheritedRuntimeTransition, runtimeTransition]) {
    const before = { publicAfterSha256: seam.originalPublicSha256 }, after = { commandCount: seam.commandCount + 1, publicBeforeSha256: seam.continuedPublicSha256 };
    assertPublicChain(before, after, lineage);
    assert.throws(() => assertPublicChain(before, { ...after, commandCount: after.commandCount + 1 }, lineage));
    assert.throws(() => assertPublicChain(before, { ...after, publicBeforeSha256: stateHash('drift') }, lineage));
  }
  const before = { publicAfterSha256: runtimeTransition.originalPublicSha256 }, after = { commandCount: 975, publicBeforeSha256: runtimeTransition.continuedPublicSha256 };
  assert.throws(() => assertPublicChain(before, after, { ...lineage, runtimeTransition: { ...runtimeTransition, proofSha256: inheritedRuntimeTransition.proofSha256 } }));
});
