import assert from 'node:assert/strict';

export const PLANNING_ACTIVATION = Object.freeze({
  command: { type: 'CAMPAIGN', command: { type: 'ENABLE_PLANNING' } },
  label: '启用本场战争筹备',
  cost: '不花行动、时间或费用；须在签发发动命令前选择，之后每次侦察和保护性准备照实支付，不能补写过去战果',
});

/** The sole allowed current-vs-pre-planning difference for historical states.
 * No existing public field, section, action, action ID, or value is ignored. */
export function stripPlanningActivation(view, state) {
  const root = state.redPriest, campaign = root?.campaign, frame = root?.frame;
  if (campaign) assert(!Object.hasOwn(campaign, 'planning'), 'Historical states must not acquire a planning property');
  const expected = !!(frame && frame.budget.sequence === 1 && campaign?.phase === 'CRISIS'
    && !campaign.planning && frame.location === campaign.location);
  const found = view.actions.filter(a => a.command?.type === 'CAMPAIGN' && a.command.command?.type === 'ENABLE_PLANNING');
  assert.equal(found.length, expected ? 1 : 0, 'Activation availability must exactly match the reviewed CRISIS predicate');
  const prior = structuredClone(view);
  if (expected) {
    assert.equal(campaign.declaration, null, 'Activation cannot be offered after declaration');
    assert.equal(state.status, 'ACTIVE', 'This historical equivalence contract only admits the recorded living original');
    assert.deepEqual(view.actions.at(-1), {
      id: `red-priest-action-${view.actions.length}`,
      ...PLANNING_ACTIVATION,
      enabled: true,
      reason: null,
    }, 'Only the exact enabled, non-preferred, trailing activation action may be removed');
    prior.actions.pop();
  }
  return { prior, removed: expected ? 1 : 0 };
}
