"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.redPriestBudget = exports.RED_PRIEST_FROZEN_SOURCE_KEYS = void 0;
exports.redPriestHistoryDigest = redPriestHistoryDigest;
exports.redPriestAcquisitionSnapshot = redPriestAcquisitionSnapshot;
exports.redPriestSourceBlock = redPriestSourceBlock;
exports.createRedPriestSource = createRedPriestSource;
exports.redPriestSourceView = redPriestSourceView;
exports.validateRedPriestSource = validateRedPriestSource;
const index_js_1 = require("../conqueror/index.js");
const canonical_js_1 = require("../canonical.js");
const checksum_js_1 = require("../checksum.js");
const same = (a, b) => (0, canonical_js_1.stableStringify)(a) === (0, canonical_js_1.stableStringify)(b);
const digest = (value) => (0, checksum_js_1.sha256Hex)((0, canonical_js_1.stableStringify)(value));
/** Old living people and original equipment remain these exact historical
 * entities. New national armies never become replacements for this team. */
exports.RED_PRIEST_FROZEN_SOURCE_KEYS = [
    'hunter', 'provoker', 'pyromaniac', 'conspirator', 'reaper',
    'ironBloodKnight', 'warBishop', 'weatherWarlock', 'conqueror',
];
const redPriestBudget = (s) => ({
    week: s.week, date: structuredClone(s.date), actions: s.actionsRemaining, cash: s.cash,
    health: s.health, mind: s.mind, spirituality: s.spirituality, pollution: s.seer.pollution,
    injuries: structuredClone(s.injuries), injuryRisk: s.injuryRisk, status: s.status,
    sequence: s.progression.sequence, acting: s.progression.acting,
    mastery: { ...s.progression.mastery }, coreStats: { ...s.character.coreStats },
    completedSources: [...s.seer.completedSources],
});
exports.redPriestBudget = redPriestBudget;
function redPriestHistoryDigest(s) {
    return digest(Object.fromEntries(exports.RED_PRIEST_FROZEN_SOURCE_KEYS.map(key => [key, s[key]])));
}
function redPriestAcquisitionSnapshot(s) {
    if (s.conqueror.promotionWeek === null)
        throw Error('尚无真实征服者晋升记录。');
    return {
        bottles: structuredClone(s.conqueror.bottles),
        consumptions: structuredClone(s.conqueror.acquisitionJournal.filter(e => e.command.type === 'CONSUME')),
        promotionWeek: s.conqueror.promotionWeek,
    };
}
function redPriestSourceBlock(s) {
    if (s.progression.pathwayId !== 'hunter' || s.progression.sequence !== 1 || s.status !== 'ACTIVE')
        return '须由仍活着的征服者继续。';
    if (!(0, index_js_1.validateConquerorState)(s) || s.conqueror.promotionWeek === null)
        return '原晋升与实际军团、物品履历尚未通过核验。';
    if (s.progression.acting !== 100 || !s.conqueror.life.reflected)
        return '先完成征服者的真实实践、反思和消化。';
    if ((0, index_js_1.hasConquerorLock)(s) || s.combat || s.activeEvent || s.eventQueue.length || s.pulse !== 'NONE')
        return '先沿普通退路收束原现场，不得把未完成的交战带入新战争。';
    if (s.date.year < 1353)
        return '北大陆此次危机尚未进入当前年代，可先继续现有生活。';
    // This chapter has exactly three originals. A historical later-batch save is
    // readable, but cannot mint a fourth characteristic through this storyline.
    const bottles = s.conqueror.bottles;
    if (bottles.length !== 3 || bottles.some((b, i) => b.id !== `conqueror-potion-${i + 1}`))
        return '原特性来源与三份总量尚有未解决的冲突，须先查清，不能重复领料。';
    if (bottles.filter(b => b.status === 'CONSUMED' && (b.outcome === 'SUCCESS' || b.outcome === 'GREAT_SUCCESS')).length !== 1)
        return '本人实际整合的原特性尚未核清。';
    return null;
}
function createRedPriestSource(s) {
    const reason = redPriestSourceBlock(s);
    if (reason)
        throw Error(reason);
    const acquisition = redPriestAcquisitionSnapshot(s);
    return {
        runId: s.runId, actorId: `${s.runId}:original-player`, revision: s.revision,
        budget: (0, exports.redPriestBudget)(s), character: structuredClone(s.character),
        finance: structuredClone({ weeklyBudget: s.weeklyBudget, wagePaidWeek: s.wagePaidWeek,
            lifeTier: s.lifeTier, nextLifeTier: s.nextLifeTier, debts: s.debts, missedWeeks: s.missedWeeks, credit: s.credit }),
        random: { ...s.random }, historyDigest: redPriestHistoryDigest(s),
        combatHistoryLength: s.combatHistory.length, combatHistoryDigest: digest(s.combatHistory),
        originalWorldDigest: digest(s.world), acquisition, acquisitionDigest: digest(acquisition),
    };
}
/** Only a read-only predecessor view; no old bottle, ally, casualty or outcome
 * is rewritten when the current chapter advances time or changes the body. */
function redPriestSourceView(s, source) {
    const b = source.budget;
    return {
        ...s, ...structuredClone(source.finance), revision: source.revision, week: b.week,
        date: structuredClone(b.date), actionsRemaining: b.actions, cash: b.cash,
        health: b.health, mind: b.mind, spirituality: b.spirituality, status: 'ACTIVE',
        injuries: structuredClone(b.injuries), injuryRisk: b.injuryRisk,
        character: structuredClone(source.character), random: { ...source.random },
        progression: { ...s.progression, pathwayId: 'hunter', sequence: 1, acting: b.acting, mastery: { ...b.mastery } },
        seer: { ...s.seer, pollution: b.pollution, completedSources: [...b.completedSources] },
        combatHistory: s.combatHistory.slice(0, source.combatHistoryLength),
        combat: null, activeEvent: null, eventQueue: [], pulse: 'NONE', billAmount: 0, ending: null,
    };
}
function validateRedPriestSource(s, source) {
    try {
        // At the actual handoff, the proposed source must equal this exact live
        // predecessor, not a self-consistent replacement view with extra money or
        // a different random cursor. Later owned transitions seal this source.
        if (!s.redPriest.guidanceKnown && source.revision === s.revision)
            return same(createRedPriestSource(s), source);
        if (source.random.seed !== s.random.seed || source.random.cursor > s.random.cursor)
            return false;
        if (source.runId !== s.runId || source.actorId !== `${s.runId}:original-player` || source.revision > s.revision ||
            source.historyDigest !== redPriestHistoryDigest(s) || source.originalWorldDigest !== digest(s.world) ||
            source.combatHistoryDigest !== digest(s.combatHistory.slice(0, source.combatHistoryLength)) ||
            !same(source.acquisition, redPriestAcquisitionSnapshot(s)) || source.acquisitionDigest !== digest(source.acquisition))
            return false;
        return same(createRedPriestSource(redPriestSourceView(s, source)), source);
    }
    catch {
        return false;
    }
}
//# sourceMappingURL=source.js.map