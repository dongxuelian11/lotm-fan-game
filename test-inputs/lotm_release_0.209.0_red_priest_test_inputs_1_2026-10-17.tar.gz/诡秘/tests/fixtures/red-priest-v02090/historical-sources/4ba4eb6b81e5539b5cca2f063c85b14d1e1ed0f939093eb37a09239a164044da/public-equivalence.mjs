import assert from 'node:assert/strict';

export const ALLOWED_PUBLIC_CHANGES = Object.freeze([
  'APPENDED_STABILIZE_PROMOTION_PREPARED_COMPOUND_ACTIONS',
  'APPENDED_PROMOTION_STABILITY_PREPARED_COMPOUND_SECTION',
]);
const WORKSHOP = 'backlund:sealed-compounding-room';
const MATERIAL_IDS = ['conqueror-potion-1:characteristic', 'conqueror-potion-2:characteristic',
  'conqueror-potion-3:characteristic', 'red-priest-uniqueness:iron-crown-1126'];
const WITNESSES = [
  { polityId: 'loen', name: '鲁恩', legionId: 'loen-expedition', legionName: '鲁恩东境军团' },
  { polityId: 'intis', name: '因蒂斯', legionId: 'intis-expedition', legionName: '因蒂斯西境军团' },
  { polityId: 'feneport', name: '费内波特', legionId: 'feneport-expedition', legionName: '费内波特南境军团' },
];
const NODES = ['northern-pass', 'eastern-bridge', 'western-depot', 'southern-river', 'eastern-stores'];
const pass = receipt => ['SUCCESS', 'GREAT_SUCCESS'].includes(receipt?.result);

/** Independent expected values for this exact historical PREPARED window.
 * This deliberately does not call the new runtime preview or formatter. Any
 * history outside the sealed 219-command evidence fails instead of broadening
 * the normalization to arbitrary new fields or arbitrary blocked reasons. */
function expectedPreparation(root, compound) {
  const { frame, campaign, materials, source } = root, b = frame.budget;
  assert.equal(b.status, 'ACTIVE'); assert.equal(b.sequence, 1); assert.equal(b.acting, 100);
  assert.equal(root.promotionWeek, null); assert.equal(root.guidanceKnown, true);
  assert.equal(campaign.phase, 'ARMISTICE'); assert(campaign.declaration && campaign.firstCrossBorder && campaign.warStarted);
  assert.equal(campaign.opponentDisposition, 'CEASEFIRE');
  assert.equal(frame.location, WORKSHOP); assert.equal(compound.locationId, WORKSHOP);
  assert.equal(materials.status, 'ACTIVE'); assert.equal(compound.status, 'PREPARED');
  assert.deepEqual([compound.integratedMaterialId, ...compound.externalMaterialIds, compound.uniquenessId].sort(), [...MATERIAL_IDS].sort());
  assert.deepEqual(materials.items.map(item => item.id).sort(), [...MATERIAL_IDS].sort());
  for (const item of materials.items) {
    assert.equal(item.locationId, WORKSHOP); assert.equal(item.holderId, source.actorId);
    if (item.id === compound.integratedMaterialId) assert.equal(item.disposition, 'INTEGRATED_PLAYER');
    else { assert.equal(item.disposition, 'IN_COMPOUND'); assert.equal(item.containerId, compound.id); }
  }
  const witnesses = WITNESSES.map(expected => {
    const polity = campaign.polities[expected.polityId], legion = campaign.legions[expected.legionId];
    assert.equal(polity.authority, 'GRANTED'); assert.equal(legion.id, expected.legionId);
    assert.equal(legion.polityId, expected.polityId); assert(legion.personnel > 0); assert.equal(legion.retreated, false);
    const event = root.journal.find(entry => entry.id === polity.authorizationEventId);
    assert(event); assert.deepEqual(event.command, { type: 'CAMPAIGN', command: { type: 'REQUEST_AUTHORITY', polityId: expected.polityId } });
    assert.equal(event.before.location, 'loen-headquarters');
    const receipt = event.campaignHost.receipt;
    assert.equal(receipt.kind, 'AUTHORIZATION'); assert.equal(receipt.targetId, expected.polityId);
    assert.equal(receipt.eventId, event.id); assert.equal(receipt.campaignId, campaign.campaignId); assert(pass(receipt));
    assert(event.randomReceipts.some(entry => ['SUCCESS', 'GREAT_SUCCESS'].includes(entry.check.tier)));
    assert.deepEqual(receipt, campaign.journal.find(entry => entry.host.eventId === event.id)?.host.receipt);
    return { ...expected, personnel: legion.personnel };
  });
  assert.deepEqual(Object.values(campaign.nodes).filter(node => node.victory).map(node => node.id).sort(), [...NODES].sort());
  for (const nodeId of NODES) {
    const node = campaign.nodes[nodeId], victory = node.victory;
    assert.equal(node.consolidated, true); assert.equal(node.controller, 'coalition'); assert(node.battleCount > 0);
    assert.equal(campaign.legions[victory.defenderId].retreated, true);
    const event = root.journal.find(entry => entry.id === victory.eventId), receipt = event?.campaignHost?.receipt;
    assert(event && receipt); assert.equal(event.command.type, 'CAMPAIGN');
    assert(['BATTLE', 'PREPARED_BATTLE'].includes(event.command.command.type)); assert.equal(event.command.command.nodeId, nodeId);
    assert.equal(receipt.id, victory.receiptId); assert.equal(receipt.kind, 'BATTLE'); assert.equal(receipt.targetId, nodeId);
    assert.equal(receipt.campaignId, campaign.campaignId); assert(pass(receipt));
    assert(event.randomReceipts.some(entry => ['SUCCESS', 'GREAT_SUCCESS'].includes(entry.check.tier)));
  }
  for (const polity of Object.values(campaign.polities)) {
    assert(polity.mobilizedPersonnel > 0 && polity.treasurySpent > 0 && polity.transportLoads > 0 && polity.livelihoodLoss > 0);
  }
  const reason = b.health < 80 || b.mind < 70 || b.injuries.length > 0
    ? '先真正恢复到80健康、70精神并解除原伤势，再进行稳定准备。'
    : b.actions < 2 || b.cash < 120 || b.spirituality < 12
      ? '稳定准备需要2行动、120便士、12灵性与8精神，并实际经过一周。' : null;
  const chance = bonus => Math.max(5, Math.min(95, 50 + 2 * (b.coreStats.will + bonus - 55)));
  const currentChance = chance(0), stabilizedChance = chance(35);
  const lines = [
    `这份原成药当前服用成功率${currentChance}%；尚无已生效的战后稳定加值。失败仍可能重伤、增加污染或死亡。`,
    `若真实见证、原件、地点与资源条件均满足，并支付120便士、2行动、12灵性、8精神，实际经过1周完成稳定准备，取得仅本瓶一次的稳定加值35，按当前意志估计服用成功率${stabilizedChance}%；这是有条件的准备后估计，当前仍为${currentChance}%。`,
    '跨周照常结算生活费与旧还款，不自动恢复身体或返还过去失败的费用；也可以继续普通工作、休养，或自行决定承担未准备的服药风险。',
    ...(reason ? [`当前不能准备：${reason}`] : []),
    `已核实原战争独立胜利5处；原受托见证：${witnesses.map(w => `${w.name}的${w.legionName}（现员${w.personnel}）`).join('、')}。见证只据原委托、实际战果与原军团记录。`,
  ];
  return { reason, lines, currentChance, stabilizedChance };
}

export function stripHistoricalStabilityAdditions(view, state) {
  const root = state.redPriest;
  assert(!Object.hasOwn(root, 'promotionStability'), 'Old commands must never create a stability key');
  assert.equal(root.epilogue, null, 'This 219-command history has no epilogue scene');
  assert.equal(root.frame.budget.sequence, 1, 'Both historical consumptions failed and must not promote');
  assert.equal(root.promotionWeek, null); assert.equal(state.status, 'ACTIVE');
  const compounds = root.materials.status === 'ACTIVE' ? root.materials.compounds.filter(compound => compound.status === 'PREPARED') : [];
  const found = view.actions.filter(action => action.command?.type === 'STABILIZE_PROMOTION');
  assert.equal(found.length, compounds.length, 'No missing or extra prepared-compound action');
  assert.equal(view.actions.filter(action => ['START_PREPARED_EPILOGUE', 'OPEN_PREPARED_EPILOGUE'].includes(action.command?.type)).length, 0);
  assert.equal(view.sections.filter(section => ['epilogue-entry-readiness', 'epilogue-readiness'].includes(section.id)).length, 0);
  const sections = view.sections.filter(section => section.id === 'promotion-stability');
  assert.equal(sections.length, compounds.length ? 1 : 0, 'No missing or extra stability section');
  const prior = structuredClone(view), expectedActions = [], lines = [];
  for (let index = 0; index < compounds.length; index++) {
    const compound = compounds[index], expected = expectedPreparation(root, compound);
    lines.push(...expected.lines);
    expectedActions.push({ id: `red-priest-action-${view.actions.length - compounds.length + index + 1}`,
      command: { type: 'STABILIZE_PROMOTION', compoundId: compound.id }, label: '为这份原成药完成战后稳定准备',
      cost: '2行动、120便士、12灵性、8精神；实际1周，另结正常生活费与旧还款；只用于此份原成药的下一次服用',
      enabled: expected.reason === null, reason: expected.reason, ...(expected.reason === null ? { preferredAction: true } : {}) });
  }
  const expectedSections = compounds.length ? [{ id: 'promotion-stability', title: '这份原成药的服用风险与准备', lines }] : [];
  if (compounds.length) {
    assert.deepEqual(view.actions.slice(-compounds.length), expectedActions, 'Only exact new trailing actions may be removed');
    assert.deepEqual(view.sections.slice(-1), expectedSections, 'Only the exact new trailing section may be removed');
    prior.actions.splice(-compounds.length); prior.sections.pop();
  }
  return { prior, additions: { actions: expectedActions, sections: expectedSections }, actionsRemoved: compounds.length, sectionsRemoved: compounds.length ? 1 : 0 };
}
