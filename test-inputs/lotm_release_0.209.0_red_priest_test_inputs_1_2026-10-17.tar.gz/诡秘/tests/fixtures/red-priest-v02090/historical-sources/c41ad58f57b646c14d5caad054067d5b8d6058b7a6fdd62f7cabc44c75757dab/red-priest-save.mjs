import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { closeSync, existsSync, fsyncSync, lstatSync, mkdirSync, openSync, readFileSync, readdirSync, readSync, realpathSync, renameSync, rmSync, rmdirSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

// Import-safe verifier: no producer/game import, SQLite, replay or writes here.
// One sequential NEW-tail replay per invocation; original795 is never replayed.
// SQLite covers unique selected real transitions, not every historical command.
// A completed index is durable before DB cleanup. Unknown interrupted cases
// are retained and stop, never reset or claimed passed. No replay checkpoints.
const SELF = fileURLToPath(import.meta.url), FORMAT = 'RED_PRIEST209_SELECTED_SQLITE_AUDIT_V1';
const SOURCE = 'tests/fixtures/conqueror-v01870/natural.json', PREFIX = 795;
const SOURCE_SHA = '469a6ac77052f92ac0dbd8e6ea39164592de6b4c8d8ea0405b080c1a015f7973';
const PREFIX_SHA = '88211e592c4714058c3e8b45eab02fa0f0ae73b35c2526288503329ec1d52f2e';
const PRODUCER = 'scripts/play/red-priest-stage.mjs';
const INPUTS = ['checkpoint.json', 'commands.ndjson', 'freeze.json', 'natural.json', 'summary.json'];
// Only the four reviewed living836, living915, living941 and living974 observations may continue.
const ORIGINAL_FREEZE = '2d833ab92f7ca3ca5ffc7ada05d8f0b62f5538b9d73c3533c2a5cac8256e43f0';
const ORIGINAL_INPUTS = {
  'checkpoint.json': { bytes: 1994679, sha256: '42548cdae14c82d40c066524d4e560d57597259b2914f949b99f572881fc24fd' },
  'commands.ndjson': { bytes: 37130, sha256: '7b4ca7fff4db7e24d7a882705d87e5c91138332f60427cf0dc37ef5ea7705247' },
  'freeze.json': { bytes: 549730, sha256: 'bc155d14878f26516e7c27e4248174b70c50c24b3713f1ee3db20688606ee11b' },
  'natural.json': { bytes: 3999700, sha256: '299852d1d271e33531db5456a60797c81cd43ca21a51df6ea72c64870a3ce988' },
  'summary.json': { bytes: 8904, sha256: 'ef0e44a4b747e608f91788d226cd95f4a1f75434680f85294499c0f22c513607' },
};
const AUTHORITY_INPUTS = {
  'checkpoint.json': { bytes: 2827692, sha256: '34b88f24f49b8977e8445d6b4b79c2213ca622e598054980b7ada3c663780beb' },
  'commands.ndjson': { bytes: 107858, sha256: '9c7895aeba9c4e210fb1c4842a6aee29758a4972e3bf1a4aabcc6e2f7b055f55' },
  'freeze.json': { bytes: 549730, sha256: '2f4779ed6fe48f8a1b5f11bfae7378160bba6eeff29eb95e136860230f0850a1' },
  'natural.json': { bytes: 4760983, sha256: 'de517f04ce6eec4e1c33f0b9678c478867d556d0923100708cd6fffc3caa4da1' },
  'summary.json': { bytes: 8957, sha256: '0fbe1a19830227cb35fbcfa0bd8db3ad987253cbe541bd4fb106535712cb7dca' },
};
const LOGISTICS_INPUTS = {
  'checkpoint.json': { bytes: 3151328, sha256: '287f4290b38649d7d90a1c87a9ee38c7e73dda40b5f2ca2c1621f873d286ee4f' },
  'commands.ndjson': { bytes: 130732, sha256: '4c9c8b2952d881c87c3595edc7d43b29e8a032fe18fe3b997475bf8d726521fe' },
  'freeze.json': { bytes: 549730, sha256: '842f0c30841178918294ebba9ebed4f76d907a4fc8c33fe2ed8b4e77ba047935' },
  'natural.json': { bytes: 5061123, sha256: '990b93bddb1374f35da9d5de2761eeb6867379d469f8e2edc8ae94ffbac0b71e' },
  'summary.json': { bytes: 9038, sha256: '2971902254edec100b6f0fe08595d675a69a9f17d6c523ffe65f351d72731db3' },
};
const RESTORATION_INPUTS = {
  'checkpoint.json': { bytes: 3553388, sha256: 'ea1d6d03ef8f129ea5c0d14300cd3dbe88a4a20c4d506b729443e54242089ec6' },
  'commands.ndjson': { bytes: 160040, sha256: 'f3c77f0a870584e2284cdf058b30d5a1171857611cfc3152a386f83dd3b895a7' },
  'freeze.json': { bytes: 549730, sha256: 'ef2df8da7cbfdb298ff2dfa5f13db5d8f8ad82f3a3e8017cbdac90a5a1e7eb59' },
  'natural.json': { bytes: 5433797, sha256: 'f8017e64be594512cce88c7c2c2ff0e25a001fa4943e15a1880ea9f034e1d7e3' },
  'summary.json': { bytes: 9030, sha256: '2a981d763de851b399f26064330eb2b8fe1c4aa4a13c3124ab706fe971ae311a' },
};
const RESTORATION_SHA = 'c5fa12707cde98bba0a775475d274c369f68267fe5d2991e5a04acaabb3ad201';
const PUBLIC_974_OLD = '89b59e830d4ca6bdfee64c6edc990fa8ea032b0ae553c313880679ef5ee7f3c4', PUBLIC_974_NEW = '2b45e65b382e3aaf98e945347ea752294cdc3a26899f867272388f96d5c3b205';
const TRANSITION_SHA = '3dbc170abff8c7310dd384677469a19d9f9e217a0653dfe8d6a78a18587b4b66';
const LOGISTICS_FILES = ['src/domain/red-priest/campaign.ts', 'src/domain/red-priest/index.ts', 'dist/domain/red-priest/campaign.js', 'dist/domain/red-priest/campaign.js.map', 'dist/domain/red-priest/index.js', 'dist/domain/red-priest/index.js.map'];
const RESTORATION_FILES = ['src/domain/red-priest/campaign.ts', 'src/domain/red-priest/engine.ts', 'src/domain/red-priest/index.ts', 'src/domain/red-priest/types.ts', 'src/renderer/RedPriestPanel.tsx', 'src/renderer/SliceApp.tsx', 'dist/domain/red-priest/campaign.js', 'dist/domain/red-priest/campaign.js.map', 'dist/domain/red-priest/engine.js', 'dist/domain/red-priest/engine.js.map', 'dist/domain/red-priest/index.js', 'dist/domain/red-priest/index.js.map'];
const PUBLIC_941_OLD = '86f1b384408032f77881fd95db91a22c36079cdd45fce3c57901047e4cda09f0', PUBLIC_941_NEW = 'c87ae3523ad27e645baf837a845579f7a223eb9b2c0c428562e0b0c6be9db5db';
const CHECKS = ['strict-before-put-and-reopen', 'beforeWrite-after-real-application', 'rollback-private-rng-receipts-backup-selection-timestamps-unchanged', 'rollback-reopen', 'same-envelope-retry-exact-private-public-rng', 'commit-reopen', 'duplicate-idempotent', 'final-reopen-status'];
const digest = s => typeof s === 'string' && /^[a-f0-9]{64}$/.test(s);
const sha = value => createHash('sha256').update(value).digest('hex');
const compactHash = value => sha(JSON.stringify(value));
export function stable(value) {
  if (Array.isArray(value)) return `[${value.map(stable).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${stable(value[k])}`).join(',')}}`;
  return JSON.stringify(value);
}
export const stateHash = value => sha(stable(value));
const json = path => JSON.parse(readFileSync(path, 'utf8'));
function regular(path) { assert.equal(realpathSync(path), path, 'No symlinks'); assert(lstatSync(path).isFile()); return path; }
function directory(path) { const p = resolve(path); assert.equal(realpathSync(p), p, 'No directory symlinks'); assert(lstatSync(p).isDirectory()); return p; }
function evidence(path) {
  regular(path); const before = lstatSync(path, { bigint: true }), h = createHash('sha256'), fd = openSync(path, 'r'), b = Buffer.allocUnsafe(65536); let bytes = 0;
  try { for (;;) { const n = readSync(fd, b, 0, b.length, null); if (!n) break; bytes += n; h.update(b.subarray(0, n)); } } finally { closeSync(fd); }
  const after = lstatSync(path, { bigint: true }); for (const key of ['size', 'mtimeNs', 'ctimeNs', 'ino']) assert.equal(after[key], before[key]);
  assert.equal(BigInt(bytes), after.size); return { bytes, sha256: h.digest('hex') };
}
function sync(path) { const fd = openSync(path, 'r'); try { fsyncSync(fd); } finally { closeSync(fd); } }
function atomic(path, value) {
  // An existing .next means an unreviewed interruption, never permission to erase it.
  writeFileSync(`${path}.next`, JSON.stringify(value), { flag: 'wx' }); sync(`${path}.next`); renameSync(`${path}.next`, path); sync(dirname(path));
}
function contains(root, target) { const r = relative(root, target); return r === '' || r !== '..' && !r.startsWith(`..${sep}`) && !r.startsWith(sep); }
export function assertFreeze(captured, current) {
  for (const f of [captured, current]) {
    assert.deepEqual(Object.keys(f).sort(), ['files', 'sha256']); assert(Array.isArray(f.files) && digest(f.sha256)); const names = new Set();
    for (const row of f.files) {
      assert.deepEqual(Object.keys(row).sort(), ['bytes', 'file', 'sha256']); assert(typeof row.file === 'string' && row.file && !names.has(row.file));
      names.add(row.file); assert(Number.isSafeInteger(row.bytes) && row.bytes >= 0 && digest(row.sha256));
    }
    assert.equal(compactHash(f.files), f.sha256);
  }
  assert.deepEqual(current, captured, 'Capture/runtime/source/producer freeze must match without exceptions');
}
export function assertProducerOnlyFreezeChange(before, after) {
  assertFreeze(before, before); assertFreeze(after, after);
  assert.deepEqual(before.files.map(r => r.file), after.files.map(r => r.file), 'No added, removed or reordered frozen input');
  const changes = before.files.filter((row, i) => row.bytes !== after.files[i].bytes || row.sha256 !== after.files[i].sha256);
  assert.deepEqual(changes.map(r => r.file), ['$natural-producer'], 'Only the specifically approved producer continuation changes');
}
export function assertContinuationPolicy(before, after) {
  assert.equal(before.attemptsPerMaterialOperation, 6); assert.equal(after.attemptsPerMaterialOperation, 12);
  assert.deepEqual(after, { ...before, attemptsPerMaterialOperation: 12 }, 'Only the explicit cumulative material limit 6 to 12 changes');
}
export function assertAuthorityContinuationPolicy(before, after) {
  assert.equal(before.authorityAttemptsPerPolity, 5); assert.equal(after.authorityAttemptsPerPolity, 12);
  assert.deepEqual(after, { ...before, authorityAttemptsPerPolity: 12 }, 'Only the explicit cumulative authority limit 5 to 12 changes');
}
export function assertLogisticsPolicy(before, after) {
  assert.equal(before.logisticsRecovery, undefined); assert.deepEqual(after, { ...before, logisticsRecovery: true });
}
export function assertRestorationPolicy(before, after) {
  for (const key of ['fieldArmyRecovery', 'finiteSupplyRecovery', 'postwarFootReturn', 'verifiedPersonnelExit']) assert.equal(before[key], undefined);
  assert.deepEqual(after, { ...before, fieldArmyRecovery: true, finiteSupplyRecovery: true, postwarFootReturn: true, verifiedPersonnelExit: '现有人员已经不足以完成剩余目标。继续交战不能补回损失，可以真实停战或保护撤离。' });
}
export function restoreBeforeLogistics(view) {
  const result = structuredClone(view), added = result.actions.filter(a => a.command.type === 'CAMPAIGN' && a.command.command.type === 'RETURN_TO_HEADQUARTERS');
  assert(added.length <= 1); if (added.length) { const a = added[0]; assert.deepEqual(a.command, { type: 'CAMPAIGN', command: { type: 'RETURN_TO_HEADQUARTERS' } });
    assert.equal(a.label, '沿原路回总部整备'); assert.equal(typeof a.enabled, 'boolean'); assert.equal(result.actions.at(-1), a); result.actions.pop(); }
  return result;
}
export function assertLogisticsReplayRows(proof, rows) {
  assert.equal(proof.replay.commands, 146); assert.equal(proof.replay.first, 796); assert.equal(proof.replay.last, 941); assert.equal(proof.replay.allPrivateAndRngEqual, true);
  assert.equal(proof.replay.publicDifference, 'Only appended RETURN_TO_HEADQUARTERS action'); assert.equal(proof.replay.addedProjectionChecks, 18);
  assert.equal(rows.length, 146); assert.equal(proof.replay.rows.length, 146);
  for (const [i, check] of proof.replay.rows.entries()) { const row = rows[i]; assert.equal(check.commandCount, 796 + i); assert.equal(row.commandCount, check.commandCount);
    assert.equal(check.stateSha256, row.afterStateSha256); assert.deepEqual(check.random, row.randomAfter); assert.equal(check.capturedPublicSha256, row.publicAfterSha256); assert(digest(check.publicSha256)); }
  assert.equal(proof.replay.rows.at(-1).publicSha256, proof.continuedPublicSha256);
}
export function restoreBeforeRestoration(view) {
  const result = structuredClone(view), added = [], orders = [], polities = { loen: '鲁恩', intis: '因蒂斯', feneport: '费内波特' };
  for (const [i, action] of result.actions.entries()) {
    const c = action.command, type = c.type === 'CAMPAIGN' ? c.command.type : c.type; let order;
    if (type === 'REST_FIELD_ARMIES') { assert.deepEqual(c, { type: 'CAMPAIGN', command: { type } }); assert.equal(action.label, '让总部原军休整'); order = 0; }
    else if (type === 'RETURN_ON_FOOT') { assert.deepEqual(c, { type }); assert.equal(action.label, '停战后沿原路步行返总部'); order = 1; }
    else if (type === 'SUPPLY_ONLY') { const id = c.command.polityId; assert(Object.hasOwn(polities, id)); assert.deepEqual(c, { type: 'CAMPAIGN', command: { type, polityId: id } }); assert.equal(action.label, `运输${polities[id]}原库存补给`); order = 2 + Object.keys(polities).indexOf(id); }
    else { assert.equal(added.length, 0, 'Only an appended recovery action suffix may be removed'); continue; }
    assert.equal(typeof action.enabled, 'boolean'); added.push(i); orders.push(order);
  }
  assert.deepEqual(orders, [...new Set(orders)].sort()); if (added.length) result.actions.splice(added[0]);
  const readiness = result.sections.filter(s => s.id === 'campaign-readiness'); assert(readiness.length <= 1);
  if (readiness.length) { const section = readiness[0]; assert.deepEqual(Object.keys(section).sort(), ['id', 'lines', 'title']); assert.equal(section.title, '胜算与有限兵员'); assert(Array.isArray(section.lines) && section.lines.every(line => typeof line === 'string'));
    result.sections = result.sections.filter(s => s.id !== 'campaign-readiness'); }
  return result;
}
export function assertRestorationReplayRows(proof, rows) {
  assert.equal(proof.replay.commands, 179); assert.equal(proof.replay.first, 796); assert.equal(proof.replay.last, 974); assert.equal(proof.replay.allPrivateAndRngEqual, true);
  assert.equal(proof.replay.publicDifference, 'Only appended recovery actions and campaign-readiness section; historical RETURN_TO_HEADQUARTERS projection preserved');
  assert.equal(proof.replay.addedProjectionChecks, 382, 'Diagnostic transformation-call count, never boundary coverage');
  assert.equal(rows.length, 179); assert.equal(proof.replay.rows.length, 179);
  for (const [i, check] of proof.replay.rows.entries()) { const row = rows[i]; assert.equal(check.commandCount, 796 + i); assert.equal(row.commandCount, check.commandCount);
    assert.equal(check.stateSha256, row.afterStateSha256); assert.deepEqual(check.random, row.randomAfter); assert.equal(check.capturedPublicSha256, row.publicAfterSha256); assert(digest(check.publicSha256)); }
  assert.equal(proof.replay.rows.at(-1).publicSha256, proof.continuedPublicSha256);
  assert.equal(proof.replay.rows.at(-1).priorRuntimePublicSha256, proof.originalPublicSha256);
  for (const [i, check] of proof.replay.rows.entries()) { assert(digest(check.priorRuntimePublicSha256)); if (check.commandCount > 941) assert.equal(check.priorRuntimePublicSha256, rows[i].publicAfterSha256); }
}
export function assertPublicChain(previous, row, lineage) {
  const seams = lineage?.original.commandCount === 974 ? [lineage.inheritedRuntimeTransition, lineage.runtimeTransition] : lineage?.original.commandCount === 941 ? [lineage.runtimeTransition] : [];
  const seam = seams.find(s => row.commandCount === s.commandCount + 1);
  if (seam) { const count = seam.commandCount; assert([941, 974].includes(count));
    assert.equal(seam.proofSha256, count === 941 ? TRANSITION_SHA : RESTORATION_SHA);
    assert.equal(seam.originalPublicSha256, count === 941 ? PUBLIC_941_OLD : PUBLIC_974_OLD); assert.equal(seam.continuedPublicSha256, count === 941 ? PUBLIC_941_NEW : PUBLIC_974_NEW);
    assert.equal(previous.publicAfterSha256, seam.originalPublicSha256); assert.equal(row.publicBeforeSha256, seam.continuedPublicSha256);
  } else assert.equal(row.publicBeforeSha256, previous.publicAfterSha256);
}
export const assertLogisticsFreeze = (before, after, changes) => assertRuntimeFreeze(before, after, changes, LOGISTICS_FILES);
export const assertRestorationFreeze = (before, after, changes) => assertRuntimeFreeze(before, after, changes, RESTORATION_FILES);
function assertRuntimeFreeze(before, after, changes, paths) {
  assertFreeze(before, before); assertFreeze(after, after); assert.deepEqual(changes.map(c => c.file), paths);
  assert.deepEqual(before.files.map(r => r.file), after.files.map(r => r.file)); const changed = [];
  for (const [i, row] of before.files.entries()) { const next = after.files[i], change = changes.find(c => c.file === row.file);
    if (row.bytes !== next.bytes || row.sha256 !== next.sha256) changed.push(row.file);
    if (change) { assert.deepEqual({ bytes: row.bytes, sha256: row.sha256 }, change.before); assert.deepEqual({ bytes: next.bytes, sha256: next.sha256 }, change.after); } }
  assert.deepEqual(changed.sort(), ['$natural-producer', ...paths].sort(), 'Only exact approved runtime files and producer may change');
}
export function assertOriginalLedgerPrefix(current, original) {
  assert(Buffer.isBuffer(current) && Buffer.isBuffer(original)); assert(original.length && original.at(-1) === 10);
  assert(current.subarray(0, original.length).equals(original), 'Every original completed row must remain the exact byte prefix');
}
function inspectFreeze(repo) {
  const files = [], walk = file => {
    const path = join(repo, file), stat = lstatSync(path); assert(!stat.isSymbolicLink());
    if (stat.isDirectory()) for (const child of readdirSync(path).sort()) walk(join(file, child));
    else files.push({ file: file.split(sep).join('/'), ...evidence(path) });
  };
  for (const file of ['package.json', 'package-lock.json', 'src', 'dist/domain', 'dist/content', 'dist/resolution', 'dist/persistence', 'dist/shared', 'dist/application', 'dist/simulation']) walk(file);
  files.push({ file: '$natural-producer', ...evidence(join(repo, PRODUCER)) }, { file: SOURCE, ...evidence(join(repo, SOURCE)) });
  return { sha256: compactHash(files), files };
}
export function assertResumeManifest(saved, current) { assert.deepEqual(saved, current, 'Resume requires exact inputs, selection, source, producer, runtime and verifier bytes'); }
export function selectBoundaries(rows, journal) {
  assert(rows.length > 0, 'No actual new transition to verify');
  const events = new Map(journal.map(e => [e.revision, e])); assert.equal(events.size, journal.length);
  const seen = new Set(), selected = new Map(), coverage = {};
  const add = (row, reason) => {
    coverage[reason] = (coverage[reason] ?? 0) + 1; if (seen.has(reason)) return; seen.add(reason);
    const item = selected.get(row.commandCount) ?? { commandCount: row.commandCount, names: [] };
    item.names.push(reason); selected.set(row.commandCount, item);
  };
  for (const row of rows) {
    assert.equal(row.intent.type, 'RED_PRIEST'); const c = row.intent.command, e = events.get(row.revision);
    if (c.type === 'LEARN_GUIDANCE') assert.equal(e, undefined);
    else { assert(e, 'Every non-guidance command has its real journal event'); assert.deepEqual(e.command, c); }
    add(row, `command:${c.type}${c.command ? `:${c.command.type}` : ''}`);
    if (c.type === 'CAMPAIGN' && c.command.type === 'BATTLE') {
      const receipt = e.campaignHost?.receipt; assert.equal(receipt?.kind, 'BATTLE');
      assert(['SUCCESS', 'GREAT_SUCCESS', 'FAILURE', 'SEVERE_FAILURE'].includes(receipt.result));
      add(row, `battle:${receipt.result.includes('SUCCESS') ? 'success' : 'failure'}`);
    }
    if (c.type === 'CONSUME') {
      const receipt = e.materialReceipt?.consumption; assert(receipt && ['SUCCESS', 'FAILURE'].includes(receipt.outcome));
      assert.equal(receipt.compoundId, c.compoundId); add(row, `consume:${receipt.outcome}`);
    }
  }
  add(rows.at(-1), 'final-actual-transition');
  return { selected: [...selected.values()].sort((a, b) => a.commandCount - b.commandCount), coverage };
}
function readCapture(root, repo, freeze) {
  const old = json(regular(join(repo, SOURCE))); assert.equal(evidence(join(repo, SOURCE)).sha256, SOURCE_SHA);
  assert.equal(old.commands.length, PREFIX); assert.equal(compactHash(old.commands), PREFIX_SHA);
  assert.equal(old.seed, 'hunter-rebuild-first'); assert.equal(old.final.runId, 'hunter-rebuild-natural');
  assert.equal(old.final.revision, 796); assert.equal(old.final.status, 'ACTIVE'); assert.equal(old.final.schemaVersion, 184);
  assert.deepEqual(old.final.random, { seed: old.seed, cursor: 376 });
  const capture = json(join(root, 'natural.json')), wrapped = json(join(root, 'checkpoint.json')), cp = wrapped.payload, report = json(join(root, 'summary.json'));
  assert.equal(wrapped.sha256, stateHash(cp), 'Complete durable checkpoint checksum');
  assert.equal(cp.format, 'RED_PRIEST_DURABLE_PUBLIC_ACTION_BOUNDARY_V1'); assert.equal(cp.source, SOURCE);
  assert.equal(cp.sourceSha256, SOURCE_SHA); assert.equal(cp.prefixSha256, PREFIX_SHA); assert.equal(cp.freezeSha256, freeze.sha256);
  assert.equal(cp.pending, null); assert(cp.terminal, 'Paused or interrupted producer captures are not terminal evidence');
  assert.deepEqual(cp.terminal, { stage: capture.stage, reason: capture.reason }); assert.equal(capture.pendingIntent, null);
  assert.deepEqual(capture.provenance, { kind: 'EXACT_ORIGINAL_LIVING_PUBLIC_RED_PRIEST_CONTINUATION', source: SOURCE,
    sourceSha256: SOURCE_SHA, prefixCommandsSha256: PREFIX_SHA, runtimeFreezeSha256: freeze.sha256, historicalPrefixReplayedByThisProducer: false,
    historicalPrefixRetainedExactly: true, originalCaptureMayNotChange: true, privateAudit: true, seedChanged: false, selectedFromEnabledPublicActionsOnly: true,
    ...(capture.lineage ? { continuation: { proofFile: capture.lineage.proofFile, proofSha256: capture.lineage.proofSha256, originalCommandCount: capture.lineage.original.commandCount } } : {}) });
  assert.deepEqual(cp.lineage, capture.lineage);
  for (const key of ['creation', 'seed', 'initial']) assert.deepEqual(capture[key], old[key]);
  assert.equal(capture.prefixCount, PREFIX); assert.deepEqual(capture.prefixFinal, old.final); assert.deepEqual(capture.commands.slice(0, PREFIX), old.commands);
  assert.deepEqual(capture.commands.slice(PREFIX), cp.commands); assert.deepEqual(capture.policy, cp.policyDefinition);
  assert.equal(capture.commands.length, cp.commandCount); assert.equal(cp.commands.length, cp.rows.length); assert(digest(cp.initialStateSha256));
  const text = readFileSync(join(root, 'commands.ndjson'), 'utf8'); assert(text.endsWith('\n'));
  const rows = text.slice(0, -1).split('\n').map(line => { assert(line); return JSON.parse(line); }); assert.deepEqual(rows, cp.rows);
  assert.equal(stateHash(capture.final), cp.finalStateSha256); assert.equal(stateHash(cp.state), cp.finalStateSha256);
  assert.equal(capture.final.revision, old.final.revision + rows.length); assert.equal(report.paused, false); assert.equal(report.strictFinalValidation, true);
  assert.equal(report.stage, capture.stage); assert.equal(report.reason, capture.reason); assert.equal(report.originalCommands, PREFIX);
  assert.equal(report.commands, cp.commandCount); assert.equal(report.newCommands, rows.length);
  for (const [i, row] of rows.entries()) {
    assert.equal(row.commandCount, PREFIX + i + 1); assert.equal(row.revision, old.final.revision + i + 1);
    assert.deepEqual(row.intent, cp.commands[i]); assert.equal(compactHash(row.intent), row.commandSha256);
    for (const key of ['beforeStateSha256', 'afterStateSha256', 'publicBeforeSha256', 'publicAfterSha256']) assert(digest(row[key]));
    if (i) { assert.equal(row.beforeStateSha256, rows[i - 1].afterStateSha256); assertPublicChain(rows[i - 1], row, cp.lineage); assert.deepEqual(row.randomBefore, rows[i - 1].randomAfter); }
    assert.equal(row.randomBefore.seed, old.seed); assert.equal(row.randomAfter.seed, old.seed);
    assert(Number.isSafeInteger(row.randomBefore.cursor) && row.randomBefore.cursor >= 376); assert(row.randomAfter.cursor >= row.randomBefore.cursor && Number.isSafeInteger(row.randomAfter.cursor));
  }
  assert.equal(rows[0].beforeStateSha256, cp.initialStateSha256); assert.deepEqual(rows[0].randomBefore, old.final.random);
  assert.equal(rows.at(-1).afterStateSha256, cp.finalStateSha256); assert.equal(rows.at(-1).publicAfterSha256, cp.publicStateSha256);
  assert.deepEqual(rows.at(-1).randomAfter, capture.final.random);
  return { old, capture, cp, rows, ...selectBoundaries(rows, capture.final.redPriest.journal) };
}
export function assertContinuationOrder(count, requiredOriginal = null) {
  assert([836, 915, 941, 974].includes(count), 'Only exact836,915,941,974 observations are approved'); if (requiredOriginal !== null) assert.equal(count, requiredOriginal);
}
function readContinuation(root, freeze, data, requiredOriginal = null) {
  if (!data.capture.lineage) { assert(!existsSync(join(root, 'prior-proof')) && !existsSync(join(root, 'prior-observation'))); return null; }
  const count = data.capture.lineage.original.commandCount; assertContinuationOrder(count, requiredOriginal);
  assert.deepEqual(readdirSync(directory(join(root, 'prior-proof'))).sort(), ['commands.ndjson', 'lineage.json', 'producer.mjs', ...([941, 974].includes(count) ? ['runtime-before', 'runtime-transition.json'] : [])].sort());
  const original = count === 974 ? { format: 'RED_PRIEST_APPROVED_EXACT_974_FIELD_ARMY_CONTINUATION_V1', commandCount: 974,
    checkpointPayloadSha256: '020a3b8e3cc38e071b01b20c94a74bf60ce240019787091e3a624443b2e08e8e', policyStateSha256: 'a6d727a990575227544231fe1bbd77770cfdba89f36dcffb550225b13ed7311b',
    terminal: { stage: 'FINITE_CAMPAIGN_REVIEW_REQUIRED', reason: 'No enabled forward route, objective or finite reinforcement remains' },
    stateSha256: '47b56cc7d857dd18d157628b55fb6de56fcb7d5b4c4097b34aa0a42df1a0d73a', publicSha256: PUBLIC_974_OLD,
    freezeSha256: 'bc9ab45457e5173f3b72adf6585c19d233f6b79b1be5f165981dd44e8b90d5f9',
    producer: { file: '$natural-producer', bytes: 65014, sha256: 'e6fc50ac046b9634870989968558cd21efcbbb7154caf86b15f54fcb963f445f' },
    originalFiles: Object.entries(RESTORATION_INPUTS).map(([file, value]) => ({ file, ...value })) } : count === 941 ? { format: 'RED_PRIEST_APPROVED_EXACT_941_LOGISTICS_CONTINUATION_V1', commandCount: 941,
    checkpointPayloadSha256: 'cf1675b04822d635b46931f1d5ff9b84c85b5279e080b670070f0cbb989834dd', policyStateSha256: 'd84ddb3e627b7633e6bad677fce5422b0d4a1a604a8029e728da1931ee7e0f7a',
    terminal: { stage: 'FINITE_PUBLIC_NO_PROGRESS', reason: 'Finite recovery limit reached: Recover actual resources for 在灰脊北关执行会战' },
    stateSha256: '5e92f155fbeadf38dd22722831489bf7176865858b58d3254e1025725bfe1751', publicSha256: PUBLIC_941_OLD,
    freezeSha256: '4fd9123b33f55edd661b3155b4cd645c46f2d8ee5f7c5b69c76bdb777e73cb62',
    producer: { file: '$natural-producer', bytes: 55887, sha256: '4811bb5c3b801c1b45a582a825094f4fb3ee9a43191baa4a5be4dc4279f47f65' },
    originalFiles: Object.entries(LOGISTICS_INPUTS).map(([file, value]) => ({ file, ...value })) } : count === 915 ? { format: 'RED_PRIEST_APPROVED_EXACT_915_CONTINUATION_V1', commandCount: 915,
    checkpointPayloadSha256: 'cf768632559c637fb2bafc94385eb6e3b141311bc218850776077e010280dea5',
    policyStateSha256: '53fe8c9290ad29304ce04e894cd6ac5f7c8b837079c74ebb393856a53f3d7dd1',
    terminal: { stage: 'FINITE_AUTHORITY_ATTEMPTS', reason: 'Actual coalition permission was not obtained within the finite public policy' },
    stateSha256: '040db02f43169b0e913c77c1adb39fff31293a2947f9d90c8fea06b61b7ecd4a', publicSha256: '4b9777b46c624336024dfa8472a677757fd5dedba887dbab588f296c9fd6cb70',
    freezeSha256: 'be967f07d9a912627b5c21fb1746247b4d2ba3797ee1dce532108748e1eeb11e',
    producer: { file: '$natural-producer', bytes: 52076, sha256: 'fa5afd4e7c6b6263d452d3aa59c34a43252d80b9269f851c7b1e7081f986ae02' },
    originalFiles: Object.entries(AUTHORITY_INPUTS).map(([file, value]) => ({ file, ...value })) }
    : { format: 'RED_PRIEST_APPROVED_EXACT_836_CONTINUATION_V1', commandCount: 836,
    checkpointPayloadSha256: '1e12bab7df3acdae9717e68f84cf2b4e2a95433437470ef5363a0a11c7478180',
    policyStateSha256: 'afc9f285472bfe3f0ef205cce4e3f188e9c77c82b6fe51cbca7f2e42f98f5844',
    terminal: { stage: 'FINITE_MATERIAL_ATTEMPTS', reason: 'Finite attempts exhausted for 净化已核验原残余' },
    stateSha256: 'ce66e5141b397cc89ef843a225d43f9cd5e04895fabdcdf9ecf520d58defd0a7',
    publicSha256: '19c8038ab331415db672c9efce5335f7f840f03a9d50771847cd09d4c7473189', freezeSha256: ORIGINAL_FREEZE,
    producer: { file: '$natural-producer', bytes: 41116, sha256: '1624ea7cd4cf7cfff738755a1d19a1b3bde2b041420828656be5df9aee79b7a3' },
    originalFiles: Object.entries(ORIGINAL_INPUTS).map(([file, value]) => ({ file, ...value })) };
  const pins = count === 974 ? RESTORATION_INPUTS : count === 941 ? LOGISTICS_INPUTS : count === 915 ? AUTHORITY_INPUTS : ORIGINAL_INPUTS, priorCount = count - PREFIX;
  const transitionSha = count === 974 ? RESTORATION_SHA : TRANSITION_SHA, publicAfter = count === 974 ? PUBLIC_974_NEW : PUBLIC_941_NEW;
  const changedPaths = count === 974 ? RESTORATION_FILES : LOGISTICS_FILES, cursor = count === 974 ? 426 : count === 941 ? 425 : count === 915 ? 420 : 392;
  let transition = null;
  if ([941, 974].includes(count)) { const path = regular(join(root, 'prior-proof/runtime-transition.json')); assert(digest(transitionSha), 'Reviewed runtime proof pin is required'); assert.equal(evidence(path).sha256, transitionSha); transition = json(path);
    assert.equal(transition.format, count === 974 ? 'RED_PRIEST974_FIELD_ARMY_TRANSITION_V1' : 'RED_PRIEST941_LOGISTICS_TRANSITION_V1'); assert.equal(transition.commandCount, count); assert.equal(transition.originalFreezeSha256, original.freezeSha256);
    assert.equal(transition.checkpointSha256, pins['checkpoint.json'].sha256); assert.equal(transition.stateSha256, original.stateSha256); assert.equal(transition.originalPublicSha256, original.publicSha256); assert.equal(transition.continuedPublicSha256, publicAfter);
    assert.deepEqual(transition.random, { seed: data.old.seed, cursor }); (count === 974 ? assertRestorationReplayRows : assertLogisticsReplayRows)(transition, data.rows.slice(0, priorCount));
    for (const change of transition.changedFiles) assert.deepEqual(evidence(join(root, 'prior-proof/runtime-before', change.file)), change.before); }
  // All evidence is portable and relative: preserve and independently read the
  // original five exact files alongside the small producer/ledger/control proof.
  const priorFreeze = { files: freeze.files.map(row => row.file === '$natural-producer' ? original.producer : transition?.changedFiles.some(c => c.file === row.file) ? { file: row.file, ...transition.changedFiles.find(c => c.file === row.file).before } : row), sha256: original.freezeSha256 };
  if (transition) (count === 974 ? assertRestorationFreeze : assertLogisticsFreeze)(priorFreeze, freeze, transition.changedFiles); else assertProducerOnlyFreezeChange(priorFreeze, freeze);
  const originalRoot = directory(join(root, 'prior-observation')); assert.deepEqual(readdirSync(originalRoot).sort(), [...INPUTS, ...(count > 836 ? ['prior-observation', 'prior-proof'] : [])].sort());
  for (const [file, expected] of Object.entries(pins)) assert.deepEqual(evidence(join(originalRoot, file)), expected, 'All five original raw inputs must match');
  assertFreeze(json(join(originalRoot, 'freeze.json')), priorFreeze); const prior = readCapture(originalRoot, process.cwd(), priorFreeze);
  assert.equal(json(join(originalRoot, 'checkpoint.json')).sha256, original.checkpointPayloadSha256);
  assert.equal(prior.cp.commandCount, count); assert.equal(prior.cp.state.status, 'ACTIVE'); assert.equal(prior.cp.state.revision, count + 1);
  assert.equal(prior.cp.finalStateSha256, original.stateSha256); assert.equal(prior.cp.publicStateSha256, original.publicSha256);
  assert.equal(data.cp.initialStateSha256, prior.cp.initialStateSha256);
  const nested = count > 836 ? readContinuation(originalRoot, priorFreeze, prior, count === 974 ? 941 : count === 941 ? 915 : 836) : null;
  if (count > 836) assert(nested); else assert.equal(prior.cp.lineage, undefined);
  if (count === 974) for (const [i, check] of nested.transition.replay.rows.entries()) assert.equal(transition.replay.rows[i].priorRuntimePublicSha256, check.publicSha256, '974 proof must preserve every941 runtime public hash');
  assert.deepEqual(evidence(join(root, 'prior-proof/producer.mjs')), { bytes: original.producer.bytes, sha256: original.producer.sha256 });
  assert.deepEqual(evidence(join(root, 'prior-proof/commands.ndjson')), pins['commands.ndjson']);
  const ledger = readFileSync(join(root, 'prior-proof/commands.ndjson')), priorRows = ledger.toString('utf8').trimEnd().split('\n').map(JSON.parse);
  assert.equal(priorRows.length, priorCount); const priorCommands = priorRows.map(row => row.intent), proof = json(regular(join(root, 'prior-proof/lineage.json')));
  assert.equal(stateHash(proof.priorPolicyState), original.policyStateSha256);
  assert.equal(stateHash(proof.previousPolicy), count === 974 ? 'ece2bc84ff8dc4ad9d5ee8692bb56298bf98318db77ecd7c98df2968319c879a' : count === 941 ? 'd1395f8c9f91623c4ea973a432a858cfcfb00a2bc220f107b7473d30cd4e6630' : count === 915 ? '5843cd6921d77d5a9d9d232a181af65075c72a13890508a46ddd4d24672e8ba0' : 'f3f35c3bee487ec29257f4d775311f1c9f79437071a01cd16a226764a0000640');
  assert.deepEqual(proof.priorPolicyState, prior.cp.policy); assert.deepEqual(proof.priorTerminal, prior.cp.terminal);
  assert.deepEqual(prior.cp.rows, priorRows); assert.deepEqual(prior.cp.commands, priorCommands);
  const expected = { original, newFreezeSha256: freeze.sha256, originalFilesDirectory: 'prior-observation', onlyAllowedFreezeChange: ['$natural-producer', ...(transition ? changedPaths : [])],
    producerFile: 'prior-proof/producer.mjs', ledgerFile: 'prior-proof/commands.ndjson', priorCommandsSha256: compactHash(priorCommands), priorRowsSha256: compactHash(priorRows),
    priorPolicyState: proof.priorPolicyState, priorTerminal: original.terminal, previousPolicy: proof.previousPolicy, continuedPolicy: data.cp.policyDefinition, ...(transition ? { runtimeTransition: { proofFile: 'prior-proof/runtime-transition.json', proofSha256: transitionSha, commandCount: count, originalPublicSha256: original.publicSha256, continuedPublicSha256: publicAfter, runtimeBeforeDirectory: 'prior-proof/runtime-before' } } : {}), ...(count === 974 ? { inheritedRuntimeTransition: prior.cp.lineage.runtimeTransition } : {}) };
  assert.deepEqual(proof, expected, 'Only the four exact approved observation proofs are accepted');
  (count === 974 ? assertRestorationPolicy : count === 941 ? assertLogisticsPolicy : count === 915 ? assertAuthorityContinuationPolicy : assertContinuationPolicy)(proof.previousPolicy, proof.continuedPolicy);
  const proofSha256 = evidence(join(root, 'prior-proof/lineage.json')).sha256; assert.equal(proofSha256, compactHash(proof));
  assert.deepEqual(data.capture.lineage, { ...proof, proofFile: 'prior-proof/lineage.json', proofSha256 });
  assertOriginalLedgerPrefix(readFileSync(join(root, 'commands.ndjson')), ledger);
  assert.deepEqual(data.cp.rows.slice(0, priorCount), priorRows); assert.deepEqual(data.cp.commands.slice(0, priorCount), priorCommands);
  const boundary = priorRows.at(-1); assert.equal(boundary.afterStateSha256, original.stateSha256); assert.equal(boundary.publicAfterSha256, original.publicSha256);
  assert.deepEqual(boundary.randomAfter, { seed: data.old.seed, cursor }); assert(data.rows.length > priorCount, 'Continuation must contain an actual new completed action');
  const next = data.rows[priorCount]; assert.equal(next.beforeStateSha256, original.stateSha256); assert.equal(next.publicBeforeSha256, transition ? publicAfter : original.publicSha256); assert.deepEqual(next.randomBefore, boundary.randomAfter);
  const attempts = {}; for (const row of data.rows) { const key = JSON.stringify(row.intent.command); attempts[key] = (attempts[key] ?? 0) + 1; }
  assert.deepEqual(data.cp.policy.attempts, attempts, 'Original cumulative attempt counters cannot reset');
  return { lineage: data.capture.lineage, nested, transition, originalCompletedRows: priorCount, productRuntimeSourceUnchanged: transition === null,
    evidenceScope: 'ALL_FIVE_BUNDLED_ORIGINAL_RAW_FILES_AND_PRODUCER_AND_LEDGER_VERIFIED_EXACT; EXACT_EACH_LAYER_FREEZE_WITH_ONLY_EXPLICIT_PINNED_CHANGES' };
}
function lock(out, manifestSha256, approvedPid) {
  const path = join(out, 'audit.lock.json');
  if (existsSync(path)) {
    const prior = json(regular(path)); assert.equal(prior.manifestSha256, manifestSha256);
    assert.equal(prior.pid, approvedPid, 'Stale lock requires main/operator approval with --remove-stale-lock-pid EXACT_PID');
    assert(Number.isSafeInteger(prior.pid) && prior.pid > 0); let dead = false;
    try { process.kill(prior.pid, 0); } catch (e) { if (e.code === 'ESRCH') dead = true; else throw e; }
    assert(dead, 'Never take over a live or uncertain owner'); rmSync(path);
  } else assert.equal(approvedPid, undefined, 'No stale lock exists for the approved PID');
  const owner = { manifestSha256, pid: process.pid }; writeFileSync(path, JSON.stringify(owner), { flag: 'wx' }); sync(path); sync(out);
  return () => { assert.deepEqual(json(path), owner); rmSync(path); sync(out); };
}
function dbFiles(work) {
  if (!existsSync(work)) return {}; const files = {};
  for (const name of readdirSync(directory(work)).sort()) {
    assert(['case.sqlite', 'case.sqlite.bak', 'case.sqlite.sealed'].includes(name), `Unknown SQLite artifact retained: ${name}`);
    files[name] = evidence(join(work, name));
  }
  return files;
}
function cleanCase(work, result) {
  if (!existsSync(work)) return;
  for (const [name, found] of Object.entries(dbFiles(work))) { assert.deepEqual(found, result.databaseFiles[name], 'Cleanup requires exact completed evidence'); rmSync(join(work, name)); }
  rmdirSync(work); sync(dirname(work));
}
function databaseRows(DatabaseSync, path) {
  const db = new DatabaseSync(path, { readOnly: true });
  try {
    const result = {};
    for (const [key, sql] of Object.entries({ runs: 'SELECT id,current_json,backup_json,terminal,updated_at FROM slice_runs ORDER BY id', receipts: 'SELECT id,fingerprint,receipt_json FROM slice_receipts ORDER BY id', meta: 'SELECT key,value FROM slice_meta ORDER BY key' })) {
      const rows = db.prepare(sql).all(); result[key] = { count: rows.length, sha256: compactHash(rows) };
    }
    assert.equal(Object.values(db.prepare('PRAGMA quick_check').get())[0], 'ok'); return result;
  } finally { db.close(); }
}
function checkSqlite(runtime, DatabaseSync, work, transition, before, after, intent, publicBefore, publicAfter, phase) {
  const started = performance.now(), path = join(work, 'case.sqlite'); assert(!existsSync(work)); mkdirSync(work);
  const envelope = { intentId: `red-priest209:${transition.commandCount}`, runId: before.runId, expectedRevision: before.revision, payload: intent };
  const now = '2026-10-17T00:00:01.000Z', initialTime = '2026-10-17T00:00:00.000Z';
  const receipt = { intentId: envelope.intentId, runId: after.runId, previousRevision: before.revision, newRevision: after.revision, committedAt: now, replayed: false, state: publicAfter };
  let app, inject = false, injected = 0;
  const exact = (expected, time, committed) => {
    const saved = app.repository.get(expected.runId); assert.equal(stateHash(saved.state), stateHash(expected));
    assert.deepEqual(saved.state.random, expected.random); assert.equal(saved.updatedAt, time); assert.equal(app.repository.activeRun(), expected.runId);
    assert.deepEqual(app.repository.receipt(envelope.intentId), committed ? { fingerprint: stable(envelope), receipt } : null);
  };
  const open = () => new runtime.SqliteSliceStore(path, { now: () => now, beforeWrite: () => {
    if (inject) { exact(after, now, true); injected++; throw Error('Injected beforeWrite after actual private state and receipt, before COMMIT'); }
  } });
  const close = () => { app?.close(); app = undefined; };
  const rows = () => databaseRows(DatabaseSync, path);
  const reopened = expected => { const boot = app.getBootstrap(); assert.equal(boot.ok, true); assert.deepEqual(boot.value.activeState, expected); };
  try {
    phase('PUT_BEFORE'); app = open(); assert.equal(before.status, 'ACTIVE');
    app.repository.transaction(() => { app.repository.put({ state: before, updatedAt: initialTime }); app.repository.selectRun(before.runId); });
    close(); app = open(); exact(before, initialTime, false); reopened(publicBefore); const initialRows = rows(), initialFiles = dbFiles(work);
    assert.deepEqual(Object.fromEntries(Object.entries(initialRows).map(([k, v]) => [k, v.count])), { runs: 1, receipts: 0, meta: 1 });
    phase('INJECT_BEFORE_WRITE'); inject = true; const failed = app.submitIntent(envelope); inject = false;
    assert.equal(failed.ok, false); assert.equal(failed.error.code, 'SAVE_FAILED'); assert.equal(injected, 1);
    exact(before, initialTime, false); assert.deepEqual(rows(), initialRows); assert.deepEqual(dbFiles(work), initialFiles);
    close(); app = open(); exact(before, initialTime, false); assert.deepEqual(rows(), initialRows);
    phase('RETRY_COMMIT_OUTCOME_UNKNOWN_UNTIL_VERIFIED'); const committed = app.submitIntent(envelope);
    assert.equal(committed.ok, true); assert.deepEqual(committed.value, receipt); exact(after, now, true);
    const committedRows = rows(); assert.equal(committedRows.receipts.count, 1);
    phase('COMMITTED_CHECK_REOPEN_AND_DUPLICATE'); close(); app = open(); exact(after, now, true); reopened(publicAfter); assert.deepEqual(rows(), committedRows);
    const duplicate = app.submitIntent(envelope); assert.equal(duplicate.ok, true); assert.deepEqual(duplicate.value, { ...receipt, replayed: true });
    exact(after, now, true); assert.deepEqual(rows(), committedRows);
    if (after.status === 'DEAD') {
      assert.deepEqual(json(`${path}.sealed`), [after.runId]); assert.equal(publicAfter.canAct, false);
      const blocked = app.submitIntent({ ...envelope, intentId: `${envelope.intentId}:archived`, expectedRevision: after.revision, payload: { type: 'RED_PRIEST', command: { type: 'REST' } } });
      assert.equal(blocked.ok, false); assert.equal(blocked.error.code, 'ARCHIVED'); assert.equal(app.repository.receipt(`${envelope.intentId}:archived`), null);
    } else assert.equal(existsSync(`${path}.sealed`), false);
    close(); app = open(); exact(after, now, true); assert.deepEqual(rows(), committedRows); close();
    return { ...transition, beforeStateSha256: stateHash(before), stateSha256: stateHash(after), publicStateSha256: stateHash(publicAfter), random: after.random,
      revision: after.revision, status: after.status, checks: CHECKS, terminalCheck: after.status === 'DEAD' ? 'ACTUAL_DEAD_SEALED_ARCHIVED' : 'ACTUAL_LIVING_UNSEALED',
      databaseRows: committedRows, databaseFiles: dbFiles(work), elapsedMilliseconds: Math.round(performance.now() - started) };
  } finally { close(); }
}
function runtimeBeforeFiles(root, restoration) {
  const layout = { '': ['dist', 'src'], src: restoration ? ['domain', 'renderer'] : ['domain'], ...(restoration ? { 'src/renderer': ['RedPriestPanel.tsx', 'SliceApp.tsx'] } : {}), 'src/domain': ['red-priest'], 'src/domain/red-priest': restoration ? ['campaign.ts', 'engine.ts', 'index.ts', 'types.ts'] : ['campaign.ts', 'index.ts'],
    dist: ['domain'], 'dist/domain': ['red-priest'], 'dist/domain/red-priest': restoration ? ['campaign.js', 'campaign.js.map', 'engine.js', 'engine.js.map', 'index.js', 'index.js.map'] : ['campaign.js', 'campaign.js.map', 'index.js', 'index.js.map'] };
  for (const [dir, names] of Object.entries(layout)) assert.deepEqual(readdirSync(directory(join(root, dir))).sort(), names);
  const files = restoration ? RESTORATION_FILES : LOGISTICS_FILES; for (const file of files) regular(join(root, file)); return files;
}
function captureInputNames(root, prefix = '', depth = 0) {
  assert(depth <= 4, 'Only the four approved nested observations are supported'); const names = readdirSync(directory(join(root, prefix))).sort();
  assert(INPUTS.every(file => names.includes(file))); const files = [];
  for (const name of names) {
    const file = prefix ? `${prefix}/${name}` : name;
    if (name === 'prior-observation') files.push(...captureInputNames(root, file, depth + 1));
    else if (name === 'prior-proof') { const extra = existsSync(join(root, file, 'runtime-transition.json')); const count = json(join(root, prefix, 'checkpoint.json')).payload.lineage.original.commandCount; if (extra) assert([941, 974].includes(count), 'Only exact941 and974 own runtime transitions');
      assert.deepEqual(readdirSync(directory(join(root, file))).sort(), ['commands.ndjson', 'lineage.json', 'producer.mjs', ...(extra ? ['runtime-before', 'runtime-transition.json'] : [])].sort());
      for (const child of ['commands.ndjson', 'lineage.json', 'producer.mjs', ...(extra ? ['runtime-transition.json'] : [])]) files.push(`${file}/${child}`);
      if (extra) files.push(...runtimeBeforeFiles(join(root, file, 'runtime-before'), count === 974).map(child => `${file}/runtime-before/${child}`)); }
    else { assert(INPUTS.includes(name) || name === 'error.json', 'Unknown capture artifact'); regular(join(root, file)); files.push(file); }
  }
  return files;
}
export async function verifyRedPriestCapture(options) {
  const started = performance.now(), repo = directory(process.cwd()), root = directory(options.sourceDirectory);
  assert(digest(options.freezeSha256) && digest(options.verifierSha256), 'Reviewed --freeze-sha256 and --verifier-sha256 required');
  assert.equal(evidence(SELF).sha256, options.verifierSha256); const freeze = json(regular(join(root, 'freeze.json')));
  assert.equal(freeze.sha256, options.freezeSha256); assertFreeze(freeze, inspectFreeze(repo));
  const inputNames = captureInputNames(root);
  const inputs = inputNames.map(file => ({ file, ...evidence(join(root, file)) }));
  const data = readCapture(root, repo, freeze), { old, capture, cp, rows, selected, coverage } = data, continuation = readContinuation(root, freeze, data);
  const manifest = { kind: FORMAT, sourceDirectory: root, source: { file: SOURCE, ...evidence(join(repo, SOURCE)) }, prefixCommandsSha256: PREFIX_SHA,
    freeze, verifier: evidence(SELF), inputs, continuation, selected, coverage, node: process.version };
  const manifestSha256 = stateHash(manifest);
  const unchanged = () => { assert.deepEqual(captureInputNames(root), inputNames); for (const row of inputs) assert.deepEqual(evidence(join(root, row.file)), { bytes: row.bytes, sha256: row.sha256 }); assertFreeze(freeze, inspectFreeze(repo)); assert.equal(evidence(SELF).sha256, options.verifierSha256); };
  if (options.preflight) return { preflight: 'PASSED_NO_RUNTIME_NO_SQLITE_NO_WRITES', manifestSha256, originalCommands: PREFIX, newCommands: rows.length, continuation, selected, coverage };
  const out = resolve(options.resumeDirectory ?? options.outputDirectory ?? ''); assert(options.resumeDirectory || options.outputDirectory, 'Explicit output directory required');
  assert(contains(join(repo, 'output'), out) && !contains(root, out) && !contains(out, root), 'Audit output must be separate inside repository output/');
  assert(!options.resumeDirectory || existsSync(out), 'Resume directory must already exist');
  if (!existsSync(out)) { let p = dirname(out); while (!existsSync(p)) p = dirname(p); directory(p); mkdirSync(out, { recursive: true }); }
  directory(out); if (!options.resumeDirectory) assert.equal(readdirSync(out).length, 0, 'Existing audit requires --resume-directory');
  const manifestPath = join(out, 'manifest.json'), indexPath = join(out, 'completed.json'), phasePath = join(out, 'current-phase.json'), work = join(out, 'current-sqlite');
  if (options.resumeDirectory) assertResumeManifest(json(regular(manifestPath)), manifest);
  const release = lock(out, manifestSha256, options.removeStaleLockPid); let index = { manifestSha256, results: [] }, current = null;
  try {
    for (const name of ['manifest.json.next', 'completed.json.next', 'current-phase.json.next', 'summary.json.next']) assert(!existsSync(join(out, name)), 'Unknown interrupted atomic update; preserve and inspect');
    if (existsSync(manifestPath)) assertResumeManifest(json(regular(manifestPath)), manifest); else { assert(!options.resumeDirectory); atomic(manifestPath, manifest); }
    if (existsSync(indexPath)) index = json(regular(indexPath)); else { assert(!options.resumeDirectory); atomic(indexPath, index); }
    assert.equal(index.manifestSha256, manifestSha256); assert(index.results.length <= selected.length);
    for (const [i, result] of index.results.entries()) {
      const row = rows[selected[i].commandCount - PREFIX - 1]; assert.equal(result.commandCount, selected[i].commandCount); assert.deepEqual(result.names, selected[i].names);
      assert.equal(result.beforeStateSha256, row.beforeStateSha256); assert.equal(result.stateSha256, row.afterStateSha256); assert.deepEqual(result.random, row.randomAfter); assert.deepEqual(result.checks, CHECKS);
    }
    if (existsSync(phasePath)) current = json(regular(phasePath));
    if (current) { assert.equal(current.manifestSha256, manifestSha256); const completed = index.results.find(r => r.commandCount === current.commandCount);
      assert(completed, 'UNKNOWN_INTERRUPTION: current SQLite case has no durable completed result; retain evidence for main/operator inspection'); cleanCase(work, completed); atomic(phasePath, null); current = null;
    } else assert(!existsSync(work), 'Unknown unindexed database must be inspected');
    const [slice, migration, owned, store, sqlite] = await Promise.all(['dist/domain/slice/index.js', 'dist/domain/slice/migration.js', 'dist/domain/red-priest/owned-session.js', 'dist/persistence/slice-store.js']
      .map(file => import(pathToFileURL(join(repo, file)).href)).concat(import('node:sqlite')));
    const runtime = { ...slice, ...migration, ...owned, ...store }, restoration = continuation?.transition?.commandCount === 974 ? continuation.transition : null;
    const logistics = (restoration ? continuation.nested : continuation)?.transition ?? null; let logisticsProjectionChecks = 0, recoveryProjectionChecks = 0;
    const priorRuntime = (view, count = true) => { const previous = restoration ? restoreBeforeRestoration(view) : view;
      if (count && restoration) recoveryProjectionChecks += Number(previous.actions.length !== view.actions.length) + Number(previous.sections.length !== view.sections.length); return previous; };
    const beforeLogistics = view => { const previous = restoreBeforeLogistics(view); if (previous.actions.length !== view.actions.length) logisticsProjectionChecks++; return previous; };
    const capturedPublic = (view, commandCount) => { const previous = restoration && commandCount <= 974 ? priorRuntime(view) : view; return logistics && commandCount <= 941 ? beforeLogistics(previous) : previous; };
    let state = runtime.migrateSliceState(old.final), session = null;
    for (const [key, value] of Object.entries(old.final)) if (!['schemaVersion', 'contentVersion', 'redPriest', 'fool'].includes(key)) assert.deepEqual(state[key], value);
    runtime.assertValidSliceState(state); assert.equal(stateHash(state), cp.initialStateSha256); let publicState = runtime.projectSliceState(state), view = publicState.redPriest;
    for (const row of rows) {
      const before = state, publicBefore = publicState; assert.equal(before.status, 'ACTIVE'); assert(runtime.validateSlicePayload(row.intent));
      assert.equal(stateHash(before), row.beforeStateSha256); assert.deepEqual(before.random, row.randomBefore);
      const historical = logistics && row.commandCount <= 941, recovery = restoration && row.commandCount <= 974;
      assert.equal(stateHash(capturedPublic(view, row.commandCount)), row.publicBeforeSha256);
      if (row.commandCount > 796) {
        if (recovery) assert.equal(stateHash(view), restoration.replay.rows[row.commandCount - PREFIX - 2].publicSha256);
        if (historical) assert.equal(stateHash(priorRuntime(view, false)), logistics.replay.rows[row.commandCount - PREFIX - 2].publicSha256);
      }
      const action = view.actions.find(a => stable(a.command) === stable(row.intent.command)); assert(action?.enabled); assert.equal(action.label, row.publicLabel);
      let publicAfter;
      if (session) { const draft = session.prepare(row.intent, before.revision); state = session.snapshotDraft(draft); view = session.projectDraftRedPriest(draft); publicAfter = session.projectDraft(draft); session.commit(draft); }
      else { assert.deepEqual(row.intent.command, { type: 'LEARN_GUIDANCE' }); state = runtime.applySliceIntent(before, row.intent); session = runtime.openRedPriestRuntimeSession(state); view = session.projectRedPriest(); publicAfter = session.project(); }
      assert.equal(stateHash(before), row.beforeStateSha256, 'Replay cannot mutate predecessor'); assert.equal(stateHash(state), row.afterStateSha256);
      assert.equal(state.revision, row.revision); assert.deepEqual(state.random, row.randomAfter); assert.equal(stateHash(capturedPublic(view, row.commandCount)), row.publicAfterSha256);
      if (historical) assert.equal(stateHash(priorRuntime(view)), logistics.replay.rows[row.commandCount - PREFIX - 1].publicSha256);
      if (recovery) { const check = restoration.replay.rows[row.commandCount - PREFIX - 1]; assert.equal(stateHash(view), check.publicSha256); assert.equal(stateHash(priorRuntime(view)), check.priorRuntimePublicSha256); }
      if (historical && row.commandCount === 941) { assert.equal(stateHash(beforeLogistics(priorRuntime(view, false))), PUBLIC_941_OLD); assert.equal(logisticsProjectionChecks, logistics.replay.addedProjectionChecks); }
      if (recovery && row.commandCount === 974) { assert.equal(stateHash(priorRuntime(view)), PUBLIC_974_OLD); assert.equal(recoveryProjectionChecks, restoration.replay.addedProjectionChecks); }
      assert.deepEqual(publicAfter.redPriest, view); publicState = publicAfter;
      const boundary = selected.find(item => item.commandCount === row.commandCount);
      if (boundary) {
        const done = index.results.find(item => item.commandCount === row.commandCount);
        if (done) { assert.equal(done.publicStateSha256, stateHash(publicAfter)); assert.equal(done.status, state.status); assert.equal(done.revision, state.revision); }
        else {
          const phase = name => { current = { manifestSha256, commandCount: row.commandCount, phase: name }; atomic(phasePath, current); };
          phase('SELECTED_REAL_TRANSITION'); const result = checkSqlite(runtime, sqlite.DatabaseSync, work, boundary, before, state, row.intent, publicBefore, publicAfter, phase);
          index.results.push(result); atomic(indexPath, index); cleanCase(work, result); atomic(phasePath, null); current = null;
        }
      }
      global.gc?.();
    }
    assert.equal(index.results.length, selected.length); assert.equal(stateHash(state), cp.finalStateSha256); assert.equal(stateHash(state), stateHash(capture.final));
    runtime.assertValidSliceState(state); const strict = runtime.openRedPriestRuntimeSession(state); assert.equal(stateHash(strict.snapshot()), cp.finalStateSha256); assert.equal(stateHash(strict.projectRedPriest()), cp.publicStateSha256);
    assert.deepEqual(json(join(root, 'summary.json')).public, { title: view.title, promoted: view.promoted, nextStep: view.nextStep, resources: view.resources, abilities: view.abilities, sections: view.sections });
    unchanged(); const summary = { passed: true, kind: FORMAT, manifestSha256, sourceDirectory: root, originalSourceSha256: SOURCE_SHA, prefixCommandsSha256: PREFIX_SHA,
      captureFreezeSha256: freeze.sha256, runtimeFreezeSha256: freeze.sha256, verifierSha256: options.verifierSha256, inputs, continuation,
      scope: { original795CommandsRetainedExactly: true, historical795Replay: 'NOT_RUN', newTail: 'EVERY_LEDGER_PRIVATE_RNG_AND_EXACT_CAPTURED_PUBLIC_BOUNDARY_VERIFIED',
        public941Transition: logistics ? { proofSha256: TRANSITION_SHA, originalCommandsVerified: 146, addedProjectionChecks: logisticsProjectionChecks, restoredOriginalPublic: 'ONLY_EXACT_APPENDED_RETURN_ACTION_REMOVED_FOR_HASH_COMPARISON', runtimePublic: 'EVERY_PINNED_PROOF_HASH_MATCHED_AFTER_EXACT_974_RESTORATION_IF_PRESENT' } : null,
        public974Transition: restoration ? { proofSha256: RESTORATION_SHA, originalCommandsVerified: 179, addedProjectionChecks: recoveryProjectionChecks, counterMeaning: 'DIAGNOSTIC_TRANSFORM_CALLS_NOT_BOUNDARY_COVERAGE', restoredOriginalPublic: 'ONLY_EXACT_RECOVERY_SUFFIX_AND_READINESS_SECTION_REMOVED_THEN_HISTORICAL_941_RETURN_SEAM', currentAndPriorRuntimePublic: 'EVERY_PINNED_PROOF_HASH_MATCHED' } : null,
        newCommandsReplayedThisInvocation: rows.length, sqlite: 'SELECTED_UNIQUE_ACTUAL_TRANSITIONS_ONLY', allCommandSqlite: false, syntheticDeath: 'NOT_RUN', desktop: 'NOT_RUN' },
      originalCommands: PREFIX, newCommands: rows.length, finalCommandCount: capture.commands.length, captureStage: capture.stage,
      selectedNames: selected.reduce((n, r) => n + r.names.length, 0), sqliteTransitionsVerified: index.results.length, coverage, results: index.results,
      final: { status: state.status, revision: state.revision, random: state.random, stateSha256: cp.finalStateSha256, publicChapterSha256: cp.publicStateSha256, publicStateSha256: stateHash(strict.project()) },
      elapsedMilliseconds: Math.round(performance.now() - started) };
    atomic(join(out, 'summary.json'), summary); return summary;
  } catch (error) {
    try { atomic(join(out, 'summary.json'), { passed: false, kind: FORMAT, manifestSha256, completedTransactions: index.results.length, currentPhase: current,
      error: String(error), interruptionMeaning: 'UNFINISHED_OR_UNKNOWN_IS_NOT_PASS; completed index retained; unfinished database must not be reset', elapsedMilliseconds: Math.round(performance.now() - started) }); } catch { /* preserve prior evidence */ }
    throw error;
  } finally { release(); }
}
export function argumentsForSave(args) {
  const out = {}, flags = { '--source-directory': 'sourceDirectory', '--output-directory': 'outputDirectory', '--resume-directory': 'resumeDirectory', '--freeze-sha256': 'freezeSha256', '--verifier-sha256': 'verifierSha256', '--remove-stale-lock-pid': 'removeStaleLockPid' };
  for (let i = 0; i < args.length; i++) {
    const flag = args[i]; if (flag === '--preflight' || flag === '--help') { const key = flag.slice(2); assert(!out[key]); out[key] = true; continue; }
    const key = flags[flag]; assert(key && out[key] === undefined && args[i + 1] !== undefined, `Unknown/duplicate/missing option ${flag}`); out[key] = args[++i];
    if (key === 'removeStaleLockPid') { assert(/^[1-9]\d*$/.test(out[key])); out[key] = Number(out[key]); assert(Number.isSafeInteger(out[key])); }
  }
  assert(!(out.outputDirectory && out.resumeDirectory)); return out;
}
if (process.argv[1] && resolve(process.argv[1]) === SELF) {
  try { const options = argumentsForSave(process.argv.slice(2));
    if (options.help) console.log('node --expose-gc --max-old-space-size=1024 scripts/verify/red-priest-save.mjs --source-directory EXACT_TERMINAL_CAPTURE --freeze-sha256 REVIEWED_FREEZE --verifier-sha256 REVIEWED_VERIFIER [--preflight | --output-directory output/qa-0209/sqlite | --resume-directory EXACT_AUDIT_DIR]. Explicit main/operator stale-lock approval only: --remove-stale-lock-pid DEAD_PID. Preflight performs no runtime import, SQLite, replay or write. Unknown interrupted SQLite cases stop for inspection. Original795 is retained, not replayed; new tail replays once; only selected actual transitions use SQLite.');
    else console.log(JSON.stringify(await verifyRedPriestCapture(options)));
  } catch (error) { console.error(error); process.exitCode = 1; }
}
