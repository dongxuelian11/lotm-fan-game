"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.openRedPriestRuntimeSession = void 0;
var index_js_1 = require("../slice/index.js");
Object.defineProperty(exports, "openRedPriestRuntimeSession", { enumerable: true, get: function () { return index_js_1.openRedPriestRuntimeSession; } });
//# sourceMappingURL=owned-session.js.map