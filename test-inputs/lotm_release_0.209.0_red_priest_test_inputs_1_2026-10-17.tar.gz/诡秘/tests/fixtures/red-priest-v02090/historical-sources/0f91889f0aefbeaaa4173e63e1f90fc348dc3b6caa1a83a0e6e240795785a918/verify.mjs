import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { ALLOWED_PUBLIC_CHANGES, stripHistoricalStabilityAdditions } from './public-equivalence.mjs';

const ROOT = process.cwd(), OUT = dirname(fileURLToPath(import.meta.url));
const BASE = 'output/play/red-priest-02090-planned-continued';
const PRIOR = 'output/play/red-priest-02090-planned';
const MANIFEST = `${BASE}.all-files.json`, BEFORE = 'output/qa-0209/pre-stability';
const OLD_PRODUCER = 'scripts/play/red-priest-planned-continue.mjs';
const FIRST_PRODUCER = 'scripts/play/red-priest-planned-stage.mjs';
const PLANNING_PROOF = 'output/qa-0209/planning-equivalence/proof.json';
const SOURCE918 = 'output/qa-0209/planning-candidate/original-918-checkpoint.json';
const RECONSTRUCTION = 'output/qa-0209/planning-candidate/reconstruction-proof.json';
const ALLOWED_CHANGES = [
  'src/domain/red-priest/types.ts', 'src/domain/red-priest/content.ts', 'src/domain/red-priest/engine.ts',
  'src/domain/red-priest/epilogue.ts', 'src/domain/red-priest/index.ts', 'src/renderer/RedPriestPanel.tsx',
  'dist/domain/red-priest/types.js', 'dist/domain/red-priest/types.js.map',
  'dist/domain/red-priest/content.js', 'dist/domain/red-priest/content.js.map',
  'dist/domain/red-priest/engine.js', 'dist/domain/red-priest/engine.js.map',
  'dist/domain/red-priest/epilogue.js', 'dist/domain/red-priest/epilogue.js.map',
  'dist/domain/red-priest/index.js', 'dist/domain/red-priest/index.js.map',
];
const PRODUCTION_ROOTS = ['package.json', 'package-lock.json', 'src', 'dist/domain', 'dist/content',
  'dist/resolution', 'dist/persistence', 'dist/shared', 'dist/application', 'dist/simulation'];
const sha = value => createHash('sha256').update(value).digest('hex');
const stable = value => Array.isArray(value) ? `[${value.map(stable).join(',')}]` : value && typeof value === 'object'
  ? `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stable(value[key])}`).join(',')}}` : JSON.stringify(value);
const hash = value => sha(stable(value)), compactHash = value => sha(JSON.stringify(value));
const read = path => readFileSync(resolve(ROOT, path));
const json = path => JSON.parse(read(path));
function evidence(path) {
  const absolute = resolve(ROOT, path), before = lstatSync(absolute, { bigint: true });
  assert(before.isFile() && !before.isSymbolicLink(), `Not a regular frozen file: ${path}`);
  const bytes = readFileSync(absolute), after = lstatSync(absolute, { bigint: true });
  for (const key of ['size', 'mtimeNs', 'ctimeNs', 'ino']) assert.equal(after[key], before[key], `File changed during hashing: ${path}`);
  assert.equal(BigInt(bytes.length), after.size);
  return { bytes: bytes.length, sha256: sha(bytes) };
}
function assertFile(path, pin) {
  assert.deepEqual(evidence(path), { bytes: pin.bytes, sha256: pin.sha256 }, `Frozen input changed: ${path}`);
}
function create(path, value) {
  const bytes = Buffer.from(JSON.stringify(value, null, 2) + '\n');
  if (existsSync(path)) { assert.deepEqual(readFileSync(path), bytes, `Refusing to overwrite different proof: ${path}`); return; }
  mkdirSync(dirname(path), { recursive: true }); writeFileSync(path, bytes, { flag: 'wx' });
}
function pathsWithin(directory) {
  const result = [];
  function walk(path, relative = '') {
    const stat = lstatSync(path); assert(!stat.isSymbolicLink(), `No symbolic links in sealed inputs: ${path}`);
    if (stat.isDirectory()) for (const name of readdirSync(path).sort()) walk(join(path, name), join(relative, name));
    else { assert(stat.isFile(), `Unexpected non-file: ${path}`); result.push(relative.split(sep).join('/')); }
  }
  walk(resolve(ROOT, directory)); return result.sort();
}
function currentFreeze(source) {
  const files = [];
  function walk(name) {
    const stat = lstatSync(resolve(ROOT, name)); assert(!stat.isSymbolicLink(), `No symbolic links in production: ${name}`);
    if (stat.isDirectory()) for (const child of readdirSync(resolve(ROOT, name)).sort()) walk(join(name, child));
    else { assert(stat.isFile()); files.push({ file: name.split(sep).join('/'), ...evidence(name) }); }
  }
  for (const root of PRODUCTION_ROOTS) walk(root);
  files.push({ file: source, ...evidence(source) });
  return { sha256: compactHash(files), files };
}

assert.deepEqual(process.argv.slice(2).filter(arg => !['--preflight', '--execute'].includes(arg)), []);
assert.equal(process.argv.length, 3, 'Choose --preflight (no runtime import) or explicitly authorized --execute');
const execute = process.argv[2] === '--execute';
const pinnedInputs = [
  [MANIFEST, '9964baf7e73d054affe8769111f28e780c574d63529770b93a7d5301b0a01217'],
  [`${BEFORE}/manifest.json`, '517b8287aaf6384028df2dfd847fb667692039d8a6a5561d23ae892a8c39b03f'],
  [PLANNING_PROOF, '9f64e510ace5f5f484ad2869a8bc616c668231ac345383695740a4edd065a3c3'],
  [SOURCE918, '2ab728663f4ce0096a94e49279a5feadda378f64629dd4ec6ccff785db60c68b'],
  [RECONSTRUCTION, '398f3854fc323bc106f58b0133cf702cce1a9b234bca850ccc416a21570611c5'],
];
for (const [path, digest] of pinnedInputs) assert.equal(evidence(path).sha256, digest, `Historical pin changed: ${path}`);
const sealed = json(MANIFEST); assert.equal(sealed.length, 7);
assert.deepEqual(pathsWithin(BASE), sealed.map(entry => entry.path).sort(), 'The original seven-file observation must remain sealed');
for (const entry of sealed) assertFile(join(BASE, entry.path), entry);
const wrapped = json(`${BASE}/checkpoint.json`), cp = wrapped.payload;
assert.equal(wrapped.sha256, hash(cp)); assert.equal(wrapped.sha256, '0ab3ef4e30ca552ed16611439a270ac921f0d1763af3854b3d3cb58c95290a88');
assert.equal(cp.commandCount, 1137); assert.equal(cp.prefixCount, 918); assert.equal(cp.rows.length, 219); assert.equal(cp.commands.length, 219);
assert.equal(cp.pending, null); assert.equal(cp.terminal.stage, 'FINITE_MATERIAL_ATTEMPTS');
assert.equal(cp.initialStateSha256, '779ef84dfc74b9abbfe1e97c9bff206c683a9b18d3957d6603661f9748b38acd');
assert.equal(cp.finalStateSha256, 'ef0a3d0bad112bb15156257e905d65c00dbadce7c79914d58fa097d52c8062bc');
assert.equal(cp.publicStateSha256, '5bfa25052d1fb2a01c8d0f1ce8424d0318477aabfe6f5baf0e778ce97490f354');
assert.equal(hash(cp.state), cp.finalStateSha256);
assert.deepEqual(cp.state.random, { seed: 'hunter-rebuild-first', cursor: 477 });
assert.deepEqual(read(`${BASE}/commands.ndjson`).toString().trim().split('\n').map(line => JSON.parse(line)), cp.rows);
const natural = json(`${BASE}/natural.json`);
assert.equal(natural.commands.length, 1137); assert.equal(natural.prefixCount, 918); assert.deepEqual(natural.final, cp.state);
assert.deepEqual(natural.commands.slice(918), cp.commands); assert.equal(compactHash(natural.commands.slice(0, 918)), cp.prefixSha256);
for (let index = 0; index < cp.rows.length; index++) {
  const row = cp.rows[index]; assert.equal(row.commandCount, index + 919);
  assert.deepEqual(row.intent, cp.commands[index]); assert.equal(row.commandSha256, compactHash(row.intent));
  const before = index ? cp.rows[index - 1] : null;
  assert.equal(row.beforeStateSha256, before?.afterStateSha256 ?? cp.initialStateSha256);
  assert.equal(row.publicBeforeSha256, before?.publicAfterSha256 ?? cp.initialPublicStateSha256);
  assert.deepEqual(row.randomBefore, before?.randomAfter ?? { seed: 'hunter-rebuild-first', cursor: 423 });
}
assert.equal(cp.rows.at(-1).afterStateSha256, cp.finalStateSha256); assert.equal(cp.rows.at(-1).publicAfterSha256, cp.publicStateSha256);
assert.deepEqual(cp.rows.filter(row => row.intent.command.type === 'CONSUME').map(row => row.commandCount), [1031, 1114]);
assert(!cp.commands.some(intent => ['STABILIZE_PROMOTION', 'START_PREPARED_EPILOGUE', 'OPEN_PREPARED_EPILOGUE'].includes(intent.command.type)));
const root918 = json(SOURCE918); assert.equal(root918.sha256, hash(root918.payload));
assert.equal(hash(root918.payload.state), cp.initialStateSha256);
assert.deepEqual(natural.commands.slice(795, 918), root918.payload.commands);
const reconstruction = json(RECONSTRUCTION); assertFile(SOURCE918, reconstruction.checkpoint);
assert.equal(reconstruction.allPrivatePublicAndRngEqual, true); assert.equal(reconstruction.strictFinalValidation, true);
const oldFreeze = json(`${BASE}/freeze.json`), oldPins = new Map(oldFreeze.files.map(entry => [entry.file, entry]));
assert.equal(oldFreeze.sha256, compactHash(oldFreeze.files)); assert.equal(oldFreeze.sha256, cp.freezeSha256);
assert.equal(oldFreeze.sha256, 'f0b74f904c2bdc58838d013daf1a9669462582af04d412c7d0e0d35308edac4a');
assert.equal(oldPins.size, oldFreeze.files.length); assert.equal(oldPins.size, 4062); assertFile(OLD_PRODUCER, oldPins.get('$natural-producer'));
assertFile(cp.source, { bytes: oldPins.get(cp.source).bytes, sha256: cp.sourceSha256 });
const planningProof = json(PLANNING_PROOF);
assert.equal(planningProof.format, 'RED_PRIEST983_PLANNING_TRANSITION_V1');
assert.equal(planningProof.replay.commands, 188); assert.equal(planningProof.replay.rows.length, 188);
assert.equal(planningProof.replay.allPrivateAndRngEqual, true); assert.equal(planningProof.replay.allExistingPublicFieldsEqual, true);
assert.equal(planningProof.strictFinalValidation, true);
assert.deepEqual(oldFreeze.files.filter(entry => entry.file !== '$natural-producer'), planningProof.currentRuntimeFreeze.files,
  'The 1137 observation must use exactly the already-proved planning runtime');
const original983 = planningProof.original983Capture;
assert.equal(original983.manifestEvidence.sha256, '24d971395d08ca7b031d51d79c17a75681ccf7e3fe78a076f79b84f917acf909');
assertFile(original983.manifest, original983.manifestEvidence); assert.deepEqual(json(original983.manifest), original983.files);
assert.equal(original983.files.length, 57); assert.deepEqual(pathsWithin(original983.directory), original983.files.map(entry => entry.path).sort());
for (const entry of original983.files) assertFile(join(original983.directory, entry.path), entry);
assertFile(original983.producer.path, original983.producer);
const transition918 = json(`${BASE}/runtime-transition.json`);
assert.equal(transition918.format, 'RED_PRIEST918_PLANNING_TRANSITION_V1'); assert.equal(transition918.commandCount, 918);
assert.equal(transition918.newRuntimeFreezeSha256, oldFreeze.sha256); assert.equal(transition918.stateSha256, cp.initialStateSha256);
assert.equal(transition918.continuedPublicSha256, cp.initialPublicStateSha256);
assert.equal(transition918.original983Replay.proofSha256, evidence(PLANNING_PROOF).sha256);
assert.equal(evidence(`${BASE}/runtime-transition.json`).sha256, cp.fork.runtimeProofSha256);
const continuation = json(`${BASE}/continuation.json`);
assert.equal(evidence(`${BASE}/continuation.json`).sha256, cp.continuation.proofSha256);
assert.equal(continuation.format, 'RED_PRIEST1017_ARMISTICE_OBSERVATION_CONTINUATION_V1');
assert.deepEqual(continuation.onlyAllowedFreezeChange, ['$natural-producer']); assert.equal(continuation.newFreezeSha256, oldFreeze.sha256);
for (const entry of continuation.originalCapture.files) assertFile(join(PRIOR, entry.file), entry);
assert.deepEqual(pathsWithin(PRIOR), continuation.originalCapture.files.map(entry => entry.file).sort());
assertFile(FIRST_PRODUCER, continuation.originalCapture.producer);
const priorWrapped = json(`${PRIOR}/checkpoint.json`), prior = priorWrapped.payload;
assert.equal(priorWrapped.sha256, hash(prior)); assert.equal(priorWrapped.sha256, continuation.originalCapture.checkpointPayloadSha256);
assert.equal(prior.commandCount, 1017); assert.deepEqual(cp.rows.slice(0, 99), prior.rows); assert.deepEqual(cp.commands.slice(0, 99), prior.commands);
assert.equal(compactHash(prior.rows), continuation.originalRowsSha256); assert.equal(compactHash(prior.commands), continuation.originalCommandsSha256);
assert.deepEqual(prior.policyDefinition, continuation.originalPolicyDefinition); assert.deepEqual(cp.policyDefinition, continuation.continuedPolicyDefinition);
const priorFreeze = json(`${PRIOR}/freeze.json`); assert.equal(priorFreeze.sha256, compactHash(priorFreeze.files));
assert.deepEqual(priorFreeze.files.filter(entry => entry.file !== '$natural-producer'), oldFreeze.files.filter(entry => entry.file !== '$natural-producer'));
const archive = json(`${BEFORE}/manifest.json`); assert.equal(archive.length, 36);
for (const entry of archive) assertFile(join(BEFORE, entry.path), entry);
const archivePins = new Map(archive.map(entry => [entry.path, entry]));
for (const path of [OLD_PRODUCER, FIRST_PRODUCER]) assertFile(path, archivePins.get(path));
for (const path of ALLOWED_CHANGES) {
  assert(archivePins.has(path), `Unarchived source change: ${path}`);
  assert.deepEqual({ bytes: archivePins.get(path).bytes, sha256: archivePins.get(path).sha256 },
    { bytes: oldPins.get(path).bytes, sha256: oldPins.get(path).sha256 });
}
const currentRuntimeFreeze = currentFreeze(cp.source);
assert.deepEqual(currentRuntimeFreeze.files.map(entry => entry.file), oldFreeze.files.filter(entry => entry.file !== '$natural-producer').map(entry => entry.file));
const changedFiles = [], originalRuntimeFiles = [];
for (const entry of currentRuntimeFreeze.files) {
  const old = oldPins.get(entry.file), changed = entry.bytes !== old.bytes || entry.sha256 !== old.sha256;
  if (changed) {
    assert(ALLOWED_CHANGES.includes(entry.file), `Unapproved production change: ${entry.file}`);
    changedFiles.push({ file: entry.file, before: { bytes: old.bytes, sha256: old.sha256 }, after: { bytes: entry.bytes, sha256: entry.sha256 } });
  }
  const source = changed ? join(BEFORE, entry.file) : entry.file;
  assertFile(source, old); originalRuntimeFiles.push({ ...old, source });
}
// Type-only exports/interfaces may leave types.js and epilogue.js byte-identical; every changed byte still
// requires an explicit listed path, and every substantive source must be built.
const optionalTypeOnlyArtifacts = ['dist/domain/red-priest/types.js', 'dist/domain/red-priest/types.js.map',
  'dist/domain/red-priest/epilogue.js', 'dist/domain/red-priest/epilogue.js.map'];
const requiredChanges = ALLOWED_CHANGES.filter(path => !optionalTypeOnlyArtifacts.includes(path));
for (const path of requiredChanges) assert(changedFiles.some(entry => entry.file === path), `Integrate and build the reviewed candidate first: ${path}`);
const inputMap = new Map();
function bind(path, pin = evidence(path)) { assertFile(path, pin); inputMap.set(path, { path, bytes: pin.bytes, sha256: pin.sha256 }); }
for (const entry of sealed) bind(join(BASE, entry.path), entry);
for (const entry of continuation.originalCapture.files) bind(join(PRIOR, entry.file), entry);
for (const entry of original983.files) bind(join(original983.directory, entry.path), entry);
for (const entry of archive) bind(join(BEFORE, entry.path), entry);
for (const entry of originalRuntimeFiles) if (entry.source !== entry.file) bind(entry.source, entry);
for (const [path] of pinnedInputs) bind(path);
for (const path of [OLD_PRODUCER, FIRST_PRODUCER, original983.manifest, original983.producer.path,
  'output/qa-0209/planning-equivalence/verify.mjs', 'output/qa-0209/planning-equivalence/public-equivalence.mjs',
  fileURLToPath(import.meta.url), join(OUT, 'public-equivalence.mjs')]) bind(path);
assert.equal(evidence('output/qa-0209/planning-equivalence/verify.mjs').sha256, planningProof.scriptSha256);
assert.equal(evidence('output/qa-0209/planning-equivalence/public-equivalence.mjs').sha256, planningProof.normalizerSha256);
const inputFiles = [...inputMap.values()], inputStartSha256 = hash(inputFiles);
const source1137 = { directory: BASE, checkpointFile: `${BASE}/checkpoint.json`, checkpoint: evidence(`${BASE}/checkpoint.json`),
  payloadSha256: wrapped.sha256, commandCount: 1137, stateSha256: cp.finalStateSha256, publicSha256: cp.publicStateSha256, random: cp.state.random };
const original1137Capture = { directory: BASE, manifest: MANIFEST, manifestEvidence: evidence(MANIFEST), files: sealed,
  producer: { path: OLD_PRODUCER, ...evidence(OLD_PRODUCER) }, freezeSha256: oldFreeze.sha256,
  checkpoint: source1137.checkpoint, payloadSha256: wrapped.sha256, stage: cp.terminal.stage };
const preflight = { format: 'RED_PRIEST1137_STABILITY_TRANSITION_PREFLIGHT_V1', source1137, original1137Capture,
  originalFreezeSha256: oldFreeze.sha256, currentRuntimeFreeze, originalRuntimeFiles, changedFiles, allowedChanges: ALLOWED_CHANGES,
  original983Replay: { proofFile: PLANNING_PROOF, proofSha256: evidence(PLANNING_PROOF).sha256 },
  allowedPublicChanges: ALLOWED_PUBLIC_CHANGES, inputFiles, inputStartSha256,
  scriptSha256: evidence(fileURLToPath(import.meta.url)).sha256, normalizerSha256: evidence(join(OUT, 'public-equivalence.mjs')).sha256 };
if (!execute) {
  create(join(OUT, 'preflight.json'), preflight);
  console.log(JSON.stringify({ passed: true, runtimeLoaded: false, commands: 219, sealed1137Files: 7, sealed983Files: 57,
    productionFiles: currentRuntimeFreeze.files.length, changedFiles: changedFiles.map(entry => entry.file),
    executeCommand: 'node --max-old-space-size=1024 output/qa-0209/stability-equivalence/verify.mjs --execute' })); process.exit(0);
}
if (existsSync(join(OUT, 'preflight.json'))) assert.deepEqual(json(join(OUT, 'preflight.json')), preflight, 'Inputs changed after preflight');
const slice = await import(pathToFileURL(resolve(ROOT, 'dist/domain/slice/index.js')).href);
let state = root918.payload.state, stateSha256 = hash(state);
let session = slice.openRedPriestRuntimeSession(state), view = session.projectRedPriest();
assert.equal(hash(session.snapshot()), cp.initialStateSha256);
const rows = [], consumptionChecks = []; let actionChecks = 0, sectionChecks = 0, normalizerNegativeTests = null;
function checkPublic(publicView, snapshot, expected, commandCount) {
  const normalized = stripHistoricalStabilityAdditions(publicView, snapshot);
  assert.equal(hash(normalized.prior), expected, `Existing public values changed at ${commandCount}`);
  actionChecks += normalized.actionsRemoved; sectionChecks += normalized.sectionsRemoved;
  return { full: hash(publicView), prior: hash(normalized.prior), additionsSha256: hash(normalized.additions),
    additions: normalized.additions, actionsRemoved: normalized.actionsRemoved, sectionsRemoved: normalized.sectionsRemoved };
}
function runNormalizerNegativeTests(publicView, snapshot, capturedPublicSha256, commandCount) {
  const checks = [];
  const gate = candidate => assert.equal(hash(stripHistoricalStabilityAdditions(candidate, snapshot).prior), capturedPublicSha256);
  gate(publicView);
  const mutations = [
    ['missing-new-section', value => { value.sections.pop(); }],
    ['missing-new-action', value => { value.actions.pop(); }],
    ['extra-new-section', value => { value.sections.push(structuredClone(value.sections.at(-1))); }],
    ['extra-new-action', value => { value.actions.push(structuredClone(value.actions.at(-1))); }],
    ['changed-preparation-cost', value => { value.actions.at(-1).cost += ' altered'; }],
    ['changed-preparation-section', value => { value.sections.at(-1).lines[0] += ' altered'; }],
    ['changed-original-resource', value => { value.resources.health += 1; }],
    ['changed-original-action-cost', value => { value.actions[0].cost += ' altered'; }],
    ['removed-original-section', value => { value.sections.splice(0, 1); }],
    ['misplaced-new-action', value => { const added = value.actions.pop(); value.actions.unshift(added); }],
  ];
  for (const [name, mutate] of mutations) {
    const candidate = structuredClone(publicView); mutate(candidate);
    assert.throws(() => gate(candidate), { name: 'AssertionError' }, `Normalizer incorrectly accepted ${name}`);
    checks.push({ name, rejected: true });
  }
  assert.throws(() => assert.equal(hash(publicView), capturedPublicSha256), { name: 'AssertionError' }, 'Complete hash gate must reject under-removal');
  checks.push({ name: 'under-removal-rejected-by-complete-public-hash', rejected: true });
  const overRemoved = stripHistoricalStabilityAdditions(publicView, snapshot).prior;
  overRemoved.actions.pop();
  assert.throws(() => assert.equal(hash(overRemoved), capturedPublicSha256), { name: 'AssertionError' }, 'Complete hash gate must reject over-removal');
  checks.push({ name: 'over-removal-rejected-by-complete-public-hash', rejected: true });
  return { commandCount, observedStateSha256: hash(snapshot), observedPublicSha256: hash(publicView),
    capturedPublicSha256, positiveControlPassed: true, noAdditionalReplay: true, rejectedMutations: checks.length, checks };
}
let publicCheck = checkPublic(view, state, cp.initialPublicStateSha256, 918);
for (const row of cp.rows) {
  assert.equal(stateSha256, row.beforeStateSha256); assert.deepEqual(state.random, row.randomBefore);
  assert.equal(publicCheck.prior, row.publicBeforeSha256);
  const before = publicCheck, offered = view.actions.filter(action => stable(action.command) === stable(row.intent.command));
  assert.equal(offered.length, 1); assert.equal(offered[0].enabled, true); assert.equal(offered[0].label, row.publicLabel);
  const draft = session.prepare(row.intent, state.revision), next = session.snapshotDraft(draft), afterView = session.projectDraftRedPriest(draft);
  const nextSha256 = hash(next); assert.equal(nextSha256, row.afterStateSha256, `Private mismatch at ${row.commandCount}`);
  assert.deepEqual(next.random, row.randomAfter); assert.equal(next.revision, row.revision);
  const after = checkPublic(afterView, next, row.publicAfterSha256, row.commandCount);
  if (after.actionsRemoved && normalizerNegativeTests === null)
    normalizerNegativeTests = runNormalizerNegativeTests(afterView, next, row.publicAfterSha256, row.commandCount);
  if (row.intent.command.type === 'CONSUME') {
    const event = next.redPriest.journal.at(-1), expectedRoll = row.commandCount === 1031 ? 42 : 58;
    assert.deepEqual(event.command, row.intent.command); assert.equal(event.randomReceipts.length, 1);
    const receipt = event.randomReceipts[0]; assert.equal(receipt.check.chance, 5); assert.equal(receipt.check.roll, expectedRoll);
    assert.equal(receipt.check.tier, 'FAILURE'); assert.equal(receipt.check.effectiveAbility, 29); assert.deepEqual(receipt.check.modifiers, []);
    assert.equal(event.materialReceipt.consumption.outcome, 'FAILURE'); assert.equal(next.progression.sequence, 1);
    consumptionChecks.push({ commandCount: row.commandCount, compoundId: row.intent.command.compoundId,
      chance: 5, roll: expectedRoll, tier: 'FAILURE', outcome: 'FAILURE', randomBefore: row.randomBefore, randomAfter: row.randomAfter,
      stateSha256: nextSha256, unchangedHistoricalEventSha256: hash(event) });
  }
  rows.push({ commandCount: row.commandCount, commandSha256: row.commandSha256, beforeStateSha256: row.beforeStateSha256,
    stateSha256: nextSha256, randomBefore: row.randomBefore, random: next.random,
    capturedPublicBeforeSha256: row.publicBeforeSha256, capturedPublicSha256: row.publicAfterSha256,
    publicBeforeSha256: before.full, publicSha256: after.full,
    priorRuntimePublicBeforeSha256: before.prior, priorRuntimePublicSha256: after.prior,
    publicAdditionBeforeSha256: before.additionsSha256, publicAdditionSha256: after.additionsSha256,
    stabilityActionsAddedBefore: before.actionsRemoved, stabilityActionsAddedAfter: after.actionsRemoved,
    stabilitySectionsAddedBefore: before.sectionsRemoved, stabilitySectionsAddedAfter: after.sectionsRemoved,
    privateAndRngEqual: true, allExistingPublicFieldsEqual: true, enabledOriginalAction: true });
  session.commit(draft); state = next; stateSha256 = nextSha256; view = afterView; publicCheck = after;
  if (rows.length % 20 === 0 || rows.length === 219) console.log(JSON.stringify({ verified: rows.length, commandCount: row.commandCount,
    privateAndRngEqual: true, exactPublicAdditionsOnly: true }));
}
assert.deepEqual(state, cp.state); assert.equal(stateSha256, cp.finalStateSha256); assert.equal(consumptionChecks.length, 2);
assert.equal(actionChecks, 6); assert.equal(sectionChecks, 6);
assert.equal(normalizerNegativeTests?.commandCount, 1028); assert.equal(normalizerNegativeTests.rejectedMutations, 12);
assert.deepEqual(rows.filter(row => row.stabilityActionsAddedAfter).map(row => row.commandCount), [1028, 1029, 1030, 1111, 1112, 1113]);
assert.deepEqual(rows.filter(row => row.stabilityActionsAddedBefore).map(row => row.commandCount), [1029, 1030, 1031, 1112, 1113, 1114]);
assert.equal(view.actions.filter(action => action.command.type === 'STABILIZE_PROMOTION').length, 0);
assert.equal(hash(view), cp.publicStateSha256, 'The original 1137 boundary has no prepared compound and must be public-byte-value exact');
slice.assertValidSliceState(state); assert.equal(hash(session.snapshot()), cp.finalStateSha256);
assert.equal(state.progression.sequence, 1); assert.equal(state.redPriest.epilogue, null);
assert(!Object.hasOwn(state.redPriest, 'promotionStability')); assert.deepEqual(state.random, { seed: 'hunter-rebuild-first', cursor: 477 });
const runtimeEnd = currentFreeze(cp.source); assert.deepEqual(runtimeEnd, currentRuntimeFreeze);
assert.deepEqual(pathsWithin(BASE), sealed.map(entry => entry.path).sort());
assert.deepEqual(pathsWithin(PRIOR), continuation.originalCapture.files.map(entry => entry.file).sort());
assert.deepEqual(pathsWithin(original983.directory), original983.files.map(entry => entry.path).sort());
for (const entry of inputFiles) assertFile(entry.path, entry);
const inputEndSha256 = hash(inputFiles.map(entry => ({ path: entry.path, ...evidence(entry.path) }))); assert.equal(inputEndSha256, inputStartSha256);
const result = { format: 'RED_PRIEST1137_STABILITY_TRANSITION_V1', commandCount: 1137, source1137, original1137Capture,
  originalFreezeSha256: oldFreeze.sha256, currentRuntimeFreeze, originalRuntimeFiles, changedFiles, allowedChanges: ALLOWED_CHANGES,
  original983Replay: preflight.original983Replay, initialStateSha256: cp.initialStateSha256,
  stateSha256, originalPublicSha256: cp.publicStateSha256, continuedPublicSha256: hash(view), random: state.random,
  strictFinalValidation: true, unchangedHistoricalConsumptionChecks: consumptionChecks, normalizerNegativeTests,
  replay: { commands: 219, first: 919, last: 1137, allPrivateAndRngEqual: true, allExistingPublicFieldsEqual: true,
    allowedPublicChanges: ALLOWED_PUBLIC_CHANGES, publicDifference: 'Only exact appended stabilization actions and the exact appended stability section at recorded PREPARED-compound windows',
    addedActionChecks: actionChecks, addedSectionChecks: sectionChecks, rows },
  inputFiles, inputStartSha256, inputEndSha256, currentRuntimeEndSha256: runtimeEnd.sha256,
  originalInputsUnchanged: true, productionUnchangedDuringReplay: true,
  scriptSha256: preflight.scriptSha256, normalizerSha256: preflight.normalizerSha256 };
create(join(OUT, 'proof.json'), result);
console.log(JSON.stringify({ passed: 219, strictFinalValidation: true, original1137Intact: true, original983Intact: true,
  historicalConsumptions: consumptionChecks, finalStateSha256: stateSha256, finalPublicSha256: result.continuedPublicSha256,
  productionFreezeSha256: currentRuntimeFreeze.sha256, proofSha256: evidence(join(OUT, 'proof.json')).sha256 }));
