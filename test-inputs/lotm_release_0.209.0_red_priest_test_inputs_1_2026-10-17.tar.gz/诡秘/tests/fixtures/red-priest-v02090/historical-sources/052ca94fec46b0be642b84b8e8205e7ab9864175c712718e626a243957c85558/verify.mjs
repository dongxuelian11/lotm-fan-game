import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { stripPlanningActivation } from './public-equivalence.mjs';

const ROOT = process.cwd(), OUT = dirname(fileURLToPath(import.meta.url));
const BASE = 'output/play/red-priest-02090-recovery';
const MANIFEST = `${BASE}.all-files.json`, OLD_PRODUCER = `${BASE}.producer.mjs`;
const BEFORE = 'output/qa-0209/pre-planning';
const HQ_PROOF = `${BASE}/prior-proof/runtime-transition.json`;
const LOGISTICS_PROOF = `${BASE}/prior-observation/prior-proof/runtime-transition.json`;
const SOURCE918 = 'output/qa-0209/planning-candidate/original-918-checkpoint.json';
const RECONSTRUCTION = 'output/qa-0209/planning-candidate/reconstruction-proof.json';
const ALLOWED_CHANGES = [
  'src/domain/red-priest/campaign.ts', 'src/domain/red-priest/engine.ts', 'src/domain/red-priest/index.ts',
  'src/renderer/RedPriestPanel.tsx',
  'dist/domain/red-priest/campaign.js', 'dist/domain/red-priest/campaign.js.map',
  'dist/domain/red-priest/engine.js', 'dist/domain/red-priest/engine.js.map',
  'dist/domain/red-priest/index.js', 'dist/domain/red-priest/index.js.map',
];
const PRODUCTION_ROOTS = ['package.json', 'package-lock.json', 'src', 'dist/domain', 'dist/content',
  'dist/resolution', 'dist/persistence', 'dist/shared', 'dist/application', 'dist/simulation'];
const sha = value => createHash('sha256').update(value).digest('hex');
const stable = value => Array.isArray(value) ? `[${value.map(stable).join(',')}]` : value && typeof value === 'object'
  ? `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stable(value[key])}`).join(',')}}` : JSON.stringify(value);
const hash = value => sha(stable(value)), compactHash = value => sha(JSON.stringify(value));
const read = path => readFileSync(resolve(ROOT, path));
const json = path => JSON.parse(read(path));
function evidence(path) {
  const absolute = resolve(ROOT, path), before = lstatSync(absolute, { bigint: true });
  assert(before.isFile() && !before.isSymbolicLink(), `Not a regular frozen file: ${path}`);
  const bytes = readFileSync(absolute), after = lstatSync(absolute, { bigint: true });
  for (const key of ['size', 'mtimeNs', 'ctimeNs', 'ino']) assert.equal(after[key], before[key], `File changed during hashing: ${path}`);
  assert.equal(BigInt(bytes.length), after.size);
  return { bytes: bytes.length, sha256: sha(bytes) };
}
function assertFile(path, pin) {
  assert.deepEqual(evidence(path), { bytes: pin.bytes, sha256: pin.sha256 }, `Frozen input changed: ${path}`);
}
function create(path, value) {
  const bytes = Buffer.from(JSON.stringify(value, null, 2) + '\n');
  if (existsSync(path)) { assert.deepEqual(readFileSync(path), bytes, `Refusing to overwrite different proof: ${path}`); return; }
  mkdirSync(dirname(path), { recursive: true }); writeFileSync(path, bytes, { flag: 'wx' });
}
function pathsWithin(directory) {
  const result = [];
  function walk(path, relative = '') {
    const stat = lstatSync(path); assert(!stat.isSymbolicLink(), `No symbolic links in sealed inputs: ${path}`);
    if (stat.isDirectory()) for (const name of readdirSync(path).sort()) walk(join(path, name), join(relative, name));
    else { assert(stat.isFile(), `Unexpected non-file: ${path}`); result.push(relative.split(sep).join('/')); }
  }
  walk(resolve(ROOT, directory)); return result.sort();
}
function currentFreeze(source) {
  const files = [];
  function walk(name) {
    const stat = lstatSync(resolve(ROOT, name)); assert(!stat.isSymbolicLink(), `No symbolic links in production: ${name}`);
    if (stat.isDirectory()) for (const child of readdirSync(resolve(ROOT, name)).sort()) walk(join(name, child));
    else { assert(stat.isFile()); files.push({ file: name.split(sep).join('/'), ...evidence(name) }); }
  }
  for (const root of PRODUCTION_ROOTS) walk(root);
  files.push({ file: source, ...evidence(source) });
  return { sha256: compactHash(files), files };
}

assert.deepEqual(process.argv.slice(2).filter(arg => !['--preflight', '--execute'].includes(arg)), []);
assert.equal(process.argv.length, 3, 'Choose --preflight (no runtime import) or explicitly authorized --execute');
const execute = process.argv[2] === '--execute';
assert.equal(evidence(MANIFEST).sha256, '24d971395d08ca7b031d51d79c17a75681ccf7e3fe78a076f79b84f917acf909');
assert.equal(evidence(`${BEFORE}/manifest.json`).sha256, 'db83a6a5a05a3d2ba1704d0f0b65846ed3a3586c0896fec2105361a3fc77a94b');
assert.equal(evidence(HQ_PROOF).sha256, 'c5fa12707cde98bba0a775475d274c369f68267fe5d2991e5a04acaabb3ad201');
assert.equal(evidence(LOGISTICS_PROOF).sha256, '3dbc170abff8c7310dd384677469a19d9f9e217a0653dfe8d6a78a18587b4b66');
assert.equal(evidence(SOURCE918).sha256, '2ab728663f4ce0096a94e49279a5feadda378f64629dd4ec6ccff785db60c68b');
assert.equal(evidence(RECONSTRUCTION).sha256, '398f3854fc323bc106f58b0133cf702cce1a9b234bca850ccc416a21570611c5');
const sealed = json(MANIFEST); assert.equal(sealed.length, 57);
assert.deepEqual(pathsWithin(BASE), sealed.map(entry => entry.path).sort(), 'Original archive file set must stay exactly sealed');
for (const entry of sealed) assertFile(join(BASE, entry.path), entry);
const oldFreeze = json(`${BASE}/freeze.json`);
assert.equal(oldFreeze.sha256, compactHash(oldFreeze.files));
assert.equal(oldFreeze.sha256, 'd6fffde98a45d09615a74b8daded5cb41071eee1f26a74789d54660ca8ba8993');
const oldPins = new Map(oldFreeze.files.map(entry => [entry.file, entry]));
assert.equal(oldPins.size, oldFreeze.files.length); assert.equal(oldPins.size, 4062);
assertFile(OLD_PRODUCER, oldPins.get('$natural-producer'));
const archive = json(`${BEFORE}/manifest.json`);
for (const pin of archive) assertFile(join(BEFORE, pin.path), pin);
const archivePins = new Map(archive.map(entry => [entry.path, entry]));
for (const path of ['scripts/play/red-priest-stage.mjs', 'scripts/verify/red-priest-save.mjs', 'scripts/verify/red-priest-save.test.mjs'])
  assertFile(path, archivePins.get(path));
for (const path of ALLOWED_CHANGES) {
  assert(archivePins.has(path), `Missing exact pre-planning archive: ${path}`);
  assert.deepEqual({ bytes: archivePins.get(path).bytes, sha256: archivePins.get(path).sha256 },
    { bytes: oldPins.get(path).bytes, sha256: oldPins.get(path).sha256 });
}
const wrapped = json(`${BASE}/checkpoint.json`), cp = wrapped.payload;
assert.equal(wrapped.sha256, hash(cp)); assert.equal(cp.commandCount, 983); assert.equal(cp.rows.length, 188);
assert.equal(cp.commands.length, 188); assert.equal(cp.freezeSha256, oldFreeze.sha256);
assert.equal(cp.terminal.stage, 'FINITE_CAMPAIGN_WITHDRAWN'); assert.equal(cp.policy.phase, 'WITHDRAWN_PERSONNEL'); assert.equal(cp.pending, null);
assert.equal(hash(cp.state), cp.finalStateSha256);
assert.equal(cp.finalStateSha256, 'c6f86247a2aef2057f1aa06f3810c80a2f765138991b5a94865fa719323eff3d');
assert.equal(cp.publicStateSha256, 'f2968347af0f0df6460250387cc1cfc7a4cc254e41d28071a71b8a538b6c310c');
assertFile(cp.source, { bytes: oldPins.get(cp.source).bytes, sha256: cp.sourceSha256 });
assert.deepEqual(read(`${BASE}/commands.ndjson`).toString().trim().split('\n').map(line => JSON.parse(line)), cp.rows);
const natural = json(`${BASE}/natural.json`);
assert.equal(natural.commands.length, 983); assert.equal(natural.prefixCount, 795);
assert.equal(compactHash(natural.commands.slice(0, 795)), cp.prefixSha256);
assert.deepEqual(natural.commands.slice(795), cp.commands); assert.deepEqual(natural.final, cp.state);
const root918 = json(SOURCE918); assert.equal(hash(root918.payload), root918.sha256);
assert.equal(hash(root918.payload.state), '779ef84dfc74b9abbfe1e97c9bff206c683a9b18d3957d6603661f9748b38acd');
const reconstruction = json(RECONSTRUCTION); assertFile(SOURCE918, reconstruction.checkpoint);
assert.equal(reconstruction.allPrivatePublicAndRngEqual, true); assert.equal(reconstruction.strictFinalValidation, true);
assert.equal(reconstruction.original983.manifestEvidence.sha256, evidence(MANIFEST).sha256);
const hq = json(HQ_PROOF), logistics = json(LOGISTICS_PROOF);
assert.equal(hq.replay.commands, 179); assert.equal(logistics.replay.commands, 146);
assert.equal(hq.replay.allPrivateAndRngEqual, true); assert.equal(logistics.replay.allPrivateAndRngEqual, true);
assert.equal(hq.replay.rows.length, 179); assert.equal(logistics.replay.rows.length, 146);
const hqRows = new Map(hq.replay.rows.map(row => [row.commandCount, row]));
const logisticsRows = new Map(logistics.replay.rows.map(row => [row.commandCount, row]));
const priorPublicAfter = new Map();
for (let index = 0; index < cp.rows.length; index++) {
  const row = cp.rows[index]; assert.equal(row.commandCount, index + 796); assert.deepEqual(row.intent, cp.commands[index]);
  assert.equal(row.commandSha256, compactHash(row.intent));
  if (index) {
    assert.equal(row.beforeStateSha256, cp.rows[index - 1].afterStateSha256);
    assert.deepEqual(row.randomBefore, cp.rows[index - 1].randomAfter);
    const expectedCapturedBefore = row.commandCount === 942 ? logistics.continuedPublicSha256
      : row.commandCount === 975 ? hq.continuedPublicSha256 : cp.rows[index - 1].publicAfterSha256;
    assert.equal(row.publicBeforeSha256, expectedCapturedBefore, `Unreviewed historical public seam before ${row.commandCount}`);
  }
  if (row.commandCount <= 974) {
    const approved = hqRows.get(row.commandCount); assert(approved);
    assert.equal(approved.stateSha256, row.afterStateSha256); assert.deepEqual(approved.random, row.randomAfter);
    assert.equal(approved.capturedPublicSha256, row.publicAfterSha256);
    if (row.commandCount <= 941) {
      const earlier = logisticsRows.get(row.commandCount); assert(earlier);
      assert.equal(earlier.stateSha256, row.afterStateSha256); assert.deepEqual(earlier.random, row.randomAfter);
      assert.equal(earlier.capturedPublicSha256, row.publicAfterSha256);
      assert.equal(approved.priorRuntimePublicSha256, earlier.publicSha256);
    } else assert.equal(approved.priorRuntimePublicSha256, row.publicAfterSha256);
    priorPublicAfter.set(row.commandCount, approved.publicSha256);
  } else priorPublicAfter.set(row.commandCount, row.publicAfterSha256);
}
assert.equal(priorPublicAfter.get(974), hq.continuedPublicSha256);
assert.equal(priorPublicAfter.get(918), root918.payload.publicStateSha256);
const currentRuntimeFreeze = currentFreeze(cp.source);
assert.deepEqual(currentRuntimeFreeze.files.map(entry => entry.file), oldFreeze.files.filter(entry => entry.file !== '$natural-producer').map(entry => entry.file),
  'No new, removed, or unbound production file may escape the frozen inventory');
const changedFiles = [];
for (const entry of currentRuntimeFreeze.files) {
  const old = oldPins.get(entry.file);
  if (entry.bytes === old.bytes && entry.sha256 === old.sha256) continue;
  assert(ALLOWED_CHANGES.includes(entry.file), `Unapproved changed production file: ${entry.file}`);
  changedFiles.push({ file: entry.file, before: { bytes: old.bytes, sha256: old.sha256 }, after: { bytes: entry.bytes, sha256: entry.sha256 } });
}
assert.deepEqual(changedFiles.map(entry => entry.file).sort(), [...ALLOWED_CHANGES].sort(), 'Build and integrate every reviewed planning candidate before this proof');
const additionalInputs = [MANIFEST, `${BEFORE}/manifest.json`, OLD_PRODUCER, SOURCE918, RECONSTRUCTION,
  fileURLToPath(import.meta.url), join(OUT, 'public-equivalence.mjs'), 'docs/RED_PRIEST_PLAYABLE_STAGE.md',
  'scripts/play/red-priest-stage.mjs', 'scripts/verify/red-priest-save.mjs', 'scripts/verify/red-priest-save.test.mjs'];
const inputFiles = [...sealed.map(entry => ({ path: join(BASE, entry.path), bytes: entry.bytes, sha256: entry.sha256 })),
  ...archive.map(entry => ({ path: join(BEFORE, entry.path), bytes: entry.bytes, sha256: entry.sha256 })),
  ...additionalInputs.map(path => ({ path, ...evidence(path) }))];
const inputStartSha256 = hash(inputFiles);
const original983Capture = { directory: BASE, manifest: MANIFEST, manifestEvidence: evidence(MANIFEST), files: sealed,
  producer: { path: OLD_PRODUCER, ...evidence(OLD_PRODUCER) }, freezeSha256: oldFreeze.sha256,
  checkpoint: evidence(`${BASE}/checkpoint.json`), payloadSha256: wrapped.sha256, stage: cp.terminal.stage };
const preflight = { format: 'RED_PRIEST983_PLANNING_TRANSITION_PREFLIGHT_V1', original983Capture,
  currentRuntimeFreeze, changedFiles, allowedChanges: ALLOWED_CHANGES, inputFiles, inputStartSha256,
  admittedHistoricalPublicSeams: [{ commandCount: 941, proofFile: LOGISTICS_PROOF, ...evidence(LOGISTICS_PROOF) },
    { commandCount: 974, proofFile: HQ_PROOF, ...evidence(HQ_PROOF) }],
  scriptSha256: evidence(fileURLToPath(import.meta.url)).sha256,
  normalizerSha256: evidence(join(OUT, 'public-equivalence.mjs')).sha256 };
if (!execute) {
  create(join(OUT, 'preflight.json'), preflight);
  console.log(JSON.stringify({ passed: true, runtimeLoaded: false, sealedOriginalFiles: 57, productionFiles: currentRuntimeFreeze.files.length,
    changedFiles: changedFiles.map(entry => entry.file), executeCommand: 'node --max-old-space-size=1024 output/qa-0209/planning-equivalence/verify.mjs --execute' }));
  process.exit(0);
}
if (existsSync(join(OUT, 'preflight.json'))) assert.deepEqual(json(join(OUT, 'preflight.json')), preflight, 'Inputs changed after preflight');
const [slice, migration] = await Promise.all(['dist/domain/slice/index.js', 'dist/domain/slice/migration.js']
  .map(path => import(pathToFileURL(resolve(ROOT, path)).href)));
let state = migration.migrateSliceState(json(cp.source).final), session = null;
assert.equal(hash(state), cp.initialStateSha256);
const rows = []; let removedCount = 0;
function checkPublic(view, snapshot, expected, count, boundary) {
  const { prior, removed } = stripPlanningActivation(view, snapshot); removedCount += removed;
  assert.equal(hash(prior), expected, `Complete pre-planning runtime public projection changed at ${count} ${boundary}`);
  return { full: hash(view), prior: hash(prior), removed };
}
for (const row of cp.rows) {
  assert.equal(hash(state), row.beforeStateSha256, `Private before ${row.commandCount}`);
  assert.deepEqual(state.random, row.randomBefore, `RNG before ${row.commandCount}`);
  const beforeView = session ? session.projectRedPriest() : slice.projectSliceState(state).redPriest;
  const beforeExpected = row.commandCount === 796 ? row.publicBeforeSha256 : priorPublicAfter.get(row.commandCount - 1);
  const before = checkPublic(beforeView, state, beforeExpected, row.commandCount, 'before');
  const offered = beforeView.actions.filter(action => stable(action.command) === stable(row.intent.command));
  assert.equal(offered.length, 1); assert.equal(offered[0].enabled, true); assert.equal(offered[0].label, row.publicLabel);
  let next, afterView;
  if (session) {
    const draft = session.prepare(row.intent, state.revision);
    next = session.snapshotDraft(draft); afterView = session.projectDraftRedPriest(draft); session.commit(draft);
  } else {
    next = slice.applySliceIntent(state, row.intent); session = slice.openRedPriestRuntimeSession(next); afterView = session.projectRedPriest();
  }
  assert.equal(hash(next), row.afterStateSha256, `Private after ${row.commandCount}`);
  assert.deepEqual(next.random, row.randomAfter, `RNG after ${row.commandCount}`); assert.equal(next.revision, row.revision);
  const after = checkPublic(afterView, next, priorPublicAfter.get(row.commandCount), row.commandCount, 'after');
  rows.push({ commandCount: row.commandCount, commandSha256: row.commandSha256, beforeStateSha256: row.beforeStateSha256,
    stateSha256: hash(next), randomBefore: row.randomBefore, random: next.random,
    capturedPublicBeforeSha256: row.publicBeforeSha256, capturedPublicSha256: row.publicAfterSha256,
    publicBeforeSha256: before.full, publicSha256: after.full,
    priorRuntimePublicBeforeSha256: before.prior, priorRuntimePublicSha256: after.prior,
    planningActionRemovedBefore: before.removed, planningActionRemovedAfter: after.removed,
    privateAndRngEqual: true, allExistingPublicFieldsEqual: true, enabledOriginalAction: true });
  if (row.commandCount === 918) assert.deepEqual(next, root918.payload.state, 'The independently reconstructed 918 branch root must be byte-value identical');
  state = next;
  if (rows.length % 20 === 0 || rows.length === 188) console.log(JSON.stringify({ verified: rows.length, commandCount: row.commandCount, privateAndRngEqual: true, completeLegacyPublicEqual: true }));
}
assert.equal(hash(state), cp.finalStateSha256); assert.deepEqual(state, cp.state);
slice.assertValidSliceState(state);
const finalView = session.projectRedPriest(); assert.equal(hash(finalView), cp.publicStateSha256, 'Original 983 terminal public projection must match without normalization');
assert.equal(state.redPriest.campaign.phase, 'WITHDRAWN'); assert.equal(state.progression.sequence, 1);
assert(!Object.hasOwn(state.redPriest.campaign, 'planning')); assert.deepEqual(state.random, { seed: 'hunter-rebuild-first', cursor: 427 });
const runtimeEnd = currentFreeze(cp.source); assert.deepEqual(runtimeEnd, currentRuntimeFreeze, 'Production changed during replay');
assert.deepEqual(pathsWithin(BASE), sealed.map(entry => entry.path).sort());
for (const entry of inputFiles) assertFile(entry.path, entry);
const inputEndSha256 = hash(inputFiles.map(entry => ({ path: entry.path, ...evidence(entry.path) })));
assert.equal(inputEndSha256, inputStartSha256);
const result = { format: 'RED_PRIEST983_PLANNING_TRANSITION_V1', commandCount: 983, originalFreezeSha256: oldFreeze.sha256,
  original983Capture, currentRuntimeFreeze, changedFiles, allowedChanges: ALLOWED_CHANGES,
  initialStateSha256: cp.initialStateSha256, stateSha256: hash(state), originalPublicSha256: cp.publicStateSha256,
  continuedPublicSha256: hash(finalView), random: state.random, strictFinalValidation: true,
  checkpointSha256: evidence(`${BASE}/checkpoint.json`).sha256,
  replay: { commands: 188, first: 796, last: 983, allPrivateAndRngEqual: true, allExistingPublicFieldsEqual: true,
    publicDifference: 'Only the exact trailing ENABLE_PLANNING action at the reviewed CRISIS availability predicate; prior 941/974 public seams matched against their unchanged full-projection proof hashes',
    allowedPublicChanges: ['APPENDED_ENABLE_PLANNING_CRISIS_ACTION'], addedProjectionChecks: removedCount, rows },
  source918: { checkpointFile: SOURCE918, checkpoint: evidence(SOURCE918), reconstructionProofFile: RECONSTRUCTION,
    reconstructionProof: evidence(RECONSTRUCTION), ...rows.find(row => row.commandCount === 918) },
  admittedHistoricalPublicSeams: preflight.admittedHistoricalPublicSeams,
  inputFiles, inputStartSha256, inputEndSha256, currentRuntimeEndSha256: runtimeEnd.sha256,
  originalInputsUnchanged: true, productionUnchangedDuringReplay: true,
  scriptSha256: preflight.scriptSha256, normalizerSha256: preflight.normalizerSha256 };
create(join(OUT, 'proof.json'), result);
console.log(JSON.stringify({ passed: 188, strictFinalValidation: true, original983Intact: true,
  finalStateSha256: result.stateSha256, finalPublicSha256: result.continuedPublicSha256,
  productionFreezeSha256: currentRuntimeFreeze.sha256, proof: join(OUT, 'proof.json'), proofSha256: evidence(join(OUT, 'proof.json')).sha256 }));
