import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve, relative, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { ALLOWED_PUBLIC_CHANGES, ORIGINAL_EPILOGUE_STORY, ORIGINAL_PRE_EPILOGUE_STORY, reconstructOriginalPublic } from './public-equivalence.mjs';

const ROOT = process.cwd(), OUT = dirname(fileURLToPath(import.meta.url));
const FIXTURE = 'tests/fixtures/red-priest-v02090', BASE = `${FIXTURE}/planned`;
const BEFORE = 'output/qa-0209/pre-final-story';
const RETURN_BEFORE = 'output/qa-0209/pre-final-return-action';
const MANIFEST = 'output/qa-0209/final-ui-equivalence/original-capture-manifest.json';
const SELF = relative(ROOT, fileURLToPath(import.meta.url)).split(sep).join('/');
const NORMALIZER = relative(ROOT, join(OUT, 'public-equivalence.mjs')).split(sep).join('/');
const ALLOWED_CHANGES = ['src/domain/red-priest/index.ts', 'dist/domain/red-priest/index.js', 'dist/domain/red-priest/index.js.map'];
const PRODUCTION_ROOTS = ['package.json', 'package-lock.json', 'src', 'dist/domain', 'dist/content',
  'dist/resolution', 'dist/persistence', 'dist/shared', 'dist/application', 'dist/simulation'];
const sha = value => createHash('sha256').update(value).digest('hex');
const stable = value => Array.isArray(value) ? `[${value.map(stable).join(',')}]` : value && typeof value === 'object'
  ? `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stable(value[key])}`).join(',')}}` : JSON.stringify(value);
const hash = value => sha(stable(value)), compactHash = value => sha(JSON.stringify(value));
const read = path => readFileSync(resolve(ROOT, path));
const json = path => JSON.parse(read(path));
function evidence(path) {
  const absolute = resolve(ROOT, path), before = lstatSync(absolute, { bigint: true });
  assert(before.isFile() && !before.isSymbolicLink(), `Not a regular frozen file: ${path}`);
  const bytes = readFileSync(absolute), after = lstatSync(absolute, { bigint: true });
  for (const key of ['size', 'mtimeNs', 'ctimeNs', 'ino']) assert.equal(after[key], before[key], `File changed during hashing: ${path}`);
  assert.equal(BigInt(bytes.length), after.size);
  return { bytes: bytes.length, sha256: sha(bytes) };
}
function assertFile(path, pin) {
  assert.deepEqual(evidence(path), { bytes: pin.bytes, sha256: pin.sha256 }, `Frozen input changed: ${path}`);
}
function create(path, value) {
  const bytes = Buffer.from(JSON.stringify(value, null, 2) + '\n');
  if (existsSync(path)) { assert.deepEqual(readFileSync(path), bytes, `Refusing to overwrite different proof: ${path}`); return; }
  mkdirSync(dirname(path), { recursive: true }); writeFileSync(path, bytes, { flag: 'wx' });
}
function pathsWithin(directory) {
  const result = [];
  function walk(path, relative = '') {
    const stat = lstatSync(path); assert(!stat.isSymbolicLink(), `No symbolic links in sealed inputs: ${path}`);
    if (stat.isDirectory()) for (const name of readdirSync(path).sort()) walk(join(path, name), join(relative, name));
    else { assert(stat.isFile(), `Unexpected non-file: ${path}`); result.push(relative.split(sep).join('/')); }
  }
  walk(resolve(ROOT, directory)); return result.sort();
}
function currentFreeze(source) {
  const files = [];
  function walk(name) {
    const stat = lstatSync(resolve(ROOT, name)); assert(!stat.isSymbolicLink(), `No symbolic links in production: ${name}`);
    if (stat.isDirectory()) for (const child of readdirSync(resolve(ROOT, name)).sort()) walk(join(name, child));
    else { assert(stat.isFile()); files.push({ file: name.split(sep).join('/'), ...evidence(name) }); }
  }
  for (const root of PRODUCTION_ROOTS) walk(root);
  files.push({ file: source, ...evidence(source) });
  return { sha256: compactHash(files), files };
}

assert.deepEqual(process.argv.slice(2).filter(arg => !['--preflight', '--execute'].includes(arg)), []);
assert.equal(process.argv.length, 3, 'Choose --preflight (no runtime import) or explicitly authorized --execute');
const execute = process.argv[2] === '--execute';
assert.equal(evidence(MANIFEST).sha256, 'eebd0006d9f0965953b4fe683e20bcde201e83ae366d53a99dedef567a13aff1');
assert.equal(evidence(`${BEFORE}/manifest.json`).sha256, 'e11be44602365353a5a074151251220763c955b4de1950461f100fe039ab1ec2');
const files7 = json(MANIFEST); assert.equal(files7.length, 7);
assert.deepEqual(pathsWithin(BASE), files7.map(entry => entry.path).sort());
for (const entry of files7) assertFile(join(BASE, entry.path), entry);
const wrapped = json(`${BASE}/checkpoint.json`), cp = wrapped.payload;
assert.equal(hash(cp), wrapped.sha256); assert.equal(wrapped.sha256, '2a20318082e960898828e4dee8546d64f564148ead8699d9fec08b60fcbe2dcc');
assert.equal(cp.commandCount, 1051); assert.equal(cp.prefixCount, 918); assert.equal(cp.commands.length, 133); assert.equal(cp.rows.length, 133);
assert.equal(cp.initialStateSha256, '779ef84dfc74b9abbfe1e97c9bff206c683a9b18d3957d6603661f9748b38acd');
assert.equal(cp.finalStateSha256, '6a308acd1cee397f8666ae2a2715723f075d7b86c0c700b56ee7b7a569b3970c');
assert.equal(cp.publicStateSha256, '1b69a9b6b90a0cd6e56dadc5e6a7ab42e66a1f766dc78fd6e0b58f06b301ff46');
assert.equal(hash(cp.state), cp.finalStateSha256); assert.equal(cp.pending, null); assert.equal(cp.terminal.stage, 'NATURAL_RESCUE_REPORTED');
assert.deepEqual(cp.state.random, { seed: 'hunter-rebuild-first', cursor: 441 });
assert.deepEqual(read(`${BASE}/commands.ndjson`).toString().trim().split('\n').map(line => JSON.parse(line)), cp.rows);
const natural = json(`${BASE}/natural.json`);
assert.equal(natural.commands.length, 1051); assert.equal(natural.prefixCount, 918); assert.deepEqual(natural.final, cp.state);
assert.deepEqual(natural.commands.slice(918), cp.commands); assert.equal(compactHash(natural.commands.slice(0, 918)), cp.prefixSha256);
for (let index = 0; index < cp.rows.length; index++) {
  const row = cp.rows[index], before = cp.rows[index - 1];
  assert.equal(row.commandCount, index + 919); assert.deepEqual(row.intent, cp.commands[index]); assert.equal(row.commandSha256, compactHash(row.intent));
  assert.equal(row.beforeStateSha256, before?.afterStateSha256 ?? cp.initialStateSha256);
  assert.equal(row.publicBeforeSha256, before?.publicAfterSha256 ?? cp.initialPublicStateSha256);
  assert.deepEqual(row.randomBefore, before?.randomAfter ?? { seed: 'hunter-rebuild-first', cursor: 423 });
}
assert.equal(cp.rows.at(-1).afterStateSha256, cp.finalStateSha256); assert.equal(cp.rows.at(-1).publicAfterSha256, cp.publicStateSha256);
const oldFreeze = json(`${BASE}/freeze.json`); assert.equal(oldFreeze.sha256, compactHash(oldFreeze.files));
assert.equal(oldFreeze.sha256, '569f2da5b397e8a7520240c7ac32a550afb3a715982fe0df13fd7d8bb21d76ef');
assert.equal(oldFreeze.sha256, cp.freezeSha256); const oldPins = new Map(oldFreeze.files.map(entry => [entry.file, entry]));
assert.equal(oldPins.size, 4062); assert.equal(oldPins.size, oldFreeze.files.length);
const originalRuntimeFreeze = { files: oldFreeze.files.filter(entry => entry.file !== '$natural-producer') };
originalRuntimeFreeze.sha256 = compactHash(originalRuntimeFreeze.files);
const archive = json(`${BEFORE}/manifest.json`); assert.deepEqual(archive.files.map(entry => entry.file), ALLOWED_CHANGES);
for (const entry of archive.files) { assertFile(entry.archived, entry); assert.deepEqual({ bytes: entry.bytes, sha256: entry.sha256 }, { bytes: oldPins.get(entry.file).bytes, sha256: oldPins.get(entry.file).sha256 }); }
const beforeSource = read(archive.files[0].archived).toString(), currentSource = read(ALLOWED_CHANGES[0]).toString();
const newHelper = [
  "export function redPriestEpilogueStory(ep: Pick<NonNullable<RedPriestState['epilogue']>, 'patients' | 'status' | 'reported'>): string {",
  "  const evacuated = ep.patients.filter(p => p.status === 'EVACUATED').length;",
  "  const sheltered = ep.patients.filter(p => p.status === 'SHELTERED').length;",
  "  const account = ep.reported ? '救援人数和原分队损失已经交接。'",
  "    : ep.status === 'ACTIVE' ? '原分队仍受疲劳、伤势和现场抵抗限制。'",
  "      : '救援已经收束，实际人数和原分队损失尚待交接。';",
  '  return `停战后的原运输侧线起火；已转运原伤员${evacuated}名，${sheltered}名仍留在有遮蔽的原救护站。${account}`;',
  '}', '',
].join('\n');
const newAssignment = 'const ep = root.epilogue; result.story = redPriestEpilogueStory(ep);';
const oldAssignment = `const ep = root.epilogue; result.story = '${ORIGINAL_EPILOGUE_STORY}';`;
assert.equal(currentSource.split(newHelper).length, 2); assert.equal(currentSource.split(newAssignment).length, 2);
assert.equal(evidence(`${RETURN_BEFORE}/inserted-block.txt`).sha256, 'ea6400a5b7aa169e9f1ff5a32a5f5f27ca72551eed9b9abcf924227712e94e09');
const appendTravelBlock = read(`${RETURN_BEFORE}/inserted-block.txt`).toString();
assert.equal(currentSource.split(appendTravelBlock).length, 2);
assert.equal(currentSource.replace(appendTravelBlock, '').replace(newHelper, '').replace(newAssignment, oldAssignment), beforeSource,
  'Only the exact pure story helper/assignment and the approved trailing travel block may change source');
assert.equal(read('src/domain/red-priest/content.ts').toString().match(/export const RED_PRIEST_STORY = '([^']+)';/)[1], ORIGINAL_PRE_EPILOGUE_STORY);
const currentRuntimeFreeze = currentFreeze(cp.source);
assert.deepEqual(currentRuntimeFreeze.files.map(entry => entry.file), originalRuntimeFreeze.files.map(entry => entry.file));
const currentPins = new Map(currentRuntimeFreeze.files.map(entry => [entry.file, entry]));
const actualChanged = currentRuntimeFreeze.files.filter(entry => entry.sha256 !== oldPins.get(entry.file).sha256 || entry.bytes !== oldPins.get(entry.file).bytes);
assert.deepEqual(actualChanged.map(entry => entry.file).sort(), [...ALLOWED_CHANGES].sort());
const changedFiles = ALLOWED_CHANGES.map(file => ({ file, before: { bytes: oldPins.get(file).bytes, sha256: oldPins.get(file).sha256 },
  after: { bytes: currentPins.get(file).bytes, sha256: currentPins.get(file).sha256 } }));

// The portable map only locates bytes. Every used artifact is authenticated by
// its independently pinned digest below; the mutable locator is not an input
// trust anchor and may later gain aliases for this new proof.
const locator = json(`${FIXTURE}/proofs/story-input-locations.json`);
assert.equal(locator.format, 'RED_PRIEST_PLANNED_VERIFIER_ARTIFACT_MAP_V1');
const inputMap = new Map();
function bind(path, pin = evidence(path)) {
  assertFile(path, pin); const existing = inputMap.get(path);
  if (existing) assert.deepEqual(existing, { path, bytes: pin.bytes, sha256: pin.sha256 });
  inputMap.set(path, { path, bytes: pin.bytes, sha256: pin.sha256 }); return path;
}
function located(name, pin, kind = 'ARTIFACT') {
  const aliases = locator.entries.filter(entry => entry.kind === kind && entry.name === name && entry.sha256 === pin.sha256 && entry.bytes === pin.bytes);
  const selected = aliases[0];
  if (selected) {
    const path = join(FIXTURE, selected.path), absolute = resolve(ROOT, path);
    assert(absolute.startsWith(resolve(ROOT, FIXTURE) + sep), 'Portable alias escapes fixture');
    return bind(path, pin);
  }
  assert(existsSync(resolve(ROOT, name)), `Missing exact artifact ${name}`); return bind(name, pin);
}
for (const entry of files7) bind(join(BASE, entry.path), entry);
for (const entry of archive.files) bind(entry.archived, entry);
for (const path of [MANIFEST, `${BEFORE}/manifest.json`, SELF, NORMALIZER, `${RETURN_BEFORE}/inserted-block.txt`, `${RETURN_BEFORE}/manifest.json`]) bind(path);
const producerPath = located('$natural-producer', oldPins.get('$natural-producer'), 'FROZEN_RUNTIME');
const history = json(`${BASE}/history-manifest.json`);
assert.equal(evidence(`${BASE}/history-manifest.json`).sha256, '4def938bbd0fc45ce23ac84c5468654796fb9feae3f37f96f2a5b67281fabe65');
assert.equal(history.format, 'RED_PRIEST918_STABILITY_FIRST_HISTORY_V1'); assert.equal(history.newFreezeSha256, oldFreeze.sha256);
assert.equal(history.selectedPromotionCheckpoint, false); assert.equal(history.original1222BranchPreserved, true);
assert.deepEqual(history.policyDefinition, cp.policyDefinition); assert.equal(history.original918PrefixSha256, cp.prefixSha256);
for (const source of history.sources) {
  for (const entry of source.files) located(join(source.directory, entry.path), entry);
  if (source.producer) located(source.producer.path, source.producer);
  if (source.manifest) located(source.manifest.path, source.manifest);
}
for (const entry of [...history.proofs, ...history.additionalProofInputs]) located(entry.path, entry);
const source918 = history.sources.find(source => source.id === 'source918'); assert(source918);
const rootPin = source918.files.find(entry => entry.path === 'original-918-checkpoint.json'); assert(rootPin);
assert.equal(rootPin.sha256, '2ab728663f4ce0096a94e49279a5feadda378f64629dd4ec6ccff785db60c68b');
const rootFile = located(join(source918.directory, rootPin.path), rootPin), root918 = json(rootFile);
assert.equal(hash(root918.payload), root918.sha256); assert.equal(hash(root918.payload.state), cp.initialStateSha256);
assert.deepEqual(natural.commands.slice(795, 918), root918.payload.commands);
const historicalProofs = [];
for (const entry of history.proofs) {
  const proofFile = located(entry.path, entry), proof = json(proofFile);
  if (entry.id === 'historicalPlanning983') assert.equal(entry.sha256, '9f64e510ace5f5f484ad2869a8bc616c668231ac345383695740a4edd065a3c3');
  else { assert.equal(entry.id, 'currentStability219'); assert.equal(entry.sha256, 'f7ae783e6592d8fe1d4c5fc41c2555b271c4ed2a3860140bee88b77073328dff');
    assert.deepEqual(proof.currentRuntimeFreeze.files, originalRuntimeFreeze.files); }
  assert.equal(proof.strictFinalValidation, true); assert.equal(proof.inputStartSha256, proof.inputEndSha256);
  for (const input of proof.inputFiles) located(input.path, input);
  historicalProofs.push({ id: entry.id, proofFile, proofSha256: entry.sha256 });
}
const transition918 = json(`${BASE}/runtime-transition.json`);
assert.equal(transition918.newRuntimeFreezeSha256, oldFreeze.sha256); assert.equal(transition918.stateSha256, cp.initialStateSha256);
assert.equal(transition918.continuedPublicSha256, cp.initialPublicStateSha256); assert.equal(transition918.unchangedPrivateAndRng, true);
assert.equal(evidence(`${BASE}/runtime-transition.json`).sha256, cp.fork.runtimeProofSha256);
const priorStoryProofFile = 'output/qa-0209/final-story-equivalence/proof.json';
assert.equal(evidence(priorStoryProofFile).sha256, '81ff3aca0bbbfe1850ed7f79fd852c3f68bc9bf8cc062af64abf7363885c93c9');
bind(priorStoryProofFile); const priorStory = json(priorStoryProofFile);
assert.equal(priorStory.format, 'RED_PRIEST1051_STORY_TRANSITION_V1');
assert.deepEqual(priorStory.originalRuntimeFreeze, originalRuntimeFreeze);
assert.equal(priorStory.replay.rows.length, 133); assert.equal(priorStory.strictFinalValidation, true);
for (const input of priorStory.inputFiles) located(input.path, input);
const priorStoryProof = { proofFile: priorStoryProofFile, proofSha256: evidence(priorStoryProofFile).sha256 };
assert.equal(evidence(`${RETURN_BEFORE}/manifest.json`).sha256, '797182bf9b46957d516422f4e30bb14e4d897f95107a710893738e7ec1e5d0b6');
const returnArchive = json(`${RETURN_BEFORE}/manifest.json`);
assert.deepEqual(returnArchive.map(entry => entry.path), ALLOWED_CHANGES);
for (const entry of returnArchive) {
  const pin = { bytes: entry.size, sha256: entry.sha256 };
  bind(join(RETURN_BEFORE, entry.path), pin);
  const previous = priorStory.currentRuntimeFreeze.files.find(row => row.file === entry.path);
  assert.deepEqual(pin, { bytes: previous.bytes, sha256: previous.sha256 });
}
assert.equal(currentSource.replace(appendTravelBlock, ''), read(join(RETURN_BEFORE, ALLOWED_CHANGES[0])).toString());

const projectionFiles = ['src/shared/player-text.ts', 'src/shared/player-text-copy.ts', 'dist/shared/player-text.js',
  'dist/shared/player-text.js.map', 'dist/shared/player-text-copy.js', 'dist/shared/player-text-copy.js.map'].map(file => {
    assert.deepEqual(currentPins.get(file), oldPins.get(file)); return currentPins.get(file);
  });
const projectionContracts = { capture: 'OWNED_AUTHORED_RED_PRIEST_PROJECTION', persistence: 'COMPLETE_PLAYER_FACING_SLICE_PROJECTION',
  relation: 'EXACT_FROZEN_PROJECT_PLAYER_TEXT_WITH_ORIGINAL_PLAYER_NAME', files: projectionFiles };
const inputFiles = [...inputMap.values()], inputStartSha256 = hash(inputFiles);
const originalCapture = { directory: BASE, files7, manifest: MANIFEST, manifestEvidence: evidence(MANIFEST),
  freezeSha256: oldFreeze.sha256, producer: { path: producerPath, ...evidence(producerPath) } };
const source1051 = { checkpointFile: `${BASE}/checkpoint.json`, checkpoint: evidence(`${BASE}/checkpoint.json`),
  checkpointPayloadSha256: wrapped.sha256, commandCount: 1051, stateSha256: cp.finalStateSha256,
  publicSha256: cp.publicStateSha256, random: cp.state.random };
const preflight = { format: 'RED_PRIEST1051_FINAL_UI_TRANSITION_PREFLIGHT_V1', source1051, originalCapture,
  originalRuntimeFreeze, currentRuntimeFreeze, changedFiles, allowedChanges: ALLOWED_CHANGES,
  allowedPublicChanges: ALLOWED_PUBLIC_CHANGES, publicProjectionPath: 'redPriest', publicFieldPaths: ['story', 'actions[last]'],
  exactSourceEditVerified: true, historicalProofs, priorStoryProof, projectionContracts, inputFiles, inputStartSha256,
  scriptSha256: evidence(SELF).sha256, normalizerSha256: evidence(NORMALIZER).sha256 };
if (!execute) {
  create(join(OUT, 'preflight.json'), preflight);
  console.log(JSON.stringify({ passed: true, runtimeLoaded: false, commands: 133, originalFiles: 7,
    boundHistoricalInputs: inputFiles.length, productionFiles: currentRuntimeFreeze.files.length,
    executeCommand: 'node --max-old-space-size=1024 output/qa-0209/final-ui-equivalence/verify.mjs --execute' })); process.exit(0);
}
if (existsSync(join(OUT, 'preflight.json'))) assert.deepEqual(json(join(OUT, 'preflight.json')), preflight, 'Inputs changed after preflight');
const slice = await import(pathToFileURL(resolve(ROOT, 'dist/domain/slice/index.js')).href);
const { projectPlayerText } = await import(pathToFileURL(resolve(ROOT, 'dist/shared/player-text.js')).href);
let state = root918.payload.state, stateSha256 = hash(state);
const session = slice.openRedPriestRuntimeSession(state); assert.equal(hash(session.snapshot()), cp.initialStateSha256);
let view = session.projectRedPriest(); const rows = []; let storyChanges = 0, normalizerNegativeTests = null, travelNegativeTests = null;
function checkProjectionPair(authored, global, snapshot) {
  const before = hash(authored);
  assert.deepEqual(global.redPriest, projectPlayerText({ redPriest: authored }, snapshot.character.name).redPriest);
  assert.equal(hash(authored), before);
  return { global: hash(global), playerChapter: hash(global.redPriest) };
}
let projectionCheck = checkProjectionPair(view, session.project(), state);
function checkPublic(publicView, snapshot, expected, commandCount) {
  const normalized = reconstructOriginalPublic(publicView, snapshot);
  assert.equal(hash(normalized.prior), expected, `Only the exact approved story and trailing travel action may differ at ${commandCount}`);
  if (normalized.changed) storyChanges++;
  return { ...normalized, full: hash(publicView), prior: hash(normalized.prior), priorRuntime: hash(normalized.storyOnly) };
}
function runNegativeTests(publicView, snapshot, expectedStateSha256, expectedPublicSha256, expectedRandom, commandCount) {
  const gate = (candidateView, candidateState = snapshot) => {
    assert.equal(hash(candidateState), expectedStateSha256); assert.deepEqual(candidateState.random, expectedRandom);
    assert.equal(hash(reconstructOriginalPublic(candidateView, candidateState).prior), expectedPublicSha256);
  };
  gate(publicView); const checks = [];
  const mutations = [
    ['missing-story', value => { delete value.story; }],
    ['wrong-story-text', value => { value.story += ' altered'; }],
    ['stale-original-story', value => { value.story = ORIGINAL_EPILOGUE_STORY; }],
    ['extra-story-copy', value => { value.extraStory = value.story; }],
    ['changed-original-resource', value => { value.resources.health += 1; }],
    ['changed-original-action-cost', value => { value.actions[0].cost += ' altered'; }],
    ['missing-original-section', value => { value.sections.pop(); }],
  ];
  for (const [name, mutate] of mutations) {
    const candidate = structuredClone(publicView); mutate(candidate);
    assert.throws(() => gate(candidate), { name: 'AssertionError' }, `Incorrectly accepted ${name}`); checks.push({ name, rejected: true });
  }
  for (const [name, random] of [['changed-seed', { ...snapshot.random, seed: `${snapshot.random.seed}:altered` }],
    ['changed-rng-cursor', { ...snapshot.random, cursor: snapshot.random.cursor + 1 }]]) {
    assert.throws(() => gate(publicView, { ...snapshot, random }), { name: 'AssertionError' }); checks.push({ name, rejected: true });
  }
  assert.throws(() => assert.equal(hash(publicView), expectedPublicSha256), { name: 'AssertionError' });
  checks.push({ name: 'under-normalization-full-public-hash-rejection', rejected: true });
  const overNormalized = reconstructOriginalPublic(publicView, snapshot).prior; delete overNormalized.resources;
  assert.throws(() => assert.equal(hash(overNormalized), expectedPublicSha256), { name: 'AssertionError' });
  checks.push({ name: 'over-normalization-full-public-hash-rejection', rejected: true });
  return { commandCount, observedStateSha256: expectedStateSha256, observedPublicSha256: hash(publicView),
    capturedPublicSha256: expectedPublicSha256, positiveControlPassed: true, noAdditionalReplay: true,
    rejectedMutations: checks.length, checks };
}
function runTravelNegativeTests(publicView, snapshot, expectedStateSha256, expectedPublicSha256, expectedRandom, commandCount) {
  const gate = (candidateView, candidateState = snapshot) => {
    assert.equal(hash(candidateState), expectedStateSha256); assert.deepEqual(candidateState.random, expectedRandom);
    assert.equal(hash(reconstructOriginalPublic(candidateView, candidateState).prior), expectedPublicSha256);
  };
  gate(publicView); const checks = [];
  const mutations = [
    ['missing-travel', value => { value.actions.pop(); }],
    ['duplicate-travel', value => { value.actions.push(structuredClone(value.actions.at(-1))); }],
    ['wrong-travel-target', value => { value.actions.at(-1).command.to = 'southern-harbor'; }],
    ['wrong-travel-label', value => { value.actions.at(-1).label += ' altered'; }],
    ['wrong-travel-cost', value => { value.actions.at(-1).cost += ' altered'; }],
    ['renumbered-travel', value => { value.actions.at(-1).id += ' altered'; }],
    ['wrong-travel-enabled', value => { value.actions.at(-1).enabled = !value.actions.at(-1).enabled; }],
    ['wrong-travel-reason', value => { value.actions.at(-1).reason = null; }],
    ['extra-preferred-action', value => { value.actions.at(-1).preferredAction = true; }],
    ['reordered-original-actions', value => { [value.actions[0], value.actions[1]] = [value.actions[1], value.actions[0]]; }],
    ['changed-original-resource', value => { value.resources.health += 1; }],
    ['renumbered-original-action', value => { value.actions[0].id += ' altered'; }],
  ];
  for (const [name, mutate] of mutations) { const candidate = structuredClone(publicView); mutate(candidate);
    assert.throws(() => gate(candidate), { name: 'AssertionError' }); checks.push({ name, rejected: true }); }
  assert.throws(() => gate(publicView, { ...snapshot, random: { ...snapshot.random, seed: 'altered' } }), { name: 'AssertionError' });
  checks.push({ name: 'changed-seed', rejected: true });
  assert.throws(() => assert.equal(hash(publicView), expectedPublicSha256), { name: 'AssertionError' });
  checks.push({ name: 'under-normalization-full-public-hash-rejection', rejected: true });
  const over = reconstructOriginalPublic(publicView, snapshot).prior; over.actions.pop();
  assert.throws(() => assert.equal(hash(over), expectedPublicSha256), { name: 'AssertionError' });
  checks.push({ name: 'over-normalization-full-public-hash-rejection', rejected: true });
  return { commandCount, observedStateSha256: expectedStateSha256, observedPublicSha256: hash(publicView),
    capturedPublicSha256: expectedPublicSha256, positiveControlPassed: true, noAdditionalReplay: true,
    rejectedMutations: checks.length, checks };
}
let publicCheck = checkPublic(view, state, cp.initialPublicStateSha256, 918);
const injected = structuredClone(view); injected.actions.push({ id: `red-priest-action-${view.actions.length + 1}`,
  command: { type: 'TRAVEL', to: 'eastern-stores' }, label: '前往东南粮仓地',
  cost: '1行动；沿已行经大陆路线逐周结算旅费、生活费与旧还款', enabled: true, reason: null });
assert.throws(() => assert.equal(hash(reconstructOriginalPublic(injected, state).prior), cp.initialPublicStateSha256), { name: 'AssertionError' });
const ineligibleTravelNegativeTests = { commandCount: 918, observedStateSha256: stateSha256,
  observedPublicSha256: publicCheck.full, capturedPublicSha256: cp.initialPublicStateSha256,
  positiveControlPassed: true, noAdditionalReplay: true, rejectedMutations: 1,
  checks: [{ name: 'injected-travel-outside-exact-availability', rejected: true }] };
for (const row of cp.rows) {
  assert.equal(stateSha256, row.beforeStateSha256); assert.deepEqual(state.random, row.randomBefore);
  assert.equal(publicCheck.prior, row.publicBeforeSha256); const before = publicCheck;
  const priorStoryRow = priorStory.replay.rows[row.commandCount - 919];
  assert.equal(before.priorRuntime, priorStoryRow.publicBeforeSha256);
  const projectionBefore = projectionCheck;
  const offered = view.actions.filter(action => stable(action.command) === stable(row.intent.command));
  assert.equal(offered.length, 1); assert.equal(offered[0].enabled, true); assert.equal(offered[0].label, row.publicLabel);
  const draft = session.prepare(row.intent, state.revision), next = session.snapshotDraft(draft), afterView = session.projectDraftRedPriest(draft);
  const nextSha256 = hash(next); assert.equal(nextSha256, row.afterStateSha256); assert.deepEqual(next.random, row.randomAfter); assert.equal(next.revision, row.revision);
  const after = checkPublic(afterView, next, row.publicAfterSha256, row.commandCount);
  assert.equal(after.priorRuntime, priorStoryRow.publicSha256);
  projectionCheck = checkProjectionPair(afterView, session.projectDraft(draft), next);
  if (after.appendedTravel && travelNegativeTests === null) travelNegativeTests = runTravelNegativeTests(afterView, next, nextSha256, row.publicAfterSha256, row.randomAfter, row.commandCount);
  if (after.changed && normalizerNegativeTests === null)
    normalizerNegativeTests = runNegativeTests(afterView, next, nextSha256, row.publicAfterSha256, row.randomAfter, row.commandCount);
  rows.push({ commandCount: row.commandCount, commandSha256: row.commandSha256,
    beforeStateSha256: row.beforeStateSha256, stateSha256: nextSha256, randomBefore: row.randomBefore, random: next.random,
    capturedPublicBeforeSha256: row.publicBeforeSha256, capturedPublicSha256: row.publicAfterSha256,
    publicBeforeSha256: before.full, publicSha256: after.full,
    priorRuntimePublicBeforeSha256: before.priorRuntime, priorRuntimePublicSha256: after.priorRuntime,
    appendedTravelBefore: before.appendedTravel, appendedTravelAfter: after.appendedTravel,
    publicSliceBeforeSha256: projectionBefore.global, publicSliceSha256: projectionCheck.global,
    playerChapterBeforeSha256: projectionBefore.playerChapter, playerChapterSha256: projectionCheck.playerChapter,
    exactPlayerTextRelation: true,
    originalStoryBefore: before.originalStory, originalStoryAfter: after.originalStory,
    currentStoryBefore: before.currentStory, currentStoryAfter: after.currentStory,
    storyChangedBefore: before.changed, storyChangedAfter: after.changed,
    actualPatientsBefore: before.actualPatients, actualPatientsAfter: after.actualPatients,
    privateAndRngEqual: true, allOtherPublicFieldsEqual: true, enabledOriginalAction: true });
  session.commit(draft); state = next; stateSha256 = nextSha256; view = afterView; publicCheck = after;
  if (rows.length % 20 === 0 || rows.length === 133) console.log(JSON.stringify({ verified: rows.length, commandCount: row.commandCount,
    privateAndRngEqual: true, exactStoryAndTravelDifferencesOnly: true }));
}
assert.deepEqual(state, cp.state); assert.equal(stateSha256, cp.finalStateSha256); assert.equal(storyChanges, 5);
assert.deepEqual(rows.filter(row => row.storyChangedAfter).map(row => row.commandCount), [1047, 1048, 1049, 1050, 1051]);
assert.deepEqual(rows.filter(row => row.storyChangedBefore).map(row => row.commandCount), [1048, 1049, 1050, 1051]);
assert.deepEqual(rows.filter(row => row.appendedTravelAfter).map(row => row.commandCount), [1022, 1023, 1024]);
assert.deepEqual(rows.filter(row => row.appendedTravelBefore).map(row => row.commandCount), [1023, 1024, 1025]);
assert.deepEqual(rows.filter(row => row.appendedTravelAfter).map(row => row.appendedTravelAfter.enabled), [false, false, true]);
assert.equal(travelNegativeTests.commandCount, 1022); assert.equal(travelNegativeTests.rejectedMutations, 15);
assert.equal(normalizerNegativeTests.commandCount, 1047); assert.equal(normalizerNegativeTests.rejectedMutations, 11);
assert.equal(publicCheck.prior, cp.publicStateSha256); assert.notEqual(publicCheck.full, cp.publicStateSha256);
assert.deepEqual(publicCheck.actualPatients, { evacuated: 1, sheltered: 2, status: 'WITHDRAWN', reported: true });
slice.assertValidSliceState(state); assert.equal(hash(session.snapshot()), cp.finalStateSha256);
assert.equal(hash(session.projectRedPriest()), publicCheck.full); assert.deepEqual(state.random, { seed: 'hunter-rebuild-first', cursor: 441 });
const runtimeEnd = currentFreeze(cp.source); assert.deepEqual(runtimeEnd, currentRuntimeFreeze);
assert.deepEqual(pathsWithin(BASE), files7.map(entry => entry.path).sort());
for (const entry of inputFiles) assertFile(entry.path, entry);
const inputEndSha256 = hash(inputFiles.map(entry => ({ path: entry.path, ...evidence(entry.path) }))); assert.equal(inputEndSha256, inputStartSha256);
const result = { format: 'RED_PRIEST1051_FINAL_UI_TRANSITION_V1', commandCount: 1051, source1051, originalCapture,
  originalRuntimeFreeze, currentRuntimeFreeze, changedFiles, allowedChanges: ALLOWED_CHANGES,
  allowedPublicChanges: ALLOWED_PUBLIC_CHANGES, publicProjectionPath: 'redPriest', publicFieldPaths: ['story', 'actions[last]'], exactSourceEditVerified: true,
  stateSha256, originalPublicSha256: cp.publicStateSha256, continuedPublicSha256: publicCheck.full, random: state.random,
  originalStory: publicCheck.originalStory, currentStory: publicCheck.currentStory, strictFinalValidation: true,
  publicSliceSha256: projectionCheck.global, playerChapterSha256: projectionCheck.playerChapter,
  historicalProofs, priorStoryProof, projectionContracts, normalizerNegativeTests, travelNegativeTests, ineligibleTravelNegativeTests,
  replay: { commands: 133, first: 919, last: 1051, allPrivateAndRngEqual: true, allOtherPublicFieldsEqual: true,
    allowedPublicChanges: ALLOWED_PUBLIC_CHANGES, storyChangedChecks: storyChanges, appendedTravelChecks: 3, exactPlayerTextRelation: true, rows },
  inputFiles, inputStartSha256, inputEndSha256, currentRuntimeEndSha256: runtimeEnd.sha256,
  originalInputsUnchanged: true, productionUnchangedDuringReplay: true,
  scriptSha256: preflight.scriptSha256, normalizerSha256: preflight.normalizerSha256 };
create(join(OUT, 'proof.json'), result);
console.log(JSON.stringify({ passed: 133, strictFinalValidation: true, originalCaptureIntact: true, stateSha256,
  originalPublicSha256: cp.publicStateSha256, continuedPublicSha256: publicCheck.full,
  finalStory: publicCheck.currentStory, runtimeFreezeSha256: currentRuntimeFreeze.sha256,
  proofSha256: evidence(join(OUT, 'proof.json')).sha256 }));
