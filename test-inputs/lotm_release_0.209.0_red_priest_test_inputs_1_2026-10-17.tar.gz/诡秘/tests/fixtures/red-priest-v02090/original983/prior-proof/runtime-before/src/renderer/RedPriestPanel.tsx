import { useEffect, useId, useRef, useState } from 'react';
import type { RedPriestAction, RedPriestCommand, RedPriestProjection } from '../domain/red-priest/types';
import './seer-styles.css';

export interface RedPriestPanelProps {
  value: RedPriestProjection;
  busy: boolean;
  blocked?: boolean;
  error?: string | null;
  onCommand: (command: RedPriestCommand) => void;
  onClose?: () => void;
}

function isWithdrawal(action: RedPriestAction): boolean {
  return action.command.type === 'CAMPAIGN' && action.command.command.type === 'WITHDRAW_PROTECT' ||
    action.command.type === 'EPILOGUE' && action.command.command.type === 'WITHDRAW';
}

/** Render only public facts and dispatch the supplied intent without predicting its result. */
export function RedPriestPanel({ value, busy, blocked = false, error = null, onCommand, onClose }: RedPriestPanelProps) {
  const id = useId();
  const heading = useRef<HTMLHeadingElement>(null);
  const submitted = useRef(false);
  const confirmationHeading = useRef<HTMLHeadingElement>(null);
  const confirmationTrigger = useRef<HTMLButtonElement | null>(null);
  const [confirmation, setConfirmation] = useState<{ action: RedPriestAction; facts: string } | null>(null);
  const [pending, setPending] = useState(false);
  const facts = JSON.stringify(value);
  const locked = busy || blocked || pending || error !== null || value.resources.health <= 0;
  const live = confirmation?.facts === facts ? value.actions.find(action => action.id === confirmation.action.id
    && JSON.stringify(action.command) === JSON.stringify(confirmation.action.command)) : undefined;
  useEffect(() => { heading.current?.focus(); }, []);
  useEffect(() => {
    if (!busy) { submitted.current = false; setPending(false); }
  }, [facts, busy, error]);
  useEffect(() => {
    if (confirmation && (confirmation.facts !== facts || error !== null)) setConfirmation(null);
  }, [facts, error, confirmation]);
  useEffect(() => {
    if (confirmation) confirmationHeading.current?.focus();
    else confirmationTrigger.current?.focus();
  }, [confirmation]);

  // Keep the next useful step and ordinary withdrawal on the first screen.
  // Secondary choices remain available, with their exact costs and reasons.
  const withdrawals = value.actions.filter(isWithdrawal);
  const priority = [...value.actions.filter(action => action.preferredAction && !isWithdrawal(action)).slice(0, Math.max(0, 3 - withdrawals.length)), ...withdrawals];
  const main = [...priority, ...value.actions.filter(action => !priority.includes(action))].slice(0, 3);
  const secondary = value.actions.filter(action => !main.includes(action));
  const situation = value.sections.filter(section => ['campaign-status', 'campaign-losses', 'epilogue'].includes(section.id));
  const preparation = value.sections.filter(section => !situation.includes(section));

  function submit(action: RedPriestAction) {
    if (locked || submitted.current || !action.enabled || action.command.type === 'CONSUME' && action !== live) return;
    submitted.current = true;
    setPending(true);
    onCommand(action.command);
  }
  function choose(action: RedPriestAction, trigger: HTMLButtonElement) {
    if (locked || confirmation || submitted.current || !action.enabled) return;
    if (action.command.type === 'CONSUME') {
      confirmationTrigger.current = trigger;
      setConfirmation({ action, facts });
    } else submit(action);
  }
  function cancelConfirmation() {
    if (!locked) setConfirmation(null);
  }

  function actionButton(action: RedPriestAction) {
    const index = value.actions.indexOf(action);
    return <div key={action.id}>
      <button className={`slice-button${action.preferredAction ? '' : ' quiet'}`}
        disabled={locked || confirmation !== null || !action.enabled}
        aria-describedby={`${id}-cost-${index}${action.reason ? ` ${id}-reason-${index}` : ''}`}
        onClick={event => choose(action, event.currentTarget)}>{action.label}</button>
      <p id={`${id}-cost-${index}`} className="slice-muted">{action.cost}</p>
      {action.reason && <p id={`${id}-reason-${index}`} className="seer-action-reason">{action.reason}</p>}
    </div>;
  }

  function publicSection(section: RedPriestProjection['sections'][number]) {
    const index = value.sections.indexOf(section);
    return <section key={section.id} aria-labelledby={`${id}-section-${index}`}>
      <h3 id={`${id}-section-${index}`}>{section.title}</h3>
      {section.lines.map((line, lineIndex) => <p key={lineIndex}>{line}</p>)}
    </section>;
  }

  return <section className="seer-panel" aria-labelledby={`${id}-title`} aria-busy={busy || pending}>
    <div inert={confirmation !== null}>
    <header>
      <h2 id={`${id}-title`} ref={heading} tabIndex={-1}>{value.title}</h2>
      <p>{value.story}</p>
      <p className="slice-muted">健康 {value.resources.health} · 精神 {value.resources.mind} · 灵性 {value.resources.spirituality} · {value.resources.cash} · 本周行动 {value.resources.actionsRemaining}</p>
    </header>
    <section aria-labelledby={`${id}-next`}>
      <h3 id={`${id}-next`}>眼下该做什么</h3>
      <p>{value.nextStep}</p>
      {value.risk && <p className="slice-notice">{value.risk}</p>}
      <div className="seer-actions">{main.map(actionButton)}</div>
      {secondary.length > 0 && <details className="seer-fold">
        <summary>其他可选行动</summary>
        <div className="seer-actions">{secondary.map(actionButton)}</div>
      </details>}
    </section>
    {situation.map(publicSection)}
    {preparation.length > 0 && <details className="seer-fold">
      <summary>原物与个人账目</summary>
      {preparation.map(publicSection)}
    </details>}
    {value.abilities.length > 0 && <details className="seer-fold">
      <summary>已掌握的能力</summary>
      {value.abilities.map(ability => <div key={ability.id}>
        <h3>{ability.label} · 熟练 {ability.mastery}</h3>
        <p>{ability.description}</p>
      </div>)}
    </details>}
    {onClose && <button className="slice-button quiet" disabled={locked || confirmation !== null} onClick={onClose}>返回当前生活</button>}
    </div>
    {confirmation && <section className="seer-current-case" role="dialog" aria-modal="true" aria-label="红祭司服药确认" onKeyDown={event => {
      if (event.key === 'Escape') { event.preventDefault(); cancelConfirmation(); }
      if (event.key !== 'Tab') return;
      const buttons = Array.from(event.currentTarget.querySelectorAll<HTMLButtonElement>('button:not(:disabled)'));
      const first = buttons[0], last = buttons[buttons.length - 1];
      if (!first || !last) { event.preventDefault(); return; }
      if (event.shiftKey && (document.activeElement === first || document.activeElement === confirmationHeading.current)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }}>
      <h3 ref={confirmationHeading} tabIndex={-1}>{live?.label ?? '当前准备已变化'}</h3>
      <p>{live?.cost}</p>
      <p className="slice-notice">{value.risk}</p>
      <p>确认服用这一份原魔药。成功或失败都会消耗原物与已付代价；失败会留下实际伤势，可能死亡。</p>
      <div className="seer-confirm-buttons">
        <button className="slice-button quiet" disabled={locked} onClick={cancelConfirmation}>取消，继续准备</button>
        <button className="slice-button" disabled={locked || !live?.enabled} onClick={() => { if (live) submit(live); }}>确认服用这一份原魔药</button>
      </div>
    </section>}
  </section>;
}
