import type { SliceState } from '../slice/types.js';
import type { SeerContext } from '../seer/index.js';
import type { RedPriestCommand, RedPriestProjection, RedPriestState } from './types.js';
import { createRedPriestState, startRedPriest, transitionRedPriest, sameRedPriest, redPriestDigest,
  openRedPriestOwnedEngine, snapshotRedPriestOwnedEngine, advanceRedPriestOwnedEngine, blockRedPriestOwnedEngine,
  type RedPriestOwnedEngine } from './engine.js';
import { redPriestBudget, redPriestHistoryDigest, redPriestAcquisitionSnapshot, redPriestSourceBlock, validateRedPriestSource } from './source.js';
import { RED_PRIEST_ABILITIES, RED_PRIEST_STORY, RED_PRIEST_GOAL, RED_PRIEST_RISK, RED_PRIEST_FORMULA, RED_PRIEST_CITY_PLACES } from './content.js';
import { validateRedPriestCampaignCommand, projectRedPriestCampaign } from './campaign.js';
import { RED_PRIEST_CAMPAIGN_COALITION, RED_PRIEST_CAMPAIGN_NODES, RED_PRIEST_CAMPAIGN_ROUTES, RED_PRIEST_CAMPAIGN_POLITIES } from './campaign-content.js';
import { validateRedPriestMaterialCommand, projectRedPriestMaterials, type RedPriestMaterialCommand } from './materials.js';
import { RED_PRIEST_MATERIAL_COSTS, RED_PRIEST_MATERIAL_LOCATIONS } from './material-content.js';
import { validateRedPriestEpilogueCommand } from './epilogue.js';
import { HUNTER_ABILITIES } from '../hunter/content.js';
import { PROVOKER_ABILITIES } from '../provoker/content.js';
import { PYROMANIAC_ABILITIES } from '../pyromaniac/content.js';
import { CONSPIRATOR_ABILITIES } from '../conspirator/content.js';
import { REAPER_ABILITIES } from '../reaper/content.js';
import { IRON_BLOOD_KNIGHT_ABILITIES } from '../iron-blood-knight/content.js';
import { WAR_BISHOP_ABILITIES } from '../war-bishop/content.js';
import { WEATHER_WARLOCK_ABILITIES } from '../weather-warlock/content.js';
import { CONQUEROR_ABILITIES } from '../conqueror/content.js';
export { createRedPriestState } from './engine.js';
export { redPriestSourceView } from './source.js';
export type { RedPriestOwnedEngine } from './engine.js';
export type { RedPriestCommand, RedPriestState, RedPriestProjection } from './types.js';
const record = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
const exact = (v: object, keys: string[]) => sameRedPriest(Object.keys(v).sort(), keys.sort());
const id = (v: unknown): v is string => typeof v === 'string' && v.length > 0 && v.length <= 300 && v.trim() === v;
export function validateRedPriestCommand(v: unknown): v is RedPriestCommand {
  if (!record(v)) return false;
  if (['LEARN_GUIDANCE', 'WORK', 'REST', 'CLINIC', 'NEXT_WEEK', 'START_EPILOGUE'].includes(String(v.type))) return exact(v, ['type']);
  if (v.type === 'TRAVEL') return exact(v, ['type', 'to']) && id(v.to) &&
    (RED_PRIEST_CITY_PLACES.some(p => p.id === v.to) || RED_PRIEST_CAMPAIGN_NODES.some(n => n.id === v.to));
  if (v.type === 'CONSUME') return exact(v, ['type', 'compoundId', 'confirmed']) && id(v.compoundId) && v.confirmed === true;
  if (!exact(v, ['type', 'command'])) return false;
  return v.type === 'CAMPAIGN' ? validateRedPriestCampaignCommand(v.command) : v.type === 'MATERIAL' ? validateRedPriestMaterialCommand(v.command)
    : v.type === 'EPILOGUE' ? validateRedPriestEpilogueCommand(v.command) : false;
}
function assertCurrent(s: SliceState, root: RedPriestState): void {
  const source = root.source!, frame = root.frame!;
  if (!source || !frame || s.progression.pathwayId !== 'hunter' || !sameRedPriest(redPriestBudget(s), frame.budget) || !sameRedPriest(s.random, frame.random)) throw Error('当前身体、资源与原动作记录不一致。');
  if (s.revision !== source.revision + 1 + root.journal.length || root.journal.some((e, i) => e.revision !== source.revision + 2 + i)) throw Error('当前动作次序不一致。');
  const { coreStats: _current, ...identity } = s.character, { coreStats: _source, ...originalIdentity } = source.character;
  if (!sameRedPriest(identity, originalIdentity) || Object.entries(frame.finance).some(([key, value]) => !sameRedPriest(s[key as keyof SliceState], value))) throw Error('当前身份或实际生活账本不一致。');
  if (source.historyDigest !== redPriestHistoryDigest(s) || source.originalWorldDigest !== redPriestDigest(s.world) ||
    s.combatHistory.length !== source.combatHistoryLength || source.combatHistoryDigest !== redPriestDigest(s.combatHistory) ||
    !sameRedPriest(source.acquisition, redPriestAcquisitionSnapshot(s))) throw Error('旧同伴、原战争或原瓶履历被改写。');
  if (s.combat !== null || s.activeEvent !== null || s.eventQueue.length !== 0 || s.pulse !== 'NONE') throw Error('本章不能同时开启旧现场。');
  if ((frame.budget.sequence === 0) !== (root.promotionWeek !== null)) throw Error('当前晋升与实际服药记录不一致。');
}
function guidanceBlock(s: SliceState): string | null {
  if (!sameRedPriest(s.redPriest, createRedPriestState())) return '已有本章记录，不能重新开始或补发原物。';
  return redPriestSourceBlock(s);
}
function publicReason(reason: string | null): string | null {
  if (reason === null) return null;
  if (/[\u3400-\u9fff]/.test(reason) && !/[A-Z_]{6,}|seed|cursor|digest|receipt/i.test(reason)) return reason;
  if (/LATER_WEEK|NEXT_WEEK/.test(reason)) return '需要真实经过一周，原花费与调查结果保留。';
  if (/RESOURCES|INSUFFICIENT/.test(reason)) return '实际行动、费用或灵性不足，可先工作与休养。';
  if (/LOCATION|AT_LOCATION/.test(reason)) return '须先沿普通道路亲自到达原件所在地点。';
  if (/UNAVAILABLE|NOT_ACTIVE|BLOCKED/.test(reason)) return '原件已无法按当前保管线继续取得，原后果保留。';
  return '请先核对原件、实际所在地和前一步准备。';
}
export function validateRedPriestState(s: SliceState): boolean {
  try {
    if (sameRedPriest(s.redPriest, createRedPriestState())) return s.progression.pathwayId !== 'hunter' || s.progression.sequence !== 0;
    const head = openRedPriestOwnedEngine(s); assertCurrent(s, snapshotRedPriestOwnedEngine(head)); return true;
  } catch { return false; }
}
export function hasRedPriestHistory(s: SliceState): boolean {
  try { return s.redPriest.guidanceKnown && s.redPriest.source !== null && s.progression.pathwayId === 'hunter' && validateRedPriestSource(s, s.redPriest.source); } catch { return false; }
}
export function hasRedPriestLock(s: SliceState): boolean { return hasRedPriestHistory(s); }
export function openRedPriestOwnedHead(s: SliceState): RedPriestOwnedEngine {
  const head = openRedPriestOwnedEngine(s); assertCurrent(s, snapshotRedPriestOwnedEngine(head)); return head;
}
export function assertOwnedRedPriestCurrent(s: SliceState, head: RedPriestOwnedEngine): void {
  const root = snapshotRedPriestOwnedEngine(head);
  if (!sameRedPriest(root, s.redPriest)) throw Error('当前会话与实际存档版本不一致。');
  assertCurrent(s, root);
}
export function redPriestCommandBlock(s: SliceState, command: RedPriestCommand): string | null {
  if (!validateRedPriestCommand(command)) return '这项行动的内容无效。';
  if (s.status !== 'ACTIVE') return '已经死亡或结束的角色不能继续行动。';
  if (command.type === 'LEARN_GUIDANCE') return guidanceBlock(s);
  try { return publicReason(blockRedPriestOwnedEngine(openRedPriestOwnedHead(s), command, s.revision + 1)); }
  catch { return '当前记录未通过核验，不能继续行动。'; }
}
export function ownedRedPriestCommandBlock(s: SliceState, command: RedPriestCommand, head: RedPriestOwnedEngine): string | null {
  if (!validateRedPriestCommand(command)) return '这项行动的内容无效。';
  if (s.status !== 'ACTIVE') return '已经死亡或结束的角色不能继续行动。';
  if (command.type === 'LEARN_GUIDANCE') return '已有本章记录，不能重新开始或补发原物。';
  try { assertOwnedRedPriestCurrent(s, head); return publicReason(blockRedPriestOwnedEngine(head, command, s.revision + 1)); }
  catch { return '当前记录未通过核验，不能继续行动。'; }
}
function publish(s: SliceState, command: RedPriestCommand, root: RedPriestState, ctx: SeerContext): void {
  const b = root.frame!.budget; s.redPriest = root;
  s.week = b.week; s.date = clone(b.date); s.actionsRemaining = b.actions; s.cash = b.cash; s.health = b.health;
  s.mind = b.mind; s.spirituality = b.spirituality; s.status = b.status; s.injuries = clone(b.injuries); s.injuryRisk = b.injuryRisk;
  s.progression.sequence = b.sequence; s.progression.acting = b.acting; s.progression.mastery = { ...b.mastery }; s.character.coreStats = { ...b.coreStats };
  s.seer.pollution = b.pollution; s.seer.completedSources = [...b.completedSources]; s.random = { ...root.frame!.random };
  Object.assign(s, clone(root.frame!.finance));
  const event = command.type === 'LEARN_GUIDANCE' ? null : root.journal.at(-1)!;
  s.lastCheck = event?.randomReceipts.length ? clone(event.randomReceipts.at(-1)!.check) : null;
  if (!event) ctx.note('北大陆战争筹备', '已核对原活身份、三份特性和原军团历史；旧互助成员留在原来的生活中。伤势、个人欠款和全部资源继续保留。');
  else {
    for (const receipt of event.financeReceipts) ctx.note(receipt.title, receipt.text);
    ctx.note(b.sequence === 0 ? '红祭司当前行动' : '北大陆当前行动', event.notes.join('') || `健康${b.health}，精神${b.mind}，灵性${b.spirituality}；现款${b.cash}便士。`);
  }
}
const clone = <T>(v: T): T => structuredClone(v);
export function applyRedPriestCommand(s: SliceState, command: RedPriestCommand, ctx: SeerContext): void {
  if (!validateRedPriestCommand(command) || s.status !== 'ACTIVE') throw Error('当前不能执行这项行动。');
  let root: RedPriestState;
  if (command.type === 'LEARN_GUIDANCE') { const reason = guidanceBlock(s); if (reason) throw Error(reason); root = startRedPriest(s); }
  else { const head = openRedPriestOwnedHead(s); root = snapshotRedPriestOwnedEngine(advanceRedPriestOwnedEngine(head, command, s.revision + 1)); }
  publish(s, command, root, ctx);
}
export function applyOwnedRedPriestCommand(s: SliceState, command: RedPriestCommand, ctx: SeerContext, head: RedPriestOwnedEngine): RedPriestOwnedEngine {
  assertOwnedRedPriestCurrent(s, head);
  if (!validateRedPriestCommand(command) || command.type === 'LEARN_GUIDANCE' || s.status !== 'ACTIVE') throw Error('当前不能执行这项行动。');
  const next = advanceRedPriestOwnedEngine(head, command, s.revision + 1); publish(s, command, snapshotRedPriestOwnedEngine(next), ctx); return next;
}
const inherited = [...HUNTER_ABILITIES, ...PROVOKER_ABILITIES, ...PYROMANIAC_ABILITIES, ...CONSPIRATOR_ABILITIES, ...REAPER_ABILITIES,
  ...IRON_BLOOD_KNIGHT_ABILITIES, ...WAR_BISHOP_ABILITIES, ...WEATHER_WARLOCK_ABILITIES, ...CONQUEROR_ABILITIES];
const placeName = (place: string) => RED_PRIEST_CITY_PLACES.find(p => p.id === place)?.title ?? RED_PRIEST_CAMPAIGN_NODES.find(n => n.id === place)?.name ?? '原现场';
export function projectRedPriest(s: SliceState): RedPriestProjection {
  if (sameRedPriest(s.redPriest, createRedPriestState())) return projection(s, null);
  return projectOwnedRedPriest(s, openRedPriestOwnedHead(s));
}
export function projectOwnedRedPriest(s: SliceState, head: RedPriestOwnedEngine): RedPriestProjection { assertOwnedRedPriestCurrent(s, head); return clone(projection(s, head)); }
function projection(s: SliceState, owned: RedPriestOwnedEngine | null): RedPriestProjection {
  const result: RedPriestProjection = { title: '红祭司晋升筹备', guidanceKnown: false, promoted: false,
    story: RED_PRIEST_STORY, nextStep: RED_PRIEST_GOAL, risk: RED_PRIEST_RISK,
    resources: { health: s.health, mind: s.mind, spirituality: s.spirituality, cash: `${s.cash}便士`, actionsRemaining: s.actionsRemaining },
    abilities: [], actions: [], sections: [], insideCase: false };
  if (s.progression.pathwayId === 'hunter') result.abilities = inherited.filter(a => Object.hasOwn(s.progression.mastery, a.id))
    .map(a => ({ id: a.id, label: a.label, description: a.description, mastery: s.progression.mastery[a.id]! }));
  if (!owned) {
    const reason = guidanceBlock(s); result.actions.push({ id: 'red-priest-guidance', label: '核对大陆战争与原材料', cost: '不花行动与费用',
      enabled: reason === null, reason, command: { type: 'LEARN_GUIDANCE' }, preferredAction: true });
    result.sections.push({ id: 'requirements', title: '成神所需', lines: [...RED_PRIEST_FORMULA.map(i => `${i.name}：${i.quantity}${i.unit}。`), '亲自发动真实北大陆战争；五处独立胜利、三大战区控制与实际停战共同证明经历。'] });
    return result;
  }
  const root = snapshotRedPriestOwnedEngine(owned), f = root.frame!, b = f.budget, campaign = projectRedPriestCampaign(root.campaign!), materials = projectRedPriestMaterials(root.materials!);
  result.guidanceKnown = true; result.promoted = b.sequence === 0; result.title = b.sequence === 0 ? '红祭司 · 战争之后' : '红祭司 · 北大陆战争';
  result.insideCase = !RED_PRIEST_CITY_PLACES.some(p => p.id === f.location) || root.epilogue?.status === 'ACTIVE';
  if (b.sequence === 0) result.abilities.push(...RED_PRIEST_ABILITIES.map(a => ({ ...a, mastery: b.mastery[a.id] ?? 0 })));
  const add = (command: RedPriestCommand, label: string, cost: string, preferred = false): void => {
    const reason = s.status !== 'ACTIVE' ? '已经死亡的角色不能继续行动。' : publicReason(blockRedPriestOwnedEngine(owned, command, s.revision + 1));
    result.actions.push({ id: `red-priest-action-${result.actions.length + 1}`, command, label, cost, enabled: reason === null, reason,
      ...(preferred && reason === null && !result.actions.some(a => a.preferredAction) ? { preferredAction: true } : {}) });
  };
  const travel = (to: string, preferred = false) => add({ type: 'TRAVEL', to }, `前往${placeName(to)}`, RED_PRIEST_CITY_PLACES.some(p => p.id === f.location) && RED_PRIEST_CITY_PLACES.some(p => p.id === to) ? '1行动、10便士；普通城市道路1小时' : '1行动；沿已行经大陆路线逐周结算旅费、生活费与旧还款', preferred);
  result.sections.push({ id: 'campaign-status', title: '当前战区与目标', lines: [`本人在${placeName(f.location)}；原军团在${campaign.locationName}。`, campaign.nextStep,
    `独立胜利${campaign.achievement.victories}/5；交战战区${campaign.achievement.engagedTheaters}/3；受控战区${campaign.achievement.controlledTheaters}/3。`,
    ...campaign.theaters.map(t => `${t.name}：${t.geography}；${t.engaged ? '实际发生交战' : '尚未交战'}，${t.controlled ? '已控制运输目标' : '运输目标尚未控制'}。`) ] });
  result.sections.push({ id: 'campaign-losses', title: '原军团与战争损失', lines: [
    ...campaign.legions.filter(l => l.role === 'FIELD').map(l => `${l.name}：现员${l.personnel}，阵亡${l.killed}，伤员${l.wounded}，补给${l.supply}，士气${l.morale}。`),
    ...campaign.polities.map(p => `${p.name}：国库${p.treasury}；动员${p.mobilizedPersonnel}人，迁离${p.displacedResidents}人，已疏散${p.evacuatedResidents}人，居民死亡${p.civilianDeaths}人。`) ] });
  result.sections.push({ id: 'materials', title: '三份原特性与唯一性', lines: [materials.rule, ...materials.items.map(i => `${i.title}：${i.status}${i.locationId ? `，${placeName(i.locationId)}` : ''}。`)] });
  const debt = f.finance.debts.reduce((n, d) => n + d.remaining, 0);
  result.sections.push({ id: 'finance', title: '个人生活与旧账', lines: [`现款${b.cash}便士；未付本金${debt}便士；下次约定还款${f.finance.debts.reduce((n, d) => n + Math.min(d.remaining, d.weeklyPayment), 0)}便士。`,
    '每次真实跨周继续支付生活费及旧约还款；不足的生活费如实计欠，次周采用赤贫生活。军团国库不属于个人。',
    `当前伤势${b.injuries.length}份；重伤先以60便士普通处置，再经之后休养达到80健康。`] });
  if (root.epilogue) {
    const ep = root.epilogue; result.story = '停战后的原运输侧线起火，三名原伤员尚待移出。六人分队来自原军团，仍受疲劳、伤势和现场抵抗限制。';
    result.nextStep = ep.status === 'ACTIVE' ? '决定有限协同、现场控火与实际搬运，也可以沿原安全侧线撤出。' : ep.reported ? '战后救援已经交接，原战争与身体后果继续保留。' : '将实际救援与分队损失交回原军团。';
    result.sections.unshift({ id: 'epilogue', title: '原运输路救援', lines: [`火势${ep.fire}；运输路损坏${ep.routeDamage}；已转运伤员${ep.patients.filter(p => p.status === 'EVACUATED').length}/3。`,
      `原六人分队：阵亡${ep.killed}，受伤${ep.wounded}，已返队${ep.returned}；救出伤员没有被自动治愈。`, ep.journal.at(-1)?.summary ?? '本人已经实际抵达这处原火场。'] });
    if (ep.status === 'ACTIVE') {
      add({ type: 'EPILOGUE', command: { type: 'COORDINATE' } }, '以同袍战旌协同原分队', '1行动、8灵性、8精神；仅本次六人', true);
      add({ type: 'EPILOGUE', command: { type: 'CONTAIN_FIRE' } }, '以赤焰界限控制原火势', '1行动、12灵性、10精神；本火场仅一次', true);
      add({ type: 'EPILOGUE', command: { type: 'EVACUATE' } }, '沿实际侧线搬运伤员', '1行动；抵抗与伤亡照实结算', true);
      add({ type: 'EPILOGUE', command: { type: 'WITHDRAW' } }, '沿原安全侧线撤出', '0行动；保留未完成救援与全部后果'); return result;
    }
    if (!ep.reported) add({ type: 'EPILOGUE', command: { type: 'REPORT' } }, '交接救援与分队损失', '不花行动与费用', true);
  }
  if (b.sequence === 0 && !root.epilogue) {
    result.nextStep = '沿原大陆运输路返回停战后的原军团驻地，参与一宗有限战后救援。';
    if (f.location === root.campaign!.location) add({ type: 'START_EPILOGUE' }, '到原运输路参加救援', '1行动；原军团实派六人、消耗2补给', true);
    else if (RED_PRIEST_CITY_PLACES.some(p => p.id === f.location)) travel(root.campaign!.location, true);
  }
  if (b.sequence === 1 && root.materials!.status === 'ACTIVE') {
    for (const item of root.materials!.items) {
      let c: RedPriestMaterialCommand | null = null, target = item.locationId, label = '';
      if (item.disposition === 'UNLOCATED' || item.disposition === 'SUPPLIER_BOTTLED') { c = { type: 'TRACE_DISPOSITION', itemId: item.id }; target = RED_PRIEST_MATERIAL_LOCATIONS.archive; label = '查原瓶处置与保管记录'; }
      else if (item.disposition === 'LOCATED_DIRTY' || item.disposition === 'LOCATED_SEALED') { c = { type: 'VERIFY_CONTAINER', itemId: item.id }; label = '亲自核验原封容器'; }
      else if (item.disposition === 'VERIFIED_DIRTY') { c = { type: 'PURIFY_REMAINS', itemId: item.id }; label = '净化已核验原残余'; }
      else if (item.disposition === 'CLEAN_SEALED') { c = { type: 'TRANSFER_CUSTODY', itemId: item.id }; label = '完成原件保管交接'; }
      else if (item.disposition === 'SEALED_RELIC') { c = { type: 'INSPECT_RELIC' }; target = RED_PRIEST_MATERIAL_LOCATIONS.relicArchive; label = '调查独立遗物的保管链'; }
      else if (item.disposition === 'INSPECTED_RELIC') { c = { type: 'VERIFY_RELIC' }; label = '亲赴原库核验唯一性'; }
      else if (item.disposition === 'VERIFIED_RELIC') { c = { type: 'TRANSFER_RELIC' }; label = '完成唯一性原件交接'; }
      if (c && target) {
        if (f.location !== target) { if (!result.actions.some(a => a.command.type === 'TRAVEL' && a.command.to === target)) travel(target, true); }
        else { const cost = RED_PRIEST_MATERIAL_COSTS[c.type]; add({ type: 'MATERIAL', command: c }, label, `${cost.actions}行动、${cost.cash}便士、${cost.spirituality}灵性；1小时`, true); }
      }
    }
    const ready = root.materials!.items.filter(i => i.disposition === 'PLAYER_HELD').length === 3;
    if (ready) {
      if (f.location !== RED_PRIEST_MATERIAL_LOCATIONS.workshop) travel(RED_PRIEST_MATERIAL_LOCATIONS.workshop, true);
      else add({ type: 'MATERIAL', command: { type: 'PREPARE_COMPOUND' } }, '用同批原件调配成药', '1行动、120便士、8灵性；消耗有限实际辅料', true);
    }
    for (const compound of root.materials!.compounds.filter(c => c.status === 'PREPARED'))
      add({ type: 'CONSUME', compoundId: compound.id, confirmed: true }, '确认风险并饮下原成药', '1行动、30灵性；失败可能重伤、污染或死亡', true);
    result.nextStep = campaign.achievement.achieved && campaign.achievement.ceased ? '将两份外在原特性与唯一性带回调配室；恢复实际伤势后再决定服药。' : campaign.nextStep;
    if (f.location !== root.campaign!.location && RED_PRIEST_CITY_PLACES.some(p => p.id === f.location)) travel('loen-headquarters');
    if (f.location === root.campaign!.location) {
      if (root.campaign!.phase === 'CRISIS') {
        for (const polityId of RED_PRIEST_CAMPAIGN_COALITION) if (root.campaign!.polities[polityId].authority !== 'GRANTED')
          add({ type: 'CAMPAIGN', command: { type: 'REQUEST_AUTHORITY', polityId } }, `与${RED_PRIEST_CAMPAIGN_POLITIES.find(p => p.id === polityId)!.name}协商实际委托`, '1行动、60便士；实际1周', true);
        add({ type: 'CAMPAIGN', command: { type: 'DECLARE_OFFENSIVE' } }, '签发大陆战争发动命令', '1行动、80便士；实际1周，原各国实付动员', true);
      }
      if (root.campaign!.phase === 'ORDERED' || root.campaign!.phase === 'WAR') {
        const node = RED_PRIEST_CAMPAIGN_NODES.find(n => n.id === f.location);
        if (node) {
          add({ type: 'CAMPAIGN', command: { type: 'BATTLE', nodeId: node.id } }, `在${node.name}执行会战`, '1行动、40便士、6灵性；实际1周，真实军团伤亡', true);
          add({ type: 'CAMPAIGN', command: { type: 'CONSOLIDATE', nodeId: node.id } }, `巩固${node.name}与原运输设施`, '1行动、30便士；实际1周', true);
        }
        for (const route of RED_PRIEST_CAMPAIGN_ROUTES.filter(r => r.from === f.location)) add({ type: 'CAMPAIGN', command: { type: 'MARCH', nodeId: route.to } }, `沿原路行军至${placeName(route.to)}`, `1行动、20便士；${route.weeks}周及真实补给`, true);
        for (const polityId of RED_PRIEST_CAMPAIGN_COALITION) add({ type: 'CAMPAIGN', command: { type: 'REORGANIZE', polityId } }, `申请${RED_PRIEST_CAMPAIGN_POLITIES.find(p => p.id === polityId)!.name}有限整补`, '1行动、20便士；国库实付，原后备跨周抵达');
        add({ type: 'CAMPAIGN', command: { type: 'SEEK_ARMISTICE' } }, '协商真实停战', '1行动、20便士；实际1周', campaign.achievement.achieved);
      }
      if (!['ARMISTICE', 'WITHDRAWN'].includes(root.campaign!.phase)) add({ type: 'CAMPAIGN', command: { type: 'WITHDRAW_PROTECT' } }, '保护撤离并结束本场战争', '1行动；原路真实返程，原伤亡保留');
      add({ type: 'CAMPAIGN', command: { type: 'MILITARY_LABOUR', taskId: campaign.labour.nextTask.id } }, campaign.labour.nextTask.title,
        '2行动；每周至多一次，获授权原国库实际支付60便士');
    }
  }
  if (!RED_PRIEST_CITY_PLACES.some(p => p.id === f.location) && ['ARMISTICE', 'WITHDRAWN'].includes(root.campaign!.phase)) travel('loen-headquarters', b.sequence === 1);
  if (RED_PRIEST_CITY_PLACES.some(p => p.id === f.location)) add({ type: 'WORK' }, '做本周原职业工作', `1行动；本周工资${root.source!.character.weeklyWage}便士仅一次`);
  add({ type: 'CLINIC' }, '支付普通重伤处置', '1行动、60便士；之后仍须休养');
  add({ type: 'REST' }, '按当前生活档休养', '1行动；旧重伤须先处置', b.injuries.length > 0);
  add({ type: 'NEXT_WEEK' }, '度过真实七天', '放弃本周余下行动；照常结算生活费与旧还款', b.actions === 0);
  if (b.sequence === 1 && f.location === root.campaign!.location &&
    f.location !== 'loen-headquarters' && ['ORDERED', 'WAR'].includes(root.campaign!.phase)) {
    let returnWeeks = 0;
    for (const route of RED_PRIEST_CAMPAIGN_ROUTES) {
      returnWeeks += route.weeks;
      if (route.to === f.location) break;
    }
    // Append without renumbering any existing action. This is a real logistics
    // journey, separate from permanent withdrawal and never an advance wage.
    add({ type: 'CAMPAIGN', command: { type: 'RETURN_TO_HEADQUARTERS' } }, '沿原路回总部整备',
      `1行动；实际返程${returnWeeks}周，无个人预付费用；原军费、补给与生活欠款照常，战争和伤亡保留`, b.cash < 70);
  }
  return result;
}
