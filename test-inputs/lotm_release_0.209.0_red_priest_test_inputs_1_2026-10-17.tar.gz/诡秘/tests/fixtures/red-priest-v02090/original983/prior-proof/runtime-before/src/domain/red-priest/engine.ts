import type { SliceState } from '../slice/types.js';
import type { PublicCoreStatKey } from '../../shared/contracts.js';
import { stableStringify } from '../canonical.js';
import { sha256Hex } from '../checksum.js';
import { addGameWeeks } from '../game-calendar.js';
import { SLICE_LIFE } from '../../content/slice-events.js';
import { resolveSliceWeeklyFinance } from '../slice/weekly-finance.js';
import { DeterministicActionRandomStream } from '../../resolution/deterministic-random.js';
import { resolveNormalCheck } from '../../resolution/normal-check.js';
import { createRedPriestSource, validateRedPriestSource, type RedPriestSource, type RedPriestBudget } from './source.js';
import { validateRedPriestCommand } from './index.js';
import { createRedPriestCampaign, reduceRedPriestCampaign, getRedPriestCampaignBlock, getRedPriestCampaignChallenge,
  deriveRedPriestCampaignAchievement, advanceRedPriestCampaignToWeek, dispatchRedPriestCampaignDetachment, settleRedPriestCampaignDetachment,
  type RedPriestCampaignHost } from './campaign.js';
import { RED_PRIEST_CAMPAIGN_NODES, RED_PRIEST_CAMPAIGN_ROUTES, type CampaignNodeId } from './campaign-content.js';
import { createRedPriestMaterials, reduceRedPriestMaterials, redPriestMaterialBlock, applyRedPriestMaterialConsumption,
  transportRedPriestMaterials, type RedPriestMaterialsOrigin, type RedPriestMaterialAuthority, type RedPriestMaterialFrame,
  type RedPriestMaterialActor, type RedPriestMaterialCheckReceipt, type RedPriestMaterialConsumptionReceipt,
  type RedPriestMaterialTransportReceipt, type RedPriestMaterialHost, type RedPriestMaterialCommand,
  type RedPriestMaterialEvidence } from './materials.js';
import { RED_PRIEST_MATERIAL_IDS, RED_PRIEST_UNIQUENESS_ID, RED_PRIEST_MATERIAL_LOCATIONS,
  RED_PRIEST_RELIC_CUSTODY, RED_PRIEST_SUPPLIER_LEADS, redPriestCompoundSupply, RED_PRIEST_MATERIAL_COSTS } from './material-content.js';
import { RED_PRIEST_CITY_PLACES, RED_PRIEST_CONSUMPTION } from './content.js';
import { RED_PRIEST_ABILITY_IDS, type RedPriestState, type RedPriestCommand, type RedPriestFrame, type RedPriestEvent, type RedPriestCheckReceipt } from './types.js';
import { createRedPriestEpilogue, applyRedPriestEpilogue, redPriestEpilogueBlock } from './epilogue.js';
export const sameRedPriest = (a: unknown, b: unknown): boolean => stableStringify(a) === stableStringify(b);
export const redPriestDigest = (v: unknown): string => sha256Hex(stableStringify(v));
function need(value: unknown, reason: string): asserts value { if (!value) throw Error(reason); }
const clone = <T>(value: T): T => structuredClone(value);
const city = (id: string) => RED_PRIEST_CITY_PLACES.some(p => p.id === id);
function dataDigest(root: RedPriestState): string { const { journal: _journal, ...data } = root; return redPriestDigest(data); }
export function createRedPriestState(): RedPriestState {
  return { version: 1, guidanceKnown: false, source: null, frame: null, promotionWeek: null, campaign: null, materials: null, epilogue: null, journal: [] };
}
interface VerifiedContext { readonly origin: RedPriestMaterialsOrigin }
interface Prepared { root: RedPriestState; context: VerifiedContext }
declare const redPriestOwnedEngineBrand: unique symbol;
export interface RedPriestOwnedEngine { readonly [redPriestOwnedEngineBrand]: true }
const owned = new WeakMap<RedPriestOwnedEngine, Prepared>();
function getOwned(handle: RedPriestOwnedEngine): Prepared { const value = owned.get(handle); need(value, '无效的当前领域会话。'); return value; }
function retain(value: Prepared): RedPriestOwnedEngine { const handle = Object.freeze({}) as RedPriestOwnedEngine; owned.set(handle, value); return handle; }
function frozen<T>(v: T): T { if (v && typeof v === 'object' && !Object.isFrozen(v)) { for (const child of Object.values(v)) frozen(child); Object.freeze(v); } return v; }
function materialOrigin(source: RedPriestSource): RedPriestMaterialsOrigin {
  const sourceDigest = source.historyDigest;
  return { version: 1, caseId: `red-priest:${source.runId}`, actorId: source.actorId,
    sourceSnapshotDigest: redPriestDigest(source), sourceDigest, bottlesDigest: redPriestDigest(source.acquisition.bottles),
    acquisitionJournalDigest: redPriestDigest(source.acquisition.consumptions),
    checkpoint: { week: source.budget.week, revision: source.revision, locationId: 'loen-headquarters' },
    bottles: source.acquisition.bottles.map(bottle => {
      const event = source.acquisition.consumptions.find(e => e.command.type === 'CONSUME' && e.command.bottleId === bottle.id);
      if (bottle.status === 'CONSUMED') need(event?.check, '原服药记录缺少实际检定。');
      const integrated = bottle.outcome === 'SUCCESS' || bottle.outcome === 'GREAT_SUCCESS';
      return { bottleId: bottle.id, eventId: event ? `${source.runId}:conqueror-consumption:${event.revision}` : `${source.runId}:conqueror-original:${bottle.id}`,
        sourceDigest, acquisitionEventDigest: redPriestDigest(event ?? bottle), week: event?.week ?? bottle.acquiredWeek ?? bottle.stockedWeek ?? source.budget.week,
        revision: event?.revision ?? source.revision, status: bottle.status, outcome: bottle.outcome,
        roll: event?.check?.roll ?? null, chance: event?.check?.chance ?? null, integratedActorId: integrated ? source.actorId : null };
    }),
    uniqueness: { id: RED_PRIEST_UNIQUENESS_ID, incumbentActorId: null, custody: clone([...RED_PRIEST_RELIC_CUSTODY]) } };
}
/** Exact capabilities are scoped to one independently produced frame. They are
 * never reconstructed from a saved receipt and are never accepted from a caller. */
function authority(context: VerifiedContext, frame: RedPriestMaterialFrame | null,
  consumption: RedPriestMaterialConsumptionReceipt | null = null, transport: RedPriestMaterialTransportReceipt | null = null): RedPriestMaterialAuthority {
  return { verifyOrigin: origin => sameRedPriest(origin, context.origin),
    verifyHost: candidate => frame !== null && sameRedPriest(candidate, frame),
    verifyEvidence: (e, f) => frame !== null && sameRedPriest(f, frame) && frame.evidence !== null && sameRedPriest(e, frame.evidence),
    verifyConsumption: (r, f) => consumption !== null && sameRedPriest(r, consumption) && sameRedPriest(f, frame),
    verifyTransport: (r, f) => transport !== null && sameRedPriest(r, transport) && sameRedPriest(f, frame) };
}
function start(source: RedPriestSource): Prepared {
  const root = createRedPriestState(), origin = frozen(materialOrigin(source)), context = { origin };
  root.guidanceKnown = true; root.source = frozen(clone(source));
  root.frame = { budget: clone(source.budget), random: { ...source.random }, finance: clone(source.finance), location: 'loen-headquarters', nowSecond: 0 };
  root.campaign = createRedPriestCampaign(source.runId, source.budget.week);
  root.materials = createRedPriestMaterials(origin, authority(context, null));
  return { root, context };
}
export function startRedPriest(s: SliceState): RedPriestState { return start(createRedPriestSource(s)).root; }
function actor(b: RedPriestBudget): RedPriestMaterialActor {
  return { status: b.status === 'ACTIVE' ? 'ACTIVE' : 'DEAD', sequence: b.sequence, health: b.health, mind: b.mind,
    pollution: b.pollution, injuryIds: b.injuries.map(i => i.id) };
}
function materialFrame(root: RedPriestState, eventId: string, revision: number, evidence: RedPriestMaterialEvidence | null = null): RedPriestMaterialFrame {
  const b = root.frame!.budget;
  return { eventId, actorId: root.source!.actorId, originDigest: root.materials!.originDigest, locationId: root.frame!.location,
    week: b.week, revision, actor: actor(b), resources: { cash: b.cash, actions: b.actions, spirituality: b.spirituality }, evidence };
}
function host(root: RedPriestState, eventId: string): RedPriestCampaignHost {
  const b = root.frame!.budget;
  return { week: b.week, eventId, player: { alive: b.status === 'ACTIVE', pathwayId: 'hunter', sequence: b.sequence,
    cash: b.cash, health: b.health, mind: b.mind, spirituality: b.spirituality, actionsRemaining: b.actions,
    campaignLocation: root.campaign!.location } };
}
function pay(b: RedPriestBudget, cost: { actions?: number; cash?: number; spirituality?: number; mind?: number; health?: number; pollution?: number }): void {
  need(b.actions >= (cost.actions ?? 0) && b.cash >= (cost.cash ?? 0) && b.spirituality >= (cost.spirituality ?? 0), '实际行动、费用或灵性不足。');
  b.actions -= cost.actions ?? 0; b.cash -= cost.cash ?? 0; b.spirituality -= cost.spirituality ?? 0;
  b.health = Math.max(0, b.health - (cost.health ?? 0)); b.mind = Math.max(0, b.mind - (cost.mind ?? 0));
  b.pollution = Math.min(100, b.pollution + (cost.pollution ?? 0));
  if (b.health === 0 || b.mind === 0 || b.pollution >= 100) { b.status = 'DEAD'; b.health = 0; }
}
function checks(frame: RedPriestFrame, eventId: string) {
  const receipts: RedPriestCheckReceipt[] = [];
  const check = (ability: PublicCoreStatKey, difficulty: number, modifier = 0) => {
    const before = frame.random.cursor, rng = new DeterministicActionRandomStream(frame.random.seed, before);
    const result = resolveNormalCheck({ ability, baseAbility: frame.budget.coreStats[ability], difficulty,
      modifiers: modifier ? [{ source: '实际在场条件', value: modifier }] : [], roll: rng.nextInt(1, 100) });
    frame.random.cursor = rng.cursor;
    receipts.push({ kind: 'CHECK', id: `${eventId}:check:${receipts.length + 1}`, check: result, cursorBefore: before, cursorAfter: rng.cursor }); return result;
  };
  return { receipts, check };
}
/** Ordinary bills and agreed debt payments continue during every real week of
 * travel and war. An unpaid bill is explicit principal, never erased or frozen. */
function weeks(root: RedPriestState, count: number, revision: number, eventId: string, notes: RedPriestEvent['financeReceipts']): void {
  const f = root.frame!, b = f.budget;
  for (let i = 0; i < count; i++) {
    let result = resolveSliceWeeklyFinance({ ...f.finance, week: b.week, revision, cash: b.cash, pulse: 'BILL', billAmount: 0 });
    notes.push(...result.receipts);
    if (result.eventId === 'LIFE-BILL-01') {
      const due = SLICE_LIFE[result.state.lifeTier].cost, paid = result.state.cash;
      result.state.cash = 0;
      result.state.debts.push({ id: `${eventId}:living-debt:${i}`, source: '生活应付款', remaining: due - paid, weeklyPayment: 30, createdWeek: b.week });
      result.state.nextLifeTier = 'DESTITUTE'; result.state.pulse = 'DEBTS';
      notes.push({ title: '本周生活应付款', text: `已付${paid}便士，未付${due - paid}便士如实计欠；下周采用赤贫生活。` });
      result = resolveSliceWeeklyFinance(result.state); notes.push(...result.receipts);
    }
    b.cash = result.state.cash;
    const { lifeTier, nextLifeTier, debts, missedWeeks, credit } = result.state;
    Object.assign(f.finance, { lifeTier: nextLifeTier, nextLifeTier, debts: clone(debts), missedWeeks, credit });
    void lifeTier;
    b.week++; b.date = addGameWeeks(b.date, 1); b.actions = f.finance.weeklyBudget; f.nowSecond += 604800;
  }
}
function syncCampaign(root: RedPriestState, eventId: string): void {
  if (root.campaign!.week === root.frame!.budget.week) return;
  const result = advanceRedPriestCampaignToWeek(root.campaign!, host(root, `${eventId}:elapsed-time`));
  need(result.ok, result.ok ? '' : result.block.message); root.campaign = result.state;
}
function roadWeeks(node: CampaignNodeId): number {
  let total = 0;
  for (const route of RED_PRIEST_CAMPAIGN_ROUTES) { total += route.weeks; if (route.to === node) return total; }
  throw Error('这处地点尚无真实运输路线。');
}
function materialTransport(root: RedPriestState, context: VerifiedContext, eventId: string, revision: number, from: string, departedWeek: number): RedPriestEvent['materialReceipt'] {
  if (!['ACTIVE', 'ASCENDED'].includes(root.materials!.status) || root.frame!.budget.status !== 'ACTIVE') return null;
  const frame = materialFrame(root, eventId, revision), r: RedPriestMaterialTransportReceipt = {
    id: `${eventId}:original-transport`, eventId, originDigest: frame.originDigest, actorId: frame.actorId, locationId: frame.locationId,
    week: frame.week, revision, sourceTravelReceiptId: `${eventId}:travel`, fromLocationId: from, toLocationId: frame.locationId,
    departedWeek, arrivedWeek: frame.week,
    carried: root.materials!.items.filter(i => i.holderId === frame.actorId && ['INTEGRATED_PLAYER', 'INTEGRATED_S0', 'PLAYER_HELD', 'IN_COMPOUND'].includes(i.disposition))
      .map(i => ({ itemId: i.id, containerId: i.containerId! })) };
  const result = transportRedPriestMaterials(root.materials!, { ...frame, authority: authority(context, frame, null, r) }, r);
  root.materials = result.state; return result.receipt;
}
function materialEvidence(root: RedPriestState, c: RedPriestMaterialCommand, frame: RedPriestMaterialFrame,
  random: ReturnType<typeof checks>, revision: number): RedPriestMaterialEvidence {
  const base = { id: `${frame.eventId}:material-evidence`, eventId: frame.eventId, originDigest: frame.originDigest, actorId: frame.actorId,
    locationId: frame.locationId, week: frame.week, revision };
  if (c.type === 'PREPARE_COMPOUND') {
    const supply = redPriestCompoundSupply(root.materials!.compounds.length + 1, root.materials!.origin.checkpoint.week);
    need(supply, '普通调配物料的原库存已经用尽。');
    return { ...base, kind: 'COMPOUND_SUPPLY', batchId: supply.batchId, providerId: supply.providerId,
      chargedCash: RED_PRIEST_MATERIAL_COSTS.PREPARE_COMPOUND.cash, inputs: clone(supply.inputs) };
  }
  const item = root.materials!.items.find(i => i.id === ('itemId' in c ? c.itemId : RED_PRIEST_UNIQUENESS_ID))!;
  const check = random.check(c.type === 'PURIFY_REMAINS' ? 'will' : 'knowledge', c.type === 'PURIFY_REMAINS' ? 40 : 32);
  const passed = check.tier === 'SUCCESS' || check.tier === 'GREAT_SUCCESS';
  let container = item.containerId, location = item.locationId, keeper = item.holderId,
    before = item.contamination, after = item.contamination, recoverable = item.recoverable, custody: string | null = null;
  if (c.type === 'TRACE_DISPOSITION') {
    if (item.disposition === 'SUPPLIER_BOTTLED') { before = 0; after = 0; recoverable = true; custody = item.sourceEventId; }
    else {
      const lead = RED_PRIEST_SUPPLIER_LEADS.find(l => l.itemId === item.id); need(lead, '尚无这份原特性的处置线索。');
      container = lead.containerId; location = lead.locationId; keeper = lead.custodianId;
      after = 20; recoverable = true; custody = lead.leadId;
    }
  } else if (c.type === 'INSPECT_RELIC' || c.type === 'VERIFY_RELIC' || c.type === 'TRANSFER_RELIC') {
    const tail = root.materials!.origin.uniqueness.custody.at(-1)!;
    container = tail.containerId; location = tail.locationId; keeper = tail.toCustodianId;
    before = 0; after = 0; recoverable = false; custody = tail.id;
  } else if (c.type === 'PURIFY_REMAINS' && passed) after = 0;
  const afterActor = clone(frame.actor);
  if (c.type === 'PURIFY_REMAINS' && !passed) {
    const severe = check.tier === 'GREAT_FAILURE'; afterActor.health = Math.max(0, afterActor.health - (severe ? 24 : 8));
    afterActor.mind = Math.max(0, afterActor.mind - (severe ? 18 : 6)); afterActor.pollution = Math.min(100, afterActor.pollution + (severe ? 20 : 8));
    if (severe) afterActor.injuryIds.push(`${frame.eventId}:purification-injury`);
    if (afterActor.health === 0 || afterActor.mind === 0 || afterActor.pollution >= 100) { afterActor.status = 'DEAD'; afterActor.health = 0; }
    after = (before ?? 0) + 5;
  }
  const result: RedPriestMaterialCheckReceipt = { ...base, kind: 'MATERIAL_CHECK', action: c.type, itemId: item.id,
    sourceEventId: item.sourceEventId, checkReceiptId: random.receipts.at(-1)!.id, result: passed ? 'SUCCESS' : 'FAILURE',
    containerId: container, materialLocationId: location, custodianId: keeper, contaminationBefore: before, contaminationAfter: after,
    recoverable, custodyRecordId: custody, actorAfter: afterActor };
  return result;
}
function publishActor(b: RedPriestBudget, after: RedPriestMaterialActor, revision: number): void {
  b.health = after.health; b.mind = after.mind; b.pollution = after.pollution; b.status = after.status;
  for (const id of after.injuryIds) if (!b.injuries.some(i => i.id === id)) { b.injuries.push({ id, severity: 'HEAVY', acquiredRevision: revision, treatedRevision: null }); b.injuryRisk += 2; }
}
function reduce(prepared: Prepared, command: RedPriestCommand, revision: number): RedPriestEvent {
  const { root, context } = prepared, f = root.frame!, b = f.budget;
  need(validateRedPriestCommand(command) && command.type !== 'LEARN_GUIDANCE', '这项行动的内容无效。');
  need(root.guidanceKnown && root.source && b.status === 'ACTIVE', '已经死亡或结束的角色不能继续行动。');
  need(root.journal.length < 4096 && revision === root.source.revision + 2 + root.journal.length, '本次实际动作次序无效。');
  need(root.epilogue?.status !== 'ACTIVE' || command.type === 'EPILOGUE', '先沿当前运输路完成救援或普通撤出。');
  const eventId = `R209:${root.source.runId}:${revision}`, before = clone(f), beforeDigest = dataDigest(root), random = checks(f, eventId);
  let campaignHost: RedPriestCampaignHost | null = null, materialReceipt: RedPriestEvent['materialReceipt'] = null;
  const financeReceipts: RedPriestEvent['financeReceipts'] = [], notes: string[] = [];
  if (command.type === 'WORK') {
    need(city(f.location), '须先沿普通路线回到贝克兰德，再做原来的本职工作。');
    need(f.finance.wagePaidWeek !== b.week, '本周职业工资已经结算，不能重复入账。');
    pay(b, { actions: 1 }); b.cash += root.source.character.weeklyWage; f.finance.wagePaidWeek = b.week; f.nowSecond += 28800;
    notes.push(`本周原职业工资${root.source.character.weeklyWage}便士已入账。`);
  } else if (command.type === 'REST') {
    pay(b, { actions: 1 }); const life = SLICE_LIFE[f.finance.lifeTier];
    b.health = Math.min(100, b.health + life.health); b.mind = Math.min(100, b.mind + life.mind);
    b.spirituality = Math.min(120, b.spirituality + Math.round(120 * life.spirituality)); b.pollution = Math.max(0, b.pollution - 10);
    b.injuries = b.injuries.filter(i => !(b.health >= 80 && i.acquiredRevision < revision &&
      (i.severity === 'LIGHT' || i.treatedRevision !== null && i.treatedRevision < revision)));
    if (!b.injuries.length) b.injuryRisk = 0;
    f.nowSecond += 28800; notes.push('按当前生活档休养；未经处置的重伤仍然保留。');
  } else if (command.type === 'CLINIC') {
    need(city(f.location) || f.location === root.campaign!.location && f.location !== 'loen-headquarters' && root.campaign!.nodes[f.location as CampaignNodeId].consolidated,
      '须到城市诊所或实际巩固驻地的原救护站。');
    need(b.injuries.some(i => i.severity === 'HEAVY' && i.treatedRevision === null), '当前没有尚未处置的重伤。');
    pay(b, { actions: 1, cash: 60 });
    for (const injury of b.injuries) if (injury.severity === 'HEAVY' && injury.treatedRevision === null) injury.treatedRevision = revision;
    f.nowSecond += 3600; notes.push('60便士普通处置已完成；仍须之后休养并达到80健康，才能解除重伤。');
  } else if (command.type === 'NEXT_WEEK') {
    // Waiting deliberately abandons remaining opportunities. It never pays a
    // wage, replenishes health, removes wounds or suppresses agreed repayments.
    b.actions = 0; weeks(root, 1, revision, eventId, financeReceipts);
  } else if (command.type === 'TRAVEL') {
    need(command.to !== f.location, '本人已经在这处原地点。');
    const from = f.location, departed = b.week;
    let travel = 0;
    if (city(from) && city(command.to)) {
      need(root.campaign!.phase === 'CRISIS' || root.campaign!.phase === 'ARMISTICE' || root.campaign!.phase === 'WITHDRAWN', '原军团正在执行发动命令，先沿真实战役路线收束。');
      pay(b, { actions: 1, cash: 10 }); f.nowSecond += 3600;
    } else {
      need(root.campaign!.phase === 'ARMISTICE' || root.campaign!.phase === 'WITHDRAWN', '战争尚未结束，不能离开军团跳过大陆行军。');
      const node = city(from) ? command.to : from;
      need(RED_PRIEST_CAMPAIGN_NODES.some(n => n.id === node) && (city(from) ? city(from) && command.to === root.campaign!.location : command.to === 'loen-headquarters'), '须沿已行经运输路往返总部与原军团驻地。');
      travel = roadWeeks(node as CampaignNodeId); pay(b, { actions: 1, cash: travel * 10 });
      weeks(root, travel, revision, eventId, financeReceipts);
    }
    f.location = command.to;
    materialReceipt = materialTransport(root, context, eventId, revision, from, departed);
    notes.push(travel ? `已沿原大陆运输路行经${travel}周，个人生活及旧还款已逐周结算。` : '本人及随身原件沿普通城市道路实际到场。');
  } else if (command.type === 'CAMPAIGN') {
    need(f.location === root.campaign!.location, '本人须先沿真实路线抵达原军团所在地点。');
    if (command.command.type === 'BATTLE' || command.command.type === 'DECLARE_OFFENSIVE')
      need(b.health >= 60 && b.mind >= 50 && !b.injuries.some(i => i.severity === 'HEAVY'), '须先处理重伤并休养，不能带着未愈重伤发动或指挥会战。');
    campaignHost = host(root, eventId);
    const reason = getRedPriestCampaignBlock(root.campaign!, command.command, campaignHost); need(reason === null, reason?.message ?? '当前无法进行这项战役行动。');
    const challenge = getRedPriestCampaignChallenge(root.campaign!, command.command);
    if (challenge) {
      const check = random.check(challenge.kind === 'BATTLE' ? 'will' : 'knowledge', challenge.difficulty);
      campaignHost = { ...campaignHost, receipt: { id: `${eventId}:campaign-check`, campaignId: root.campaign!.campaignId, eventId,
        revision: root.campaign!.revision, week: b.week, kind: challenge.kind, targetId: challenge.targetId,
        result: check.tier === 'GREAT_FAILURE' ? 'SEVERE_FAILURE' : check.tier,
        source: challenge.kind === 'BATTLE' ? 'BATTLE_RESOLUTION' : 'NORMAL_CHECK' } };
    }
    const next = reduceRedPriestCampaign(root.campaign!, command.command, campaignHost); need(next.ok, next.ok ? '' : next.block.message);
    const from = f.location, departed = b.week; root.campaign = next.state;
    pay(b, next.settlement); b.cash += next.settlement.cashGain;
    weeks(root, next.settlement.weeks, revision, eventId, financeReceipts); f.location = next.settlement.toLocation;
    if (from !== f.location) materialReceipt = materialTransport(root, context, eventId, revision, from, departed);
    notes.push(...next.events.map(e => e.message));
  } else if (command.type === 'MATERIAL') {
    need(b.sequence === 1 && root.materials!.status === 'ACTIVE', '这批原件只能用于本人尚未结束的晋升筹备。');
    const frame = materialFrame(root, eventId, revision), preliminary: RedPriestMaterialHost = { ...frame, authority: authority(context, frame) };
    const reason = redPriestMaterialBlock(root.materials!, command.command, preliminary); need(reason === null, reason ?? '这批原件尚不具备条件。');
    frame.evidence = materialEvidence(root, command.command, frame, random, revision);
    const result = reduceRedPriestMaterials(root.materials!, command.command, { ...frame, authority: authority(context, frame) });
    root.materials = result.state; pay(b, result.cost); publishActor(b, result.actorAfter, revision); materialReceipt = result.receipt; f.nowSecond += 3600;
  } else if (command.type === 'CONSUME') {
    const rules = RED_PRIEST_CONSUMPTION, achievement = deriveRedPriestCampaignAchievement(root.campaign!);
    need(b.sequence === 1 && root.promotionWeek === null && b.acting === 100, '须由已经完整消化的征服者本人服药。');
    need(achievement.achieved && achievement.ceased, '须先完成实际北大陆战争、五处独立胜利与三战区控制，并真实结束战争。');
    need(f.location === RED_PRIEST_MATERIAL_LOCATIONS.workshop, '本人及原成药须沿真实路线回到封闭调配室。');
    need(b.health >= rules.healthMinimum && b.mind >= rules.mindMinimum && !b.injuries.length, '先真正恢复到80健康、70精神并解除原伤势，再承担服药风险。');
    need(b.actions >= 1 && b.spirituality >= rules.spirituality, '服药需要1行动与30灵性。');
    const compound = root.materials!.compounds.find(c => c.id === command.compoundId);
    need(compound?.status === 'PREPARED' && compound.locationId === f.location, '须由本人带着这瓶真实原成药到场。');
    const frame = materialFrame(root, eventId, revision), beforeActor = actor(b), check = random.check('will', rules.difficulty);
    const passed = check.tier === 'SUCCESS' || check.tier === 'GREAT_SUCCESS', severe = check.tier === 'GREAT_FAILURE';
    pay(b, { actions: 1, spirituality: rules.spirituality });
    if (passed) {
      b.sequence = 0; b.acting = 0; root.promotionWeek = b.week;
      for (const id of RED_PRIEST_ABILITY_IDS) b.mastery[id] = 0;
      b.completedSources.push('RED_PRIEST_ORIGINAL_SUCCESSION');
    } else {
      pay(b, { health: severe ? rules.greatFailureHealth : rules.failureHealth, mind: severe ? rules.greatFailureMind : rules.failureMind,
        pollution: severe ? rules.greatFailurePollution : rules.failurePollution });
      b.injuries.push({ id: `${eventId}:potion-injury`, severity: 'HEAVY', acquiredRevision: revision, treatedRevision: null }); b.injuryRisk += 2;
    }
    const r: RedPriestMaterialConsumptionReceipt = { id: `${eventId}:consumption`, eventId, originDigest: frame.originDigest,
      actorId: frame.actorId, locationId: frame.locationId, week: frame.week, revision, compoundId: compound.id, itemIds: [...RED_PRIEST_MATERIAL_IDS],
      outcome: passed ? 'SUCCESS' : 'FAILURE', formulaReceiptId: compound.supplyReceiptId,
      warAchievementReceiptId: `${root.campaign!.campaignId}:achieved:${root.campaign!.warStarted!.eventId}`,
      checkReceiptId: random.receipts.at(-1)!.id, actorBefore: beforeActor, actorAfter: actor(b),
      destinations: root.materials!.items.map(item => {
        if (passed) return { itemId: item.id, disposition: 'INTEGRATED_S0' as const, locationId: f.location,
          containerId: `body:${frame.actorId}`, holderId: frame.actorId, contamination: 0, recoverable: false };
        if (item.id === compound.integratedMaterialId && b.status === 'ACTIVE') return { itemId: item.id, disposition: 'INTEGRATED_PLAYER' as const,
          locationId: f.location, containerId: `body:${frame.actorId}`, holderId: frame.actorId, contamination: b.pollution, recoverable: false };
        // Only a survivable, contained rejection can leave identifiable original
        // residue in the retained original boxes at this actual sealed workshop.
        const originalBox = compound.sourceContainers.find(c => c.itemId === item.id)?.containerId;
        if (!severe && b.status === 'ACTIVE' && check.roll <= 80 && originalBox) return { itemId: item.id, disposition: 'LOCATED_DIRTY' as const,
          locationId: f.location, containerId: originalBox, holderId: 'backlund:sealed-workshop-keeper', contamination: 35, recoverable: true };
        return { itemId: item.id, disposition: 'UNAVAILABLE' as const, locationId: null, containerId: null, holderId: null, contamination: null, recoverable: false };
      }) };
    const result = applyRedPriestMaterialConsumption(root.materials!, { ...frame, authority: authority(context, frame, r) }, r);
    root.materials = result.state; materialReceipt = result.receipt; f.nowSecond += 3600;
    notes.push(passed ? '三份原特性与唯一性在同一本人体内完成融合；旧原件已全部登记为消耗。' : '实际服药失败；伤害、污染与每份原件的去向已逐一保留，没有免费复起。');
  } else if (command.type === 'START_EPILOGUE') {
    need(b.sequence === 0 && root.promotionWeek !== null && root.epilogue === null, '须由已经实际成神的本人参与这宗尚未开始的战后救援。');
    need(f.location === root.campaign!.location && f.location !== 'loen-headquarters', '须沿原大陆运输路亲自回到停战后的原军团驻地。');
    need(b.actions >= 1, '开始现场救援需要一次行动。');
    const dispatchId = `${eventId}:detachment`, result = dispatchRedPriestCampaignDetachment(root.campaign!, host(root, dispatchId), { legionId: 'loen-expedition', personnel: 6 });
    need(result.ok, result.ok ? '' : result.block.message); root.campaign = result.state; pay(b, { actions: 1 });
    root.epilogue = createRedPriestEpilogue({ eventId, week: b.week, revision, legionId: 'loen-expedition', location: f.location as CampaignNodeId, detachmentId: dispatchId });
    f.nowSecond += 600; notes.push('原军团实派六人处理运输侧线火势，三名既有伤员仍待转运；没有征召旧互助成员。');
  } else if (command.type === 'EPILOGUE') {
    need(root.epilogue && f.location === root.epilogue.originLocation, '本人须实际在这宗原运输路救援现场。');
    const reason = redPriestEpilogueBlock(root.epilogue, command.command, b); need(reason === null, reason ?? '现场条件不足。');
    const kind = command.command.type, check = kind === 'WITHDRAW' || kind === 'REPORT' ? null : random.check(kind === 'EVACUATE' ? 'physique' : 'will',
      kind === 'CONTAIN_FIRE' ? 48 : kind === 'COORDINATE' ? 42 : root.epilogue.fire >= 50 ? 48 : 36, kind === 'EVACUATE' && root.epilogue.coordinated ? 5 : 0);
    root.epilogue = applyRedPriestEpilogue(root.epilogue, command.command, b, { eventId, revision, check }); f.nowSecond += 300;
    if (root.epilogue.status !== 'ACTIVE' && root.epilogue.settlementEventId === null) {
      const settleId = `${eventId}:detachment-return`, result = settleRedPriestCampaignDetachment(root.campaign!, host(root, settleId),
        { detachmentId: root.epilogue.detachmentId, killed: root.epilogue.killed, wounded: root.epilogue.wounded });
      need(result.ok, result.ok ? '' : result.block.message); root.campaign = result.state;
      root.epilogue.returned = root.epilogue.personnel - root.epilogue.killed - root.epilogue.wounded; root.epilogue.settlementEventId = settleId;
    }
    notes.push(root.epilogue.journal.at(-1)!.summary);
  } else throw Error('这项行动尚未接线。');
  syncCampaign(root, eventId);
  const event: RedPriestEvent = { id: eventId, revision, command: clone(command), before, after: clone(f), randomReceipts: clone(random.receipts),
    campaignHost: clone(campaignHost), materialReceipt: clone(materialReceipt), financeReceipts, notes, beforeDigest, afterDigest: dataDigest(root) };
  root.journal.push(event); return event;
}
/** Full raw-entry replay independently authenticates the predecessor, constructs
 * all hosts from real state, reruns every central draw and compares all receipts.
 * Neither supplied module digests nor a public prepared object are authority. */
function reconstruct(s: SliceState): Prepared {
  const saved = s.redPriest;
  need(saved?.source && validateRedPriestSource(s, saved.source), '原身份、原军团与三份特性历史未通过核验。');
  need(Array.isArray(saved.journal) && saved.journal.length <= 4096, '本章行动记录长度无效。');
  const prepared = start(clone(saved.source));
  for (const event of saved.journal) {
    need(event && event.revision === saved.source.revision + 2 + prepared.root.journal.length, '本章实际修订次序不一致。');
    const actual = reduce(prepared, clone(event.command), event.revision);
    need(sameRedPriest(actual, event), '实际行动、检定、费用或来源回执与原记录不一致。');
  }
  need(sameRedPriest(prepared.root, saved), '当前战争、材料或身体状态不能由原行动重建。');
  return prepared;
}
function fork(value: Prepared): Prepared { return { root: clone(value.root), context: value.context }; }
export function validateRedPriestRoot(s: SliceState): void { reconstruct(s); }
export function transitionRedPriest(s: SliceState, command: RedPriestCommand): RedPriestState {
  const prepared = reconstruct(s); reduce(prepared, clone(command), s.revision + 1); return prepared.root;
}
export function openRedPriestOwnedEngine(s: SliceState): RedPriestOwnedEngine { return retain(reconstruct(clone(s))); }
export function snapshotRedPriestOwnedEngine(handle: RedPriestOwnedEngine): RedPriestState { return clone(getOwned(handle).root); }
export function advanceRedPriestOwnedEngine(handle: RedPriestOwnedEngine, command: RedPriestCommand, revision: number): RedPriestOwnedEngine {
  const prepared = fork(getOwned(handle)); reduce(prepared, clone(command), revision); return retain(prepared);
}
export function blockRedPriestOwnedEngine(handle: RedPriestOwnedEngine, command: RedPriestCommand, revision: number): string | null {
  try { reduce(fork(getOwned(handle)), clone(command), revision); return null; } catch (error) { return error instanceof Error ? error.message : '当前不能执行这项行动。'; }
}
